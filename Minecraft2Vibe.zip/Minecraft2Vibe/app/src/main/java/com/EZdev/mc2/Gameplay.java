package com.EZdev.mc2;

import java.util.ArrayList;

public class Gameplay {
    public float camX = 8f, camY = 100f, camZ = 8f; 
    public float yaw = 0f, pitch = 0f;
    public float joyMoveX = 0f, joyMoveY = 0f;
    
    public float velocityY = 0f;
    public boolean onGround = false;
    private boolean hasSpawned = false;
    private boolean wantsToJump = false; 

    public float playerWidth = 0.6f;
    public float playerHeight = 1.8f;

    public byte activeBlock = 1; 
    public float gameTime = 0f; // Die innere Uhr des Spiels!

    // Liste der aktivierten, tickenden TNTs
    public ArrayList<ActiveTNT> tickingTNTs = new ArrayList<>();

    public class ActiveTNT {
        public float x, y, z;
        public float timer = 3.0f; // 3 Sekunden bis zum Boom
        public ActiveTNT(float x, float y, float z) { this.x = x; this.y = y; this.z = z; }
    }

    public void update(float dt, WorldLogic world) {
        if (!hasSpawned) { spawnOnHighestBlock(world); return; }
        if (dt > 0.05f) dt = 0.05f;

        gameTime += dt;

        // TNT Countdown!
        for (int i = tickingTNTs.size() - 1; i >= 0; i--) {
            ActiveTNT tnt = tickingTNTs.get(i);
            tnt.timer -= dt;
            if (tnt.timer <= 0) {
                world.explode(tnt.x, tnt.y, tnt.z, 4.0f);
                tickingTNTs.remove(i);
            }
        }

        if (checkCollision(world, camX, camY, camZ)) { camY += 2.5f * dt; }

        if (wantsToJump && onGround) { velocityY = 8.5f; onGround = false; }
        wantsToJump = false; 

        velocityY -= 25f * dt; 
        if (velocityY < -20f) velocityY = -20f; 

        float nextY = camY + velocityY * dt;
        if (!checkCollision(world, camX, nextY, camZ)) {
            camY = nextY;
            onGround = false;
        } else {
            if (velocityY < 0) {
                onGround = true;
                camY = (float) Math.floor(nextY) + 1.001f;
            } else {
                camY = (float) Math.floor(nextY + playerHeight) - playerHeight - 0.001f;
            }
            velocityY = 0; 
        }

        float speed = 5.0f * dt;
        float dirX = (float) Math.sin(Math.toRadians(yaw));
        float dirZ = (float) -Math.cos(Math.toRadians(yaw));
        float rightX = (float) Math.cos(Math.toRadians(yaw));
        float rightZ = (float) Math.sin(Math.toRadians(yaw));

        float moveX = (dirX * -joyMoveY + rightX * joyMoveX) * speed;
        float moveZ = (dirZ * -joyMoveY + rightZ * joyMoveX) * speed;

        if (!checkCollision(world, camX + moveX, camY, camZ)) camX += moveX;
        if (!checkCollision(world, camX, camY, camZ + moveZ)) camZ += moveZ;

        if (camY < -20f) { hasSpawned = false; camY = 100f; velocityY = 0; }
    }

    public void jump() { wantsToJump = true; }

    private boolean checkCollision(WorldLogic world, float x, float y, float z) {
        float shrink = 0.01f;
        int minX = (int) Math.floor(x - playerWidth / 2f + shrink);
        int maxX = (int) Math.floor(x + playerWidth / 2f - shrink);
        int minY = (int) Math.floor(y);
        int maxY = (int) Math.floor(y + playerHeight - shrink); 
        int minZ = (int) Math.floor(z - playerWidth / 2f + shrink);
        int maxZ = (int) Math.floor(z + playerWidth / 2f - shrink);

        for (int bx = minX; bx <= maxX; bx++) {
            for (int by = minY; by <= maxY; by++) {
                for (int bz = minZ; bz <= maxZ; bz++) {
                    byte block = world.getBlock(bx, by, bz);
                    // Feuer (6) hat KEINE Kollision! Man kann durchlaufen!
                    if (block > 0 && block != 6) return true; 
                }
            }
        }
        return false;
    }

    private void spawnOnHighestBlock(WorldLogic world) {
        int cx = (int) Math.floor(camX);
        int cz = (int) Math.floor(camZ);
        for (int y = 127; y > 0; y--) {
            if (world.getBlock(cx, y, cz) > 0) {
                camY = y + 1.001f; 
                hasSpawned = true;
                return;
            }
        }
    }
}