.class public Lcom/EZdev/mc2/Gameplay$ActiveFire;
.super Ljava/lang/Object;
.source "Gameplay.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/Gameplay;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ActiveFire"
.end annotation


# instance fields
.field public life:F

.field public spreadTimer:F

.field final synthetic this$0:Lcom/EZdev/mc2/Gameplay;

.field public x:I

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>(Lcom/EZdev/mc2/Gameplay;III)V
    .locals 0
    .param p1, "this$0"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "x"    # I
    .param p3, "y"    # I
    .param p4, "z"    # I

    .line 75
    iput-object p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0, p2, p3, p4}, Lcom/EZdev/mc2/Gameplay$ActiveFire;->init(III)V

    return-void
.end method


# virtual methods
.method public init(III)V
    .locals 2
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I

    .line 77
    iput p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    iput p2, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    iput p3, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    .line 78
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v1, 0x40a00000    # 5.0f

    mul-float/2addr v0, v1

    add-float/2addr v0, v1

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->life:F

    .line 79
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v1, 0x3fc00000    # 1.5f

    mul-float/2addr v0, v1

    const/high16 v1, 0x3f000000    # 0.5f

    add-float/2addr v0, v1

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFire;->spreadTimer:F

    .line 80
    return-void
.end method
