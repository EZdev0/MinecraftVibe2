.class public Lcom/EZdev/mc2/Entity;
.super Ljava/lang/Object;
.source "Entity.java"


# instance fields
.field public changeDirTimer:F

.field public onGround:Z

.field private final random:Ljava/security/SecureRandom;

.field public targetX:F

.field public targetZ:F

.field public vx:F

.field public vy:F

.field public vz:F

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method public constructor <init>(FFF)V
    .locals 1
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/Entity;->random:Ljava/security/SecureRandom;

    .line 8
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/Entity;->vx:F

    iput v0, p0, Lcom/EZdev/mc2/Entity;->vy:F

    iput v0, p0, Lcom/EZdev/mc2/Entity;->vz:F

    .line 10
    iput v0, p0, Lcom/EZdev/mc2/Entity;->changeDirTimer:F

    .line 11
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/EZdev/mc2/Entity;->onGround:Z

    .line 14
    iput p1, p0, Lcom/EZdev/mc2/Entity;->x:F

    iput p2, p0, Lcom/EZdev/mc2/Entity;->y:F

    iput p3, p0, Lcom/EZdev/mc2/Entity;->z:F

    .line 15
    iput p1, p0, Lcom/EZdev/mc2/Entity;->targetX:F

    iput p3, p0, Lcom/EZdev/mc2/Entity;->targetZ:F

    .line 16
    return-void
.end method

.method private checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z
    .locals 5
    .param p1, "world"    # Lcom/EZdev/mc2/WorldLogic;
    .param p2, "cx"    # F
    .param p3, "cy"    # F
    .param p4, "cz"    # F

    .line 68
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 69
    :cond_0
    float-to-double v1, p2

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    float-to-double v2, p3

    invoke-static {v2, v3}, Ljava/lang/Math;->floor(D)D

    move-result-wide v2

    double-to-int v2, v2

    float-to-double v3, p4

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    invoke-virtual {p1, v1, v2, v3}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v1

    .line 70
    .local v1, "block":B
    if-lez v1, :cond_1

    const/4 v2, 0x6

    if-eq v1, v2, :cond_1

    const/4 v2, 0x7

    if-eq v1, v2, :cond_1

    const/4 v0, 0x1

    :cond_1
    return v0
.end method


# virtual methods
.method public update(FLcom/EZdev/mc2/WorldLogic;)V
    .locals 10
    .param p1, "dt"    # F
    .param p2, "world"    # Lcom/EZdev/mc2/WorldLogic;

    .line 20
    iget v0, p0, Lcom/EZdev/mc2/Entity;->changeDirTimer:F

    sub-float/2addr v0, p1

    iput v0, p0, Lcom/EZdev/mc2/Entity;->changeDirTimer:F

    .line 21
    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-gtz v0, :cond_0

    .line 22
    iget v0, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget-object v2, p0, Lcom/EZdev/mc2/Entity;->random:Ljava/security/SecureRandom;

    invoke-virtual {v2}, Ljava/util/Random;->nextFloat()F

    move-result v2

    const/high16 v3, 0x41200000    # 10.0f

    mul-float/2addr v2, v3

    const/high16 v4, 0x40a00000    # 5.0f

    sub-float/2addr v2, v4

    add-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/Entity;->targetX:F

    .line 23
    iget v0, p0, Lcom/EZdev/mc2/Entity;->z:F

    iget-object v2, p0, Lcom/EZdev/mc2/Entity;->random:Ljava/security/SecureRandom;

    invoke-virtual {v2}, Ljava/util/Random;->nextFloat()F

    move-result v2

    mul-float/2addr v2, v3

    sub-float/2addr v2, v4

    add-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/Entity;->targetZ:F

    .line 24
    iget-object v0, p0, Lcom/EZdev/mc2/Entity;->random:Ljava/security/SecureRandom;

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v2, 0x40400000    # 3.0f

    mul-float/2addr v0, v2

    add-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/Entity;->changeDirTimer:F

    .line 28
    :cond_0
    iget v0, p0, Lcom/EZdev/mc2/Entity;->targetX:F

    iget v2, p0, Lcom/EZdev/mc2/Entity;->x:F

    sub-float/2addr v0, v2

    .line 29
    .local v0, "dx":F
    iget v2, p0, Lcom/EZdev/mc2/Entity;->targetZ:F

    iget v3, p0, Lcom/EZdev/mc2/Entity;->z:F

    sub-float/2addr v2, v3

    .line 30
    .local v2, "dz":F
    mul-float v3, v0, v0

    mul-float v4, v2, v2

    add-float/2addr v3, v4

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v3

    double-to-float v3, v3

    .line 31
    .local v3, "dist":F
    const/high16 v4, 0x3f000000    # 0.5f

    cmpl-float v4, v3, v4

    if-lez v4, :cond_1

    .line 32
    div-float v4, v0, v3

    const/high16 v5, 0x3fc00000    # 1.5f

    mul-float/2addr v4, v5

    iput v4, p0, Lcom/EZdev/mc2/Entity;->vx:F

    .line 33
    div-float v4, v2, v3

    mul-float/2addr v4, v5

    iput v4, p0, Lcom/EZdev/mc2/Entity;->vz:F

    goto :goto_0

    .line 35
    :cond_1
    iput v1, p0, Lcom/EZdev/mc2/Entity;->vx:F

    iput v1, p0, Lcom/EZdev/mc2/Entity;->vz:F

    .line 39
    :goto_0
    iget v4, p0, Lcom/EZdev/mc2/Entity;->vy:F

    const/high16 v5, 0x41a00000    # 20.0f

    mul-float/2addr v5, p1

    sub-float/2addr v4, v5

    iput v4, p0, Lcom/EZdev/mc2/Entity;->vy:F

    .line 41
    iget v5, p0, Lcom/EZdev/mc2/Entity;->y:F

    mul-float/2addr v4, p1

    add-float/2addr v5, v4

    .line 42
    .local v5, "nextY":F
    iget v4, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v6, p0, Lcom/EZdev/mc2/Entity;->z:F

    invoke-direct {p0, p2, v4, v5, v6}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_2

    .line 43
    iput v5, p0, Lcom/EZdev/mc2/Entity;->y:F

    .line 44
    const/4 v4, 0x0

    iput-boolean v4, p0, Lcom/EZdev/mc2/Entity;->onGround:Z

    goto :goto_1

    .line 46
    :cond_2
    iput v1, p0, Lcom/EZdev/mc2/Entity;->vy:F

    .line 47
    const/4 v4, 0x1

    iput-boolean v4, p0, Lcom/EZdev/mc2/Entity;->onGround:Z

    .line 51
    :goto_1
    iget v4, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v6, p0, Lcom/EZdev/mc2/Entity;->vx:F

    mul-float/2addr v6, p1

    add-float/2addr v4, v6

    .line 52
    .local v4, "nextX":F
    iget v6, p0, Lcom/EZdev/mc2/Entity;->z:F

    iget v7, p0, Lcom/EZdev/mc2/Entity;->vz:F

    mul-float/2addr v7, p1

    add-float/2addr v7, v6

    .line 53
    .local v7, "nextZ":F
    iget-boolean v8, p0, Lcom/EZdev/mc2/Entity;->onGround:Z

    if-eqz v8, :cond_5

    iget v8, p0, Lcom/EZdev/mc2/Entity;->y:F

    invoke-direct {p0, p2, v4, v8, v6}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v6

    if-nez v6, :cond_3

    iget v6, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v8, p0, Lcom/EZdev/mc2/Entity;->y:F

    invoke-direct {p0, p2, v6, v8, v7}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v6

    if-eqz v6, :cond_5

    .line 54
    :cond_3
    iget v6, p0, Lcom/EZdev/mc2/Entity;->y:F

    const v8, 0x3f8ccccd    # 1.1f

    add-float/2addr v6, v8

    iget v9, p0, Lcom/EZdev/mc2/Entity;->z:F

    invoke-direct {p0, p2, v4, v6, v9}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v6

    if-nez v6, :cond_4

    iget v6, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v9, p0, Lcom/EZdev/mc2/Entity;->y:F

    add-float/2addr v9, v8

    invoke-direct {p0, p2, v6, v9, v7}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v6

    if-nez v6, :cond_4

    .line 55
    iget v1, p0, Lcom/EZdev/mc2/Entity;->y:F

    add-float/2addr v1, v8

    iput v1, p0, Lcom/EZdev/mc2/Entity;->y:F

    goto :goto_2

    .line 58
    :cond_4
    iput v1, p0, Lcom/EZdev/mc2/Entity;->changeDirTimer:F

    .line 59
    iput v1, p0, Lcom/EZdev/mc2/Entity;->vx:F

    iput v1, p0, Lcom/EZdev/mc2/Entity;->vz:F

    .line 63
    :cond_5
    :goto_2
    iget v1, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v6, p0, Lcom/EZdev/mc2/Entity;->vx:F

    mul-float/2addr v6, p1

    add-float/2addr v1, v6

    iget v6, p0, Lcom/EZdev/mc2/Entity;->y:F

    iget v8, p0, Lcom/EZdev/mc2/Entity;->z:F

    invoke-direct {p0, p2, v1, v6, v8}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v1

    if-nez v1, :cond_6

    iget v1, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v6, p0, Lcom/EZdev/mc2/Entity;->vx:F

    mul-float/2addr v6, p1

    add-float/2addr v1, v6

    iput v1, p0, Lcom/EZdev/mc2/Entity;->x:F

    .line 64
    :cond_6
    iget v1, p0, Lcom/EZdev/mc2/Entity;->x:F

    iget v6, p0, Lcom/EZdev/mc2/Entity;->y:F

    iget v8, p0, Lcom/EZdev/mc2/Entity;->z:F

    iget v9, p0, Lcom/EZdev/mc2/Entity;->vz:F

    mul-float/2addr v9, p1

    add-float/2addr v8, v9

    invoke-direct {p0, p2, v1, v6, v8}, Lcom/EZdev/mc2/Entity;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v1

    if-nez v1, :cond_7

    iget v1, p0, Lcom/EZdev/mc2/Entity;->z:F

    iget v6, p0, Lcom/EZdev/mc2/Entity;->vz:F

    mul-float/2addr v6, p1

    add-float/2addr v1, v6

    iput v1, p0, Lcom/EZdev/mc2/Entity;->z:F

    .line 65
    :cond_7
    return-void
.end method
