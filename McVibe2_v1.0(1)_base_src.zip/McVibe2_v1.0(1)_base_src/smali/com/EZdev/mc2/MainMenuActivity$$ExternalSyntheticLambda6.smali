.class public final synthetic Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/MainMenuActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/MainMenuActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda6;->f$0:Lcom/EZdev/mc2/MainMenuActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda6;->f$0:Lcom/EZdev/mc2/MainMenuActivity;

    invoke-static {v0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->$r8$lambda$cRbMrSdmBOoFA4sGhN5oa4JrDqA(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V

    return-void
.end method
