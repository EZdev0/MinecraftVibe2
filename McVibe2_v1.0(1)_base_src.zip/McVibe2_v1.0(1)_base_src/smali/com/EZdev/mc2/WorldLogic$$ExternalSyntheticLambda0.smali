.class public final synthetic Lcom/EZdev/mc2/WorldLogic$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/Gameplay;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/Gameplay;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/WorldLogic$$ExternalSyntheticLambda0;->f$0:Lcom/EZdev/mc2/Gameplay;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/WorldLogic$$ExternalSyntheticLambda0;->f$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/WorldLogic;->$r8$lambda$3nJOX2YuuNk4EZB8w0XRZSGstjo(Lcom/EZdev/mc2/Gameplay;)V

    return-void
.end method
