.class public final synthetic Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda5;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/UIManager;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/UIManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda5;->f$0:Lcom/EZdev/mc2/UIManager;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda5;->f$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v0, p1}, Lcom/EZdev/mc2/UIManager;->$r8$lambda$x4QMTl2tx_h1n3jOf-utpzjj_LQ(Lcom/EZdev/mc2/UIManager;Landroid/view/View;)V

    return-void
.end method
