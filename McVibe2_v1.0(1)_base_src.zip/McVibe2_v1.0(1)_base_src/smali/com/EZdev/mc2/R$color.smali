.class public final Lcom/EZdev/mc2/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static black:I = 0x7f010000

.field public static button_blue:I = 0x7f010001

.field public static button_default:I = 0x7f010002

.field public static button_load:I = 0x7f010003

.field public static button_minus:I = 0x7f010004

.field public static button_orange:I = 0x7f010005

.field public static button_plus:I = 0x7f010006

.field public static button_purple:I = 0x7f010007

.field public static button_secondary:I = 0x7f010008

.field public static button_settings:I = 0x7f010009

.field public static button_teal:I = 0x7f01000a

.field public static green:I = 0x7f01000b

.field public static menu_background:I = 0x7f01000c

.field public static settings_panel_background:I = 0x7f01000d

.field public static white:I = 0x7f01000e

.field public static yellow:I = 0x7f01000f


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
