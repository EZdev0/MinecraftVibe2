.class public Lcom/EZdev/mc2/Gameplay;
.super Ljava/lang/Object;
.source "Gameplay.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/EZdev/mc2/Gameplay$ActiveTNT;,
        Lcom/EZdev/mc2/Gameplay$ActiveFire;,
        Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    }
.end annotation


# static fields
.field private static final FIRE_NEIGHBORS:[[I


# instance fields
.field public activeBlock:B

.field public activeFires:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/Gameplay$ActiveFire;",
            ">;"
        }
    .end annotation
.end field

.field public activeSlot:I

.field public activity:Lcom/EZdev/mc2/MainActivity;

.field public blockParticles:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;",
            ">;"
        }
    .end annotation
.end field

.field public breakTimer:F

.field public camX:F

.field public camY:F

.field public camZ:F

.field public fireDamageTimer:F

.field public fireParticles:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;",
            ">;"
        }
    .end annotation
.end field

.field private final firePool:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "Lcom/EZdev/mc2/Gameplay$ActiveFire;",
            ">;"
        }
    .end annotation
.end field

.field public gameTime:F

.field private hasSpawned:Z

.field public health:F

.field public isBreaking:Z

.field public isCreative:Z

.field public isFlying:Z

.field public isRaining:Z

.field public isSneaking:Z

.field public isSprinting:Z

.field public isThundering:Z

.field public joyMoveX:F

.field public joyMoveY:F

.field public onGround:Z

.field private final particlePool:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;",
            ">;"
        }
    .end annotation
.end field

.field public pitch:F

.field public playerHeight:F

.field public playerWidth:F

.field private final random:Ljava/security/SecureRandom;

.field private final raycastResult:[I

.field public shakeIntensity:F

.field public shakeTimer:F

.field public targetX:I

.field public targetY:I

.field public targetZ:I

.field public tickingTNTs:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/Gameplay$ActiveTNT;",
            ">;"
        }
    .end annotation
.end field

.field private final tntPool:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "Lcom/EZdev/mc2/Gameplay$ActiveTNT;",
            ">;"
        }
    .end annotation
.end field

.field public velocityY:F

.field public wantsToJump:Z

.field public weatherTimer:F

.field public yaw:F


# direct methods
.method public static synthetic $r8$lambda$-33bBpFlVvLsgtGpzFzezsEprGc(Lcom/EZdev/mc2/Gameplay;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/Gameplay;->lambda$update$3()V

    return-void
.end method

.method public static synthetic $r8$lambda$QUOYpMu-E3JNdamkIPY9X16yCw4(Lcom/EZdev/mc2/Gameplay;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/Gameplay;->lambda$update$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$js-dt8wVzlJM0fOPVmgUYqq6EqM(Lcom/EZdev/mc2/Gameplay;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/Gameplay;->lambda$update$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$l3uAY9VnYCgLWCswyWZFWRhL1vY(Lcom/EZdev/mc2/Gameplay;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/Gameplay;->lambda$update$0()V

    return-void
.end method

.method public static bridge synthetic -$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 6

    .line 51
    const/4 v0, 0x6

    new-array v0, v0, [[I

    const/4 v1, 0x1

    const/4 v2, 0x0

    filled-new-array {v1, v2, v2}, [I

    move-result-object v3

    aput-object v3, v0, v2

    const/4 v3, -0x1

    filled-new-array {v3, v2, v2}, [I

    move-result-object v4

    aput-object v4, v0, v1

    const/4 v4, 0x2

    filled-new-array {v2, v1, v2}, [I

    move-result-object v5

    aput-object v5, v0, v4

    const/4 v4, 0x3

    filled-new-array {v2, v3, v2}, [I

    move-result-object v5

    aput-object v5, v0, v4

    const/4 v4, 0x4

    filled-new-array {v2, v2, v1}, [I

    move-result-object v1

    aput-object v1, v0, v4

    const/4 v1, 0x5

    filled-new-array {v2, v2, v3}, [I

    move-result-object v2

    aput-object v2, v0, v1

    sput-object v0, Lcom/EZdev/mc2/Gameplay;->FIRE_NEIGHBORS:[[I

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    .line 10
    const/high16 v0, 0x41000000    # 8.0f

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->camX:F

    const/high16 v1, 0x42c80000    # 100.0f

    iput v1, p0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    .line 11
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->yaw:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->pitch:F

    .line 12
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->joyMoveX:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->joyMoveY:F

    .line 14
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 15
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    .line 16
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->hasSpawned:Z

    .line 18
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->wantsToJump:Z

    .line 20
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    .line 21
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isSprinting:Z

    .line 23
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    .line 24
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->shakeTimer:F

    .line 26
    const v2, 0x3fe66666    # 1.8f

    iput v2, p0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    .line 27
    const v2, 0x3f19999a    # 0.6f

    iput v2, p0, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    .line 29
    const/4 v2, 0x1

    iput-byte v2, p0, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    .line 30
    iput v1, p0, Lcom/EZdev/mc2/Gameplay;->activeSlot:I

    .line 31
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->gameTime:F

    .line 33
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    .line 34
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    .line 35
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    .line 36
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    .line 38
    new-instance v2, Ljava/util/ArrayDeque;

    invoke-direct {v2}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->tntPool:Ljava/util/Deque;

    .line 39
    new-instance v2, Ljava/util/ArrayDeque;

    invoke-direct {v2}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->firePool:Ljava/util/Deque;

    .line 40
    new-instance v2, Ljava/util/ArrayDeque;

    invoke-direct {v2}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v2, p0, Lcom/EZdev/mc2/Gameplay;->particlePool:Ljava/util/Deque;

    .line 42
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    .line 43
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    .line 44
    const/high16 v2, 0x41a00000    # 20.0f

    iput v2, p0, Lcom/EZdev/mc2/Gameplay;->health:F

    .line 45
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->fireDamageTimer:F

    .line 46
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isRaining:Z

    .line 47
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isThundering:Z

    .line 48
    const/high16 v2, 0x43960000    # 300.0f

    iput v2, p0, Lcom/EZdev/mc2/Gameplay;->weatherTimer:F

    .line 54
    iput-boolean v1, p0, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    .line 55
    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    .line 56
    const/4 v0, -0x1

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    iput v0, p0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    .line 57
    const/4 v0, 0x3

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/EZdev/mc2/Gameplay;->raycastResult:[I

    return-void
.end method

.method private checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z
    .locals 16
    .param p1, "world"    # Lcom/EZdev/mc2/WorldLogic;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F

    .line 572
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    const/4 v3, 0x0

    if-nez v1, :cond_0

    return v3

    .line 573
    :cond_0
    const v4, 0x3c23d70a    # 0.01f

    .line 574
    .local v4, "shrink":F
    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    const/high16 v6, 0x40000000    # 2.0f

    div-float/2addr v5, v6

    sub-float v5, p2, v5

    add-float/2addr v5, v4

    float-to-double v7, v5

    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    move-result-wide v7

    double-to-int v5, v7

    .line 575
    .local v5, "minX":I
    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    div-float/2addr v7, v6

    add-float v7, p2, v7

    sub-float/2addr v7, v4

    float-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    move-result-wide v7

    double-to-int v7, v7

    .line 576
    .local v7, "maxX":I
    float-to-double v8, v2

    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-int v8, v8

    .line 577
    .local v8, "minY":I
    iget v9, v0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v9, v2

    sub-float/2addr v9, v4

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->floor(D)D

    move-result-wide v9

    double-to-int v9, v9

    .line 578
    .local v9, "maxY":I
    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    div-float/2addr v10, v6

    sub-float v10, p4, v10

    add-float/2addr v10, v4

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D

    move-result-wide v10

    double-to-int v10, v10

    .line 579
    .local v10, "minZ":I
    iget v11, v0, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    div-float/2addr v11, v6

    add-float v6, p4, v11

    sub-float/2addr v6, v4

    float-to-double v11, v6

    invoke-static {v11, v12}, Ljava/lang/Math;->floor(D)D

    move-result-wide v11

    double-to-int v6, v11

    .line 581
    .local v6, "maxZ":I
    move v11, v5

    .local v11, "bx":I
    :goto_0
    if-gt v11, v7, :cond_4

    .line 582
    move v12, v8

    .local v12, "by":I
    :goto_1
    if-gt v12, v9, :cond_3

    .line 583
    move v13, v10

    .local v13, "bz":I
    :goto_2
    if-gt v13, v6, :cond_2

    .line 584
    invoke-virtual {v1, v11, v12, v13}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v14

    .line 585
    .local v14, "block":B
    if-lez v14, :cond_1

    const/4 v15, 0x6

    if-eq v14, v15, :cond_1

    const/4 v15, 0x7

    if-eq v14, v15, :cond_1

    const/4 v3, 0x1

    return v3

    .line 583
    .end local v14    # "block":B
    :cond_1
    add-int/lit8 v13, v13, 0x1

    goto :goto_2

    :cond_2
    nop

    .line 582
    .end local v13    # "bz":I
    add-int/lit8 v12, v12, 0x1

    goto :goto_1

    :cond_3
    nop

    .line 581
    .end local v12    # "by":I
    add-int/lit8 v11, v11, 0x1

    goto :goto_0

    :cond_4
    nop

    .line 589
    .end local v11    # "bx":I
    return v3
.end method

.method private checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z
    .locals 5
    .param p1, "world"    # Lcom/EZdev/mc2/WorldLogic;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F

    .line 566
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 567
    :cond_0
    float-to-double v1, p2

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    float-to-double v2, p3

    invoke-static {v2, v3}, Ljava/lang/Math;->floor(D)D

    move-result-wide v2

    double-to-int v2, v2

    float-to-double v3, p4

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    invoke-virtual {p1, v1, v2, v3}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v1

    .line 568
    .local v1, "block":B
    if-lez v1, :cond_1

    const/4 v2, 0x6

    if-eq v1, v2, :cond_1

    const/4 v2, 0x7

    if-eq v1, v2, :cond_1

    const/4 v0, 0x1

    :cond_1
    return v0
.end method

.method private synthetic lambda$update$0()V
    .locals 2

    .line 215
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/high16 v1, -0x1000000

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    return-void
.end method

.method private synthetic lambda$update$1()V
    .locals 4

    .line 214
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 215
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda3;-><init>(Lcom/EZdev/mc2/Gameplay;)V

    const-wide/16 v2, 0x32

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 216
    return-void
.end method

.method private synthetic lambda$update$2()V
    .locals 3

    .line 258
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    const-string v1, "FEUERZEUG FREIGESCHALTET!"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$update$3()V
    .locals 3

    .line 299
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    const-string v1, "FEUERZEUG FREIGESCHALTET!"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private spawnOnHighestBlock(Lcom/EZdev/mc2/WorldLogic;)V
    .locals 6
    .param p1, "world"    # Lcom/EZdev/mc2/WorldLogic;

    .line 593
    if-nez p1, :cond_0

    return-void

    .line 594
    :cond_0
    iget v0, p0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-int v0, v0

    .line 595
    .local v0, "cx":I
    iget v1, p0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    .line 596
    .local v1, "cz":I
    const/16 v2, 0x7f

    .local v2, "y":I
    :goto_0
    if-lez v2, :cond_2

    .line 597
    invoke-virtual {p1, v0, v2, v1}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v3

    .line 598
    .local v3, "b":B
    if-lez v3, :cond_1

    const/4 v4, 0x7

    if-eq v3, v4, :cond_1

    .line 599
    int-to-float v4, v2

    const v5, 0x3f8020c5    # 1.001f

    add-float/2addr v4, v5

    iput v4, p0, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 600
    const/4 v4, 0x1

    iput-boolean v4, p0, Lcom/EZdev/mc2/Gameplay;->hasSpawned:Z

    .line 601
    return-void

    .line 596
    .end local v3    # "b":B
    :cond_1
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    :cond_2
    nop

    .line 604
    .end local v2    # "y":I
    return-void
.end method

.method private updateParticles(Ljava/util/ArrayList;FLcom/EZdev/mc2/WorldLogic;Z)V
    .locals 8
    .param p2, "dt"    # F
    .param p3, "world"    # Lcom/EZdev/mc2/WorldLogic;
    .param p4, "isFire"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;",
            ">;F",
            "Lcom/EZdev/mc2/WorldLogic;",
            "Z)V"
        }
    .end annotation

    .line 522
    .local p1, "list":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;>;"
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    .local v0, "i":I
    :goto_0
    if-ltz v0, :cond_a

    .line 523
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    .line 524
    .local v1, "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    if-nez v1, :cond_1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    .local v2, "lastIdx":I
    if-ge v0, v2, :cond_0

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    invoke-virtual {p1, v0, v3}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto/16 :goto_2

    .line 525
    .end local v2    # "lastIdx":I
    :cond_1
    iget v2, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->life:F

    sub-float/2addr v2, p2

    iput v2, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->life:F

    .line 526
    iget v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    const/high16 v4, 0x41700000    # 15.0f

    mul-float/2addr v4, p2

    sub-float/2addr v3, v4

    iput v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    .line 527
    iget v4, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    iget v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vx:F

    mul-float/2addr v5, p2

    add-float/2addr v4, v5

    iput v4, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    iget v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    mul-float/2addr v3, p2

    add-float/2addr v5, v3

    iput v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    iget v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    iget v6, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vz:F

    mul-float/2addr v6, p2

    add-float/2addr v3, v6

    iput v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    .line 529
    const/4 v6, 0x0

    cmpg-float v2, v2, v6

    if-gtz v2, :cond_3

    .line 530
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    .line 531
    .restart local v2    # "lastIdx":I
    if-ge v0, v2, :cond_2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    invoke-virtual {p1, v0, v3}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 532
    :cond_2
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 533
    invoke-virtual {p0, v1}, Lcom/EZdev/mc2/Gameplay;->releaseParticle(Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;)V

    .line 534
    goto/16 :goto_2

    .line 537
    .end local v2    # "lastIdx":I
    :cond_3
    invoke-direct {p0, p3, v4, v5, v3}, Lcom/EZdev/mc2/Gameplay;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v2

    if-eqz v2, :cond_9

    .line 538
    if-eqz p4, :cond_6

    iget-byte v2, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->type:B

    const/4 v3, 0x6

    if-ne v2, v3, :cond_6

    .line 539
    iget v2, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    float-to-double v4, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v2, v4

    iget v4, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    iget v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    invoke-virtual {p3, v2, v4, v5}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v2

    .line 540
    .local v2, "block":B
    const/4 v4, 0x3

    if-eq v2, v4, :cond_4

    const/4 v4, 0x4

    if-ne v2, v4, :cond_5

    .line 541
    :cond_4
    iget-object v4, p0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v4}, Ljava/util/Random;->nextFloat()F

    move-result v4

    const v5, 0x3e99999a    # 0.3f

    cmpg-float v4, v4, v5

    if-gez v4, :cond_5

    .line 542
    iget v4, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    iget v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    iget v6, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v6, v6

    invoke-virtual {p3, v4, v5, v6, v3}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 543
    iget-object v3, p0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    iget v4, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    iget v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    iget v6, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v6, v6

    invoke-virtual {p0, v4, v5, v6}, Lcom/EZdev/mc2/Gameplay;->obtainFire(III)Lcom/EZdev/mc2/Gameplay$ActiveFire;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 546
    .end local v2    # "block":B
    :cond_5
    goto :goto_1

    :cond_6
    if-nez p4, :cond_5

    .line 547
    iget v2, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    const v3, -0x41666666    # -0.3f

    mul-float/2addr v2, v3

    iput v2, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    .line 548
    iget v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vx:F

    const/high16 v4, 0x3f000000    # 0.5f

    mul-float/2addr v3, v4

    iput v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vx:F

    iget v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vz:F

    mul-float/2addr v3, v4

    iput v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vz:F

    .line 549
    iget v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    const v4, 0x3dcccccd    # 0.1f

    add-float/2addr v3, v4

    iput v3, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    .line 550
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpg-float v2, v2, v4

    if-gez v2, :cond_7

    iput v6, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vx:F

    iput v6, v1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vz:F

    .line 553
    :cond_7
    :goto_1
    if-eqz p4, :cond_9

    .line 554
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    .line 555
    .local v2, "lastIdx":I
    if-ge v0, v2, :cond_8

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    invoke-virtual {p1, v0, v3}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 556
    :cond_8
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 557
    invoke-virtual {p0, v1}, Lcom/EZdev/mc2/Gameplay;->releaseParticle(Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;)V

    .line 522
    .end local v1    # "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    .end local v2    # "lastIdx":I
    :cond_9
    :goto_2
    add-int/lit8 v0, v0, -0x1

    goto/16 :goto_0

    :cond_a
    nop

    .line 561
    .end local v0    # "i":I
    return-void
.end method


# virtual methods
.method public addBlockParticles(FFFB)V
    .locals 5
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "blockType"    # B

    .line 157
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    const/16 v1, 0x8

    if-ge v0, v1, :cond_0

    .line 158
    iget-object v1, p0, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    const/high16 v2, 0x3f000000    # 0.5f

    add-float v3, p1, v2

    add-float v4, p2, v2

    add-float/2addr v2, p3

    invoke-virtual {p0, v3, v4, v2, p4}, Lcom/EZdev/mc2/Gameplay;->obtainParticle(FFFB)Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 157
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 160
    .end local v0    # "i":I
    return-void
.end method

.method public addExplosionParticles(FFF)V
    .locals 3
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 163
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    const/16 v1, 0x19

    if-ge v0, v1, :cond_0

    .line 164
    iget-object v1, p0, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    const/high16 v2, 0x41a00000    # 20.0f

    invoke-virtual {p0, p1, p2, p3, v2}, Lcom/EZdev/mc2/Gameplay;->obtainParticle(FFFF)Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 163
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 166
    .end local v0    # "i":I
    return-void
.end method

.method public jump()V
    .locals 1

    .line 563
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/Gameplay;->wantsToJump:Z

    return-void
.end method

.method public obtainFire(III)Lcom/EZdev/mc2/Gameplay$ActiveFire;
    .locals 1
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I

    .line 122
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->firePool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 123
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->firePool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->pop()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    .line 124
    .local v0, "fire":Lcom/EZdev/mc2/Gameplay$ActiveFire;
    invoke-virtual {v0, p1, p2, p3}, Lcom/EZdev/mc2/Gameplay$ActiveFire;->init(III)V

    .line 125
    return-object v0

    .line 127
    .end local v0    # "fire":Lcom/EZdev/mc2/Gameplay$ActiveFire;
    :cond_0
    new-instance v0, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/EZdev/mc2/Gameplay$ActiveFire;-><init>(Lcom/EZdev/mc2/Gameplay;III)V

    return-object v0
.end method

.method public obtainParticle(FFFB)Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    .locals 7
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "type"    # B

    .line 135
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->particlePool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 136
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->particlePool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->pop()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    .line 137
    .local v0, "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->init(FFFB)V

    .line 138
    return-object v0

    .line 140
    .end local v0    # "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    :cond_0
    new-instance v0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    move-object v1, v0

    move-object v2, p0

    move v3, p1

    move v4, p2

    move v5, p3

    move v6, p4

    invoke-direct/range {v1 .. v6}, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;-><init>(Lcom/EZdev/mc2/Gameplay;FFFB)V

    return-object v0
.end method

.method public obtainParticle(FFFF)Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    .locals 7
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "intensity"    # F

    .line 144
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->particlePool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 145
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->particlePool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->pop()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    .line 146
    .local v0, "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->init(FFFF)V

    .line 147
    return-object v0

    .line 149
    .end local v0    # "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    :cond_0
    new-instance v0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    move-object v1, v0

    move-object v2, p0

    move v3, p1

    move v4, p2

    move v5, p3

    move v6, p4

    invoke-direct/range {v1 .. v6}, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;-><init>(Lcom/EZdev/mc2/Gameplay;FFFF)V

    return-object v0
.end method

.method public obtainTNT(FFF)Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    .locals 1
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 109
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->tntPool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 110
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->tntPool:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->pop()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    .line 111
    .local v0, "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    invoke-virtual {v0, p1, p2, p3}, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->init(FFF)V

    .line 112
    return-object v0

    .line 114
    .end local v0    # "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    :cond_0
    new-instance v0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/EZdev/mc2/Gameplay$ActiveTNT;-><init>(Lcom/EZdev/mc2/Gameplay;FFF)V

    return-object v0
.end method

.method public releaseFire(Lcom/EZdev/mc2/Gameplay$ActiveFire;)V
    .locals 1
    .param p1, "fire"    # Lcom/EZdev/mc2/Gameplay$ActiveFire;

    .line 131
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->firePool:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->push(Ljava/lang/Object;)V

    .line 132
    :cond_0
    return-void
.end method

.method public releaseParticle(Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;)V
    .locals 1
    .param p1, "p"    # Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    .line 153
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->particlePool:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->push(Ljava/lang/Object;)V

    .line 154
    :cond_0
    return-void
.end method

.method public releaseTNT(Lcom/EZdev/mc2/Gameplay$ActiveTNT;)V
    .locals 1
    .param p1, "tnt"    # Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    .line 118
    if-eqz p1, :cond_0

    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->tntPool:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->push(Ljava/lang/Object;)V

    .line 119
    :cond_0
    return-void
.end method

.method public update(FLcom/EZdev/mc2/WorldLogic;)V
    .locals 33
    .param p1, "dt"    # F
    .param p2, "world"    # Lcom/EZdev/mc2/WorldLogic;

    .line 170
    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iget-object v2, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    const/high16 v3, 0x42200000    # 40.0f

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    iget-object v2, v2, Lcom/EZdev/mc2/MainActivity;->soundManager:Lcom/EZdev/mc2/SoundManager;

    if-eqz v2, :cond_1

    .line 171
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    cmpg-float v6, v6, v3

    if-gez v6, :cond_0

    move v6, v5

    goto :goto_0

    :cond_0
    move v6, v4

    .line 172
    .local v6, "inCave":Z
    :goto_0
    invoke-virtual {v2, v6}, Lcom/EZdev/mc2/SoundManager;->updateReverb(Z)V

    .line 174
    .end local v6    # "inCave":Z
    :cond_1
    if-nez v1, :cond_2

    return-void

    .line 175
    :cond_2
    iget-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->hasSpawned:Z

    if-nez v2, :cond_3

    invoke-direct {v0, v1}, Lcom/EZdev/mc2/Gameplay;->spawnOnHighestBlock(Lcom/EZdev/mc2/WorldLogic;)V

    return-void

    .line 176
    :cond_3
    const v2, 0x3d4ccccd    # 0.05f

    cmpl-float v2, p1, v2

    if-lez v2, :cond_4

    const v2, 0x3d4ccccd    # 0.05f

    .end local p1    # "dt":F
    .local v2, "dt":F
    goto :goto_1

    .end local v2    # "dt":F
    .restart local p1    # "dt":F
    :cond_4
    move/from16 v2, p1

    .line 179
    .end local p1    # "dt":F
    .restart local v2    # "dt":F
    :goto_1
    iget-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    const/high16 v7, 0x40a00000    # 5.0f

    const/high16 v8, 0x3f000000    # 0.5f

    nop

    if-nez v6, :cond_6

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-double v9, v6

    invoke-static {v9, v10}, Ljava/lang/Math;->floor(D)D

    move-result-wide v9

    double-to-int v6, v9

    iget v9, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->floor(D)D

    move-result-wide v9

    double-to-int v9, v9

    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D

    move-result-wide v10

    double-to-int v10, v10

    invoke-virtual {v1, v6, v9, v10}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v6

    nop

    if-nez v6, :cond_5

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-double v9, v6

    .line 180
    invoke-static {v9, v10}, Ljava/lang/Math;->floor(D)D

    move-result-wide v9

    double-to-int v6, v9

    iget v9, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v9, v10

    sub-float/2addr v9, v8

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->floor(D)D

    move-result-wide v9

    double-to-int v9, v9

    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D

    move-result-wide v10

    double-to-int v10, v10

    invoke-virtual {v1, v6, v9, v10}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v6

    if-eqz v6, :cond_6

    .line 181
    :cond_5
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    mul-float v9, v2, v7

    add-float/2addr v6, v9

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 184
    :cond_6
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->gameTime:F

    add-float/2addr v6, v2

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->gameTime:F

    .line 185
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->weatherTimer:F

    sub-float/2addr v6, v2

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->weatherTimer:F

    .line 186
    const/4 v9, 0x0

    cmpg-float v6, v6, v9

    if-gtz v6, :cond_9

    .line 187
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v6}, Ljava/util/Random;->nextFloat()F

    move-result v6

    const/high16 v10, 0x43480000    # 200.0f

    mul-float/2addr v6, v10

    const/high16 v10, 0x42700000    # 60.0f

    add-float/2addr v6, v10

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->weatherTimer:F

    .line 188
    iget-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->isRaining:Z

    if-nez v6, :cond_8

    .line 189
    iput-boolean v5, v0, Lcom/EZdev/mc2/Gameplay;->isRaining:Z

    .line 190
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v6}, Ljava/util/Random;->nextFloat()F

    move-result v6

    const v10, 0x3e99999a    # 0.3f

    cmpg-float v6, v6, v10

    if-gez v6, :cond_7

    move v6, v5

    goto :goto_2

    :cond_7
    move v6, v4

    :goto_2
    iput-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->isThundering:Z

    goto :goto_3

    .line 192
    :cond_8
    iput-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->isRaining:Z

    .line 193
    iput-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->isThundering:Z

    .line 196
    :cond_9
    :goto_3
    iget-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->isRaining:Z

    const/4 v10, 0x7

    const/high16 v11, 0x41200000    # 10.0f

    const/high16 v12, 0x41a00000    # 20.0f

    if-eqz v6, :cond_a

    .line 197
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v6}, Ljava/util/Random;->nextFloat()F

    move-result v6

    cmpg-float v6, v6, v8

    if-gez v6, :cond_a

    .line 198
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget-object v13, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v13}, Ljava/util/Random;->nextFloat()F

    move-result v13

    mul-float/2addr v13, v3

    sub-float/2addr v13, v12

    add-float/2addr v6, v13

    .line 199
    .local v6, "rx":F
    iget v13, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    iget-object v14, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v14}, Ljava/util/Random;->nextFloat()F

    move-result v14

    mul-float/2addr v14, v3

    sub-float/2addr v14, v12

    add-float/2addr v13, v14

    .line 200
    .local v13, "rz":F
    iget v3, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    add-float/2addr v3, v12

    iget-object v14, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v14}, Ljava/util/Random;->nextFloat()F

    move-result v14

    mul-float/2addr v14, v11

    add-float/2addr v3, v14

    .line 201
    .local v3, "ry":F
    invoke-virtual {v0, v6, v3, v13, v10}, Lcom/EZdev/mc2/Gameplay;->obtainParticle(FFFB)Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    move-result-object v14

    .line 202
    .local v14, "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    iget-object v15, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v15}, Ljava/util/Random;->nextFloat()F

    move-result v15

    mul-float/2addr v15, v7

    const/high16 v16, -0x3ee00000    # -10.0f

    sub-float v15, v16, v15

    iput v15, v14, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    .line 203
    iget-object v15, v0, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    invoke-virtual {v15, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 206
    .end local v3    # "ry":F
    .end local v6    # "rx":F
    .end local v13    # "rz":F
    .end local v14    # "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    :cond_a
    iget-boolean v3, v0, Lcom/EZdev/mc2/Gameplay;->isThundering:Z

    const/high16 v6, 0x41c80000    # 25.0f

    const/4 v13, 0x6

    if-eqz v3, :cond_c

    iget-object v3, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v3

    const v14, 0x3c23d70a    # 0.01f

    cmpg-float v3, v3, v14

    if-gez v3, :cond_c

    .line 207
    iget v3, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget-object v14, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v14}, Ljava/util/Random;->nextFloat()F

    move-result v14

    const/high16 v15, 0x42480000    # 50.0f

    mul-float/2addr v14, v15

    sub-float/2addr v14, v6

    add-float/2addr v3, v14

    .line 208
    .local v3, "tx":F
    iget v14, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    iget-object v15, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v15}, Ljava/util/Random;->nextFloat()F

    move-result v15

    const/high16 v16, 0x42480000    # 50.0f

    mul-float v15, v15, v16

    sub-float/2addr v15, v6

    add-float/2addr v14, v15

    .line 209
    .local v14, "tz":F
    const/16 v15, 0x7f

    .local v15, "y":I
    :goto_4
    if-lez v15, :cond_c

    .line 210
    float-to-int v6, v3

    float-to-int v10, v14

    invoke-virtual {v1, v6, v15, v10}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v6

    if-lez v6, :cond_b

    .line 211
    float-to-int v6, v3

    add-int/lit8 v10, v15, 0x1

    float-to-int v7, v14

    invoke-virtual {v1, v6, v10, v7, v13}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 212
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    float-to-int v7, v3

    add-int/lit8 v10, v15, 0x1

    float-to-int v11, v14

    invoke-virtual {v0, v7, v10, v11}, Lcom/EZdev/mc2/Gameplay;->obtainFire(III)Lcom/EZdev/mc2/Gameplay$ActiveFire;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 213
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v6, :cond_c

    new-instance v7, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda0;

    invoke-direct {v7, v0}, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/Gameplay;)V

    invoke-virtual {v6, v7}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_5

    .line 209
    :cond_b
    add-int/lit8 v15, v15, -0x1

    const/high16 v6, 0x41c80000    # 25.0f

    const/high16 v7, 0x40a00000    # 5.0f

    const/4 v10, 0x7

    const/high16 v11, 0x41200000    # 10.0f

    goto :goto_4

    .line 224
    .end local v3    # "tx":F
    .end local v14    # "tz":F
    .end local v15    # "y":I
    :cond_c
    :goto_5
    iget v3, v0, Lcom/EZdev/mc2/Gameplay;->shakeTimer:F

    cmpl-float v6, v3, v9

    if-lez v6, :cond_d

    .line 225
    sub-float/2addr v3, v2

    iput v3, v0, Lcom/EZdev/mc2/Gameplay;->shakeTimer:F

    .line 226
    cmpg-float v3, v3, v9

    if-gtz v3, :cond_e

    iput v9, v0, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    goto :goto_6

    .line 228
    :cond_d
    iput v9, v0, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    .line 232
    :cond_e
    :goto_6
    iget-object v3, v1, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    if-eqz v3, :cond_f

    .line 233
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    nop

    if-eqz v6, :cond_f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/EZdev/mc2/Entity;

    .line 234
    .local v6, "e":Lcom/EZdev/mc2/Entity;
    invoke-virtual {v6, v2, v1}, Lcom/EZdev/mc2/Entity;->update(FLcom/EZdev/mc2/WorldLogic;)V

    .line 235
    .end local v6    # "e":Lcom/EZdev/mc2/Entity;
    goto :goto_7

    .line 239
    :cond_f
    iget-boolean v3, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v3, :cond_10

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    cmpl-float v7, v6, v9

    if-lez v7, :cond_10

    cmpg-float v7, v6, v12

    if-gez v7, :cond_10

    .line 240
    mul-float v7, v2, v8

    add-float/2addr v6, v7

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    .line 241
    cmpl-float v6, v6, v12

    if-lez v6, :cond_10

    iput v12, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    .line 244
    :cond_10
    const/high16 v6, 0x3f800000    # 1.0f

    const-string v7, "FIRE_UNLOCKED"

    const-string v10, "McPrefs"

    if-nez v3, :cond_14

    .line 245
    iput-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    .line 246
    iget v3, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-double v14, v3

    invoke-static {v14, v15}, Ljava/lang/Math;->floor(D)D

    move-result-wide v14

    double-to-int v3, v14

    .line 247
    .local v3, "px":I
    iget v11, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    float-to-double v14, v11

    invoke-static {v14, v15}, Ljava/lang/Math;->floor(D)D

    move-result-wide v14

    double-to-int v11, v14

    .line 248
    .local v11, "py":I
    iget v14, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-double v14, v14

    invoke-static {v14, v15}, Ljava/lang/Math;->floor(D)D

    move-result-wide v14

    double-to-int v14, v14

    .line 249
    .local v14, "pz":I
    iget v15, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    add-float/2addr v15, v6

    float-to-double v4, v15

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    invoke-virtual {v1, v3, v4, v14}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v4

    .line 250
    .local v4, "headBlock":B
    invoke-virtual {v1, v3, v11, v14}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v5

    if-eq v5, v13, :cond_11

    if-ne v4, v13, :cond_12

    :cond_11
    goto :goto_8

    .line 269
    :cond_12
    iput v9, v0, Lcom/EZdev/mc2/Gameplay;->fireDamageTimer:F

    goto :goto_9

    .line 251
    :goto_8
    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->fireDamageTimer:F

    sub-float/2addr v5, v2

    iput v5, v0, Lcom/EZdev/mc2/Gameplay;->fireDamageTimer:F

    .line 252
    cmpg-float v5, v5, v9

    if-gtz v5, :cond_14

    .line 253
    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    const/high16 v15, 0x40000000    # 2.0f

    sub-float/2addr v5, v15

    iput v5, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    .line 254
    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->fireDamageTimer:F

    .line 255
    cmpg-float v5, v5, v9

    if-gtz v5, :cond_14

    .line 256
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v5, :cond_13

    const/4 v15, 0x0

    invoke-virtual {v5, v10, v15}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    invoke-interface {v5, v7, v15}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-nez v5, :cond_13

    .line 257
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-virtual {v5, v10, v15}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/4 v15, 0x1

    invoke-interface {v5, v7, v15}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 258
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v15, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda1;

    invoke-direct {v15, v0}, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda1;-><init>(Lcom/EZdev/mc2/Gameplay;)V

    invoke-virtual {v5, v15}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 259
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v5, v5, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    if-eqz v5, :cond_13

    .line 260
    iget-object v15, v5, Lcom/EZdev/mc2/UIManager;->inventory:[I

    const/16 v21, 0x5

    const/16 v22, 0x3e7

    aput v22, v15, v21

    .line 261
    invoke-virtual {v5}, Lcom/EZdev/mc2/UIManager;->updateHotbarUI()V

    .line 264
    :cond_13
    const/4 v5, 0x0

    iput-boolean v5, v0, Lcom/EZdev/mc2/Gameplay;->hasSpawned:Z

    .line 265
    iput v12, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    .line 274
    .end local v3    # "px":I
    .end local v4    # "headBlock":B
    .end local v11    # "py":I
    .end local v14    # "pz":I
    :cond_14
    :goto_9
    iget-object v3, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    .local v3, "i":I
    :goto_a
    const/high16 v4, 0x40800000    # 4.0f

    if-ltz v3, :cond_20

    .line 275
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    .line 276
    .local v5, "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    if-nez v5, :cond_16

    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v11, 0x1

    sub-int/2addr v4, v11

    .local v4, "lastIdx":I
    if-ge v3, v4, :cond_15

    iget-object v11, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    invoke-virtual {v11, v3, v14}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_15
    iget-object v11, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move v8, v12

    goto/16 :goto_10

    .line 277
    .end local v4    # "lastIdx":I
    :cond_16
    iget v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->timer:F

    sub-float/2addr v11, v2

    iput v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->timer:F

    .line 278
    iget v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    const/high16 v14, 0x41200000    # 10.0f

    mul-float v15, v2, v14

    sub-float/2addr v11, v15

    iput v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    .line 280
    iget v14, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    mul-float/2addr v11, v2

    add-float/2addr v14, v11

    .line 281
    .local v14, "nextY":F
    iget v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    iget v15, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    invoke-direct {v0, v1, v11, v14, v15}, Lcom/EZdev/mc2/Gameplay;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v11

    if-nez v11, :cond_17

    iput v14, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    goto :goto_b

    .line 282
    :cond_17
    iput v9, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    iget v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    mul-float/2addr v11, v8

    iput v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    iget v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    mul-float/2addr v11, v8

    iput v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    .line 284
    :goto_b
    iget v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    iget v15, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    mul-float/2addr v15, v2

    add-float/2addr v11, v15

    .line 285
    .local v11, "nextX":F
    iget v15, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    iget v6, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    invoke-direct {v0, v1, v11, v15, v6}, Lcom/EZdev/mc2/Gameplay;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v6

    if-nez v6, :cond_18

    iput v11, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    goto :goto_c

    :cond_18
    iput v9, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    .line 287
    :goto_c
    iget v6, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    iget v15, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    mul-float/2addr v15, v2

    add-float/2addr v6, v15

    .line 288
    .local v6, "nextZ":F
    iget v15, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    iget v8, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    invoke-direct {v0, v1, v15, v8, v6}, Lcom/EZdev/mc2/Gameplay;->checkCollisionPoint(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v8

    if-nez v8, :cond_19

    iput v6, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    goto :goto_d

    :cond_19
    iput v9, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    .line 290
    :goto_d
    iget v8, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->timer:F

    cmpg-float v8, v8, v9

    if-gtz v8, :cond_1f

    .line 291
    iget v8, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    iget v15, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    iget v13, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    invoke-virtual {v1, v8, v15, v13, v4}, Lcom/EZdev/mc2/WorldLogic;->explode(FFFF)V

    .line 292
    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v8, :cond_1c

    .line 293
    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v13, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    sub-float v15, v8, v13

    sub-float/2addr v8, v13

    mul-float/2addr v15, v8

    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v13, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    sub-float v24, v8, v13

    sub-float/2addr v8, v13

    mul-float v24, v24, v8

    add-float v15, v15, v24

    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    iget v13, v5, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    sub-float v24, v8, v13

    sub-float/2addr v8, v13

    mul-float v24, v24, v8

    add-float v15, v15, v24

    float-to-double v12, v15

    invoke-static {v12, v13}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v12

    double-to-float v12, v12

    .line 294
    .local v12, "dist":F
    const/high16 v13, 0x40a00000    # 5.0f

    cmpg-float v15, v12, v13

    if-gez v15, :cond_1b

    .line 295
    iget v15, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    sub-float v24, v13, v12

    mul-float v24, v24, v4

    sub-float v15, v15, v24

    iput v15, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    .line 296
    cmpg-float v4, v15, v9

    if-gtz v4, :cond_1a

    const/4 v4, 0x0

    iput-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->hasSpawned:Z

    const/high16 v8, 0x41a00000    # 20.0f

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->health:F

    goto :goto_e

    :cond_1a
    const/4 v4, 0x0

    const/high16 v8, 0x41a00000    # 20.0f

    .line 297
    :goto_e
    iget-object v13, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v13, :cond_1d

    invoke-virtual {v13, v10, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v13

    invoke-interface {v13, v7, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v13

    if-nez v13, :cond_1d

    .line 298
    iget-object v13, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-virtual {v13, v10, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v13

    invoke-interface {v13}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const/4 v13, 0x1

    invoke-interface {v4, v7, v13}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 299
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v13, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda2;

    invoke-direct {v13, v0}, Lcom/EZdev/mc2/Gameplay$$ExternalSyntheticLambda2;-><init>(Lcom/EZdev/mc2/Gameplay;)V

    invoke-virtual {v4, v13}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 300
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v4, v4, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    if-eqz v4, :cond_1d

    .line 301
    iget-object v13, v4, Lcom/EZdev/mc2/UIManager;->inventory:[I

    const/4 v15, 0x5

    const/16 v24, 0x3e7

    aput v24, v13, v15

    .line 302
    invoke-virtual {v4}, Lcom/EZdev/mc2/UIManager;->updateHotbarUI()V

    goto :goto_f

    .line 294
    :cond_1b
    const/high16 v8, 0x41a00000    # 20.0f

    goto :goto_f

    .line 292
    .end local v12    # "dist":F
    :cond_1c
    move v8, v12

    .line 307
    :cond_1d
    :goto_f
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v12, 0x1

    sub-int/2addr v4, v12

    .line 308
    .restart local v4    # "lastIdx":I
    if-ge v3, v4, :cond_1e

    iget-object v12, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    invoke-virtual {v12, v3, v13}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 309
    :cond_1e
    iget-object v12, v0, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 310
    invoke-virtual {v0, v5}, Lcom/EZdev/mc2/Gameplay;->releaseTNT(Lcom/EZdev/mc2/Gameplay$ActiveTNT;)V

    goto :goto_10

    .line 290
    .end local v4    # "lastIdx":I
    :cond_1f
    move v8, v12

    .line 274
    .end local v5    # "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    .end local v6    # "nextZ":F
    .end local v11    # "nextX":F
    .end local v14    # "nextY":F
    :goto_10
    add-int/lit8 v3, v3, -0x1

    move v12, v8

    const/high16 v6, 0x3f800000    # 1.0f

    const/high16 v8, 0x3f000000    # 0.5f

    const/4 v13, 0x6

    goto/16 :goto_a

    :cond_20
    nop

    .line 315
    .end local v3    # "i":I
    iget-object v3, v0, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    const/4 v5, 0x1

    invoke-direct {v0, v3, v2, v1, v5}, Lcom/EZdev/mc2/Gameplay;->updateParticles(Ljava/util/ArrayList;FLcom/EZdev/mc2/WorldLogic;Z)V

    .line 316
    iget-object v3, v0, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    const/4 v6, 0x0

    invoke-direct {v0, v3, v2, v1, v6}, Lcom/EZdev/mc2/Gameplay;->updateParticles(Ljava/util/ArrayList;FLcom/EZdev/mc2/WorldLogic;Z)V

    .line 319
    iget-object v3, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v5

    .restart local v3    # "i":I
    :goto_11
    const/4 v6, 0x3

    const/4 v7, 0x2

    if-ltz v3, :cond_31

    .line 320
    iget-object v8, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    .line 321
    .local v8, "fire":Lcom/EZdev/mc2/Gameplay$ActiveFire;
    if-nez v8, :cond_22

    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/4 v6, 0x1

    sub-int/2addr v5, v6

    .local v5, "lastIdx":I
    if-ge v3, v5, :cond_21

    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    invoke-virtual {v6, v3, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_21
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto/16 :goto_16

    .line 323
    .end local v5    # "lastIdx":I
    :cond_22
    iget v10, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    iget v11, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    iget v12, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    invoke-virtual {v1, v10, v11, v12}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v10

    const/4 v11, 0x6

    if-eq v10, v11, :cond_24

    .line 324
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/4 v6, 0x1

    sub-int/2addr v5, v6

    .line 325
    .restart local v5    # "lastIdx":I
    if-ge v3, v5, :cond_23

    .line 326
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    invoke-virtual {v6, v3, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 328
    :cond_23
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 329
    invoke-virtual {v0, v8}, Lcom/EZdev/mc2/Gameplay;->releaseFire(Lcom/EZdev/mc2/Gameplay$ActiveFire;)V

    .line 330
    goto/16 :goto_16

    .line 333
    .end local v5    # "lastIdx":I
    :cond_24
    const/4 v10, 0x0

    .line 334
    .local v10, "hasSupport":Z
    sget-object v11, Lcom/EZdev/mc2/Gameplay;->FIRE_NEIGHBORS:[[I

    array-length v12, v11

    const/4 v13, 0x0

    :goto_12
    if-ge v13, v12, :cond_26

    aget-object v14, v11, v13

    .line 335
    .local v14, "n":[I
    iget v15, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    const/16 v19, 0x0

    aget v24, v14, v19

    add-int v15, v15, v24

    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    const/16 v20, 0x1

    aget v25, v14, v20

    add-int v4, v4, v25

    iget v5, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    aget v26, v14, v7

    add-int v5, v5, v26

    invoke-virtual {v1, v15, v4, v5}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v4

    if-lez v4, :cond_25

    .line 336
    const/4 v4, 0x1

    move v10, v4

    .line 334
    .end local v14    # "n":[I
    :cond_25
    add-int/lit8 v13, v13, 0x1

    const/high16 v4, 0x40800000    # 4.0f

    goto :goto_12

    .line 338
    :cond_26
    if-nez v10, :cond_28

    .line 339
    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    iget v5, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    iget v6, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    const/4 v7, 0x0

    invoke-virtual {v1, v4, v5, v6, v7}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 340
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    .line 341
    .restart local v4    # "lastIdx":I
    if-ge v3, v4, :cond_27

    .line 342
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    invoke-virtual {v5, v3, v6}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 344
    :cond_27
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 345
    invoke-virtual {v0, v8}, Lcom/EZdev/mc2/Gameplay;->releaseFire(Lcom/EZdev/mc2/Gameplay$ActiveFire;)V

    .line 346
    goto/16 :goto_16

    .line 349
    .end local v4    # "lastIdx":I
    :cond_28
    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->life:F

    sub-float/2addr v4, v2

    iput v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->life:F

    .line 350
    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->spreadTimer:F

    sub-float/2addr v4, v2

    iput v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->spreadTimer:F

    .line 352
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v4}, Ljava/util/Random;->nextFloat()F

    move-result v4

    const v5, 0x3c23d70a    # 0.01f

    cmpg-float v4, v4, v5

    if-gez v4, :cond_29

    .line 353
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    iget v5, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    int-to-float v5, v5

    const/high16 v7, 0x3f000000    # 0.5f

    add-float/2addr v5, v7

    iget v11, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    int-to-float v11, v11

    add-float/2addr v11, v7

    iget v12, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    int-to-float v12, v12

    add-float/2addr v12, v7

    const/4 v7, 0x6

    invoke-virtual {v0, v5, v11, v12, v7}, Lcom/EZdev/mc2/Gameplay;->obtainParticle(FFFB)Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 356
    :cond_29
    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->life:F

    cmpg-float v4, v4, v9

    if-gtz v4, :cond_2b

    .line 357
    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    iget v5, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    iget v6, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    const/4 v7, 0x0

    invoke-virtual {v1, v4, v5, v6, v7}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 358
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    .line 359
    .restart local v4    # "lastIdx":I
    if-ge v3, v4, :cond_2a

    .line 360
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/EZdev/mc2/Gameplay$ActiveFire;

    invoke-virtual {v5, v3, v6}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 362
    :cond_2a
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 363
    invoke-virtual {v0, v8}, Lcom/EZdev/mc2/Gameplay;->releaseFire(Lcom/EZdev/mc2/Gameplay$ActiveFire;)V

    .line 364
    goto/16 :goto_16

    .line 367
    .end local v4    # "lastIdx":I
    :cond_2b
    iget v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->spreadTimer:F

    cmpg-float v4, v4, v9

    if-gtz v4, :cond_30

    .line 368
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v4}, Ljava/util/Random;->nextFloat()F

    move-result v4

    const/high16 v5, 0x3f800000    # 1.0f

    mul-float/2addr v4, v5

    const/high16 v7, 0x3f000000    # 0.5f

    add-float/2addr v4, v7

    iput v4, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->spreadTimer:F

    .line 369
    const/4 v4, 0x0

    .local v4, "attempts":I
    :goto_13
    if-ge v4, v6, :cond_30

    .line 370
    iget-object v7, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v7, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v7

    const/4 v11, 0x1

    sub-int/2addr v7, v11

    .line 371
    .local v7, "dx":I
    iget-object v12, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    const/4 v13, 0x6

    invoke-virtual {v12, v13}, Ljava/util/Random;->nextInt(I)I

    move-result v12

    sub-int/2addr v12, v11

    .line 372
    .local v12, "dy":I
    iget-object v13, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v13, v6}, Ljava/util/Random;->nextInt(I)I

    move-result v13

    sub-int/2addr v13, v11

    .line 373
    .local v13, "dz":I
    iget v11, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->x:I

    add-int/2addr v11, v7

    .local v11, "nx":I
    iget v14, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->y:I

    add-int/2addr v14, v12

    .local v14, "ny":I
    iget v15, v8, Lcom/EZdev/mc2/Gameplay$ActiveFire;->z:I

    add-int/2addr v15, v13

    .line 374
    .local v15, "nz":I
    invoke-virtual {v1, v11, v14, v15}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v5

    .line 375
    .local v5, "blockType":B
    if-eq v5, v6, :cond_2c

    const/4 v6, 0x4

    if-ne v5, v6, :cond_2f

    .line 376
    :cond_2c
    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v6

    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v27

    add-int v6, v6, v27

    invoke-static {v13}, Ljava/lang/Math;->abs(I)I

    move-result v27

    add-int v6, v6, v27

    int-to-float v6, v6

    const v27, 0x3e19999a    # 0.15f

    mul-float v6, v6, v27

    .line 377
    .local v6, "distancePenalty":F
    const/4 v9, 0x4

    if-ne v5, v9, :cond_2d

    const v9, 0x3f666666    # 0.9f

    goto :goto_14

    :cond_2d
    const v9, 0x3f19999a    # 0.6f

    .line 378
    .local v9, "baseChance":F
    :goto_14
    move/from16 v28, v5

    .end local v5    # "blockType":B
    .local v28, "blockType":B
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v5}, Ljava/util/Random;->nextFloat()F

    move-result v5

    sub-float v29, v9, v6

    cmpg-float v5, v5, v29

    if-gez v5, :cond_2e

    .line 379
    const/4 v5, 0x6

    invoke-virtual {v1, v11, v14, v15, v5}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 380
    iget-object v5, v0, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    move/from16 v29, v6

    .end local v6    # "distancePenalty":F
    .local v29, "distancePenalty":F
    invoke-virtual {v0, v11, v14, v15}, Lcom/EZdev/mc2/Gameplay;->obtainFire(III)Lcom/EZdev/mc2/Gameplay$ActiveFire;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_15

    .line 378
    .end local v29    # "distancePenalty":F
    .restart local v6    # "distancePenalty":F
    :cond_2e
    move/from16 v29, v6

    .line 369
    .end local v6    # "distancePenalty":F
    .end local v7    # "dx":I
    .end local v9    # "baseChance":F
    .end local v11    # "nx":I
    .end local v12    # "dy":I
    .end local v13    # "dz":I
    .end local v14    # "ny":I
    .end local v15    # "nz":I
    .end local v28    # "blockType":B
    :cond_2f
    :goto_15
    add-int/lit8 v4, v4, 0x1

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x3

    const/4 v9, 0x0

    goto :goto_13

    .line 319
    .end local v4    # "attempts":I
    .end local v8    # "fire":Lcom/EZdev/mc2/Gameplay$ActiveFire;
    .end local v10    # "hasSupport":Z
    :cond_30
    :goto_16
    add-int/lit8 v3, v3, -0x1

    const/high16 v4, 0x40800000    # 4.0f

    const/4 v9, 0x0

    goto/16 :goto_11

    :cond_31
    nop

    .line 387
    .end local v3    # "i":I
    iget-object v3, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v3}, Ljava/util/Random;->nextFloat()F

    move-result v3

    const v4, 0x3dcccccd    # 0.1f

    cmpg-float v3, v3, v4

    if-gez v3, :cond_32

    .line 388
    iget v3, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-int v3, v3

    .local v3, "px":I
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    float-to-int v4, v4

    sub-int/2addr v4, v7

    .local v4, "py":I
    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-int v5, v5

    .line 389
    .local v5, "pz":I
    invoke-virtual {v1, v3, v4, v5}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v6

    .line 390
    .local v6, "b":B
    const/16 v8, 0x8

    if-ne v6, v8, :cond_32

    add-int/lit8 v8, v4, -0x1

    invoke-virtual {v1, v3, v8, v5}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v8

    if-nez v8, :cond_32

    .line 391
    const/4 v8, 0x0

    invoke-virtual {v1, v3, v4, v5, v8}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 392
    add-int/lit8 v8, v4, -0x1

    const/16 v9, 0x8

    invoke-virtual {v1, v3, v8, v5, v9}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 397
    .end local v3    # "px":I
    .end local v4    # "py":I
    .end local v5    # "pz":I
    .end local v6    # "b":B
    :cond_32
    const/4 v3, 0x0

    .line 398
    .local v3, "inWater":Z
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-double v8, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-int v6, v8

    invoke-virtual {v1, v4, v5, v6}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v4

    .line 399
    .local v4, "blockAtFeet":B
    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const/high16 v8, 0x3fc00000    # 1.5f

    add-float/2addr v6, v8

    float-to-double v8, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-int v6, v8

    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-int v8, v8

    invoke-virtual {v1, v5, v6, v8}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v5

    .line 400
    .local v5, "blockAtHead":B
    const/4 v6, 0x7

    if-eq v4, v6, :cond_33

    if-ne v5, v6, :cond_34

    :cond_33
    const/4 v3, 0x1

    .line 402
    :cond_34
    iget-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    if-eqz v6, :cond_35

    const/high16 v6, 0x3fc00000    # 1.5f

    goto :goto_17

    :cond_35
    const v6, 0x3fe66666    # 1.8f

    :goto_17
    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    .line 404
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v9, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-direct {v0, v1, v6, v8, v9}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v6

    if-eqz v6, :cond_36

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const/high16 v8, 0x40200000    # 2.5f

    mul-float/2addr v8, v2

    add-float/2addr v6, v8

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 406
    :cond_36
    iget-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->wantsToJump:Z

    if-eqz v6, :cond_39

    .line 407
    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    if-eqz v8, :cond_37

    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-eqz v8, :cond_37

    .line 408
    const/high16 v8, 0x41200000    # 10.0f

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    goto :goto_18

    .line 409
    :cond_37
    if-eqz v3, :cond_38

    .line 410
    const/high16 v8, 0x40800000    # 4.0f

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    goto :goto_18

    .line 411
    :cond_38
    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    if-eqz v8, :cond_3b

    .line 412
    const/high16 v8, 0x41080000    # 8.5f

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 413
    const/4 v8, 0x0

    iput-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    goto :goto_18

    .line 415
    :cond_39
    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    if-eqz v8, :cond_3b

    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-eqz v8, :cond_3b

    .line 416
    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    if-eqz v8, :cond_3a

    const/high16 v8, -0x3ee00000    # -10.0f

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    goto :goto_18

    .line 417
    :cond_3a
    const/4 v8, 0x0

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 420
    :cond_3b
    :goto_18
    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    const/high16 v9, -0x3e600000    # -20.0f

    if-eqz v8, :cond_3c

    iget-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v8, :cond_3f

    .line 421
    :cond_3c
    if-eqz v3, :cond_3e

    .line 422
    if-nez v6, :cond_3d

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    const/high16 v8, 0x40a00000    # 5.0f

    mul-float v10, v2, v8

    sub-float/2addr v6, v10

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 423
    :cond_3d
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    const/high16 v8, -0x3fc00000    # -3.0f

    cmpg-float v6, v6, v8

    if-gez v6, :cond_3f

    const/high16 v6, -0x3fc00000    # -3.0f

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    goto :goto_19

    .line 425
    :cond_3e
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    const/high16 v8, 0x41c80000    # 25.0f

    mul-float/2addr v8, v2

    sub-float/2addr v6, v8

    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 426
    cmpg-float v6, v6, v9

    if-gez v6, :cond_3f

    iput v9, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 430
    :cond_3f
    :goto_19
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    mul-float/2addr v8, v2

    add-float/2addr v6, v8

    .line 431
    .local v6, "nextY":F
    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-direct {v0, v1, v8, v6, v10}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v8

    if-nez v8, :cond_40

    .line 432
    iput v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 433
    const/4 v8, 0x0

    iput-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    goto :goto_1b

    .line 435
    :cond_40
    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    const/4 v10, 0x0

    cmpg-float v8, v8, v10

    if-gez v8, :cond_41

    .line 436
    const/4 v8, 0x1

    iput-boolean v8, v0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    .line 437
    float-to-double v10, v6

    invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D

    move-result-wide v10

    double-to-float v8, v10

    const v10, 0x3f8020c5    # 1.001f

    add-float/2addr v8, v10

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    goto :goto_1a

    .line 439
    :cond_41
    iget v8, v0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v8, v6

    float-to-double v10, v8

    invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D

    move-result-wide v10

    double-to-float v8, v10

    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    sub-float/2addr v8, v10

    const v10, 0x3a83126f    # 0.001f

    sub-float/2addr v8, v10

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 441
    :goto_1a
    const/4 v8, 0x0

    iput v8, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 444
    :goto_1b
    const/high16 v8, 0x40a00000    # 5.0f

    mul-float/2addr v8, v2

    .line 445
    .local v8, "speed":F
    if-eqz v3, :cond_42

    const/high16 v10, 0x40200000    # 2.5f

    mul-float v8, v2, v10

    goto :goto_1c

    .line 446
    :cond_42
    iget-boolean v10, v0, Lcom/EZdev/mc2/Gameplay;->isSprinting:Z

    if-eqz v10, :cond_43

    const/high16 v10, 0x41000000    # 8.0f

    mul-float v8, v2, v10

    goto :goto_1c

    .line 447
    :cond_43
    iget-boolean v10, v0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    if-eqz v10, :cond_44

    const/high16 v10, 0x40000000    # 2.0f

    mul-float v8, v2, v10

    .line 448
    :cond_44
    :goto_1c
    iget-boolean v10, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    if-eqz v10, :cond_45

    iget-boolean v10, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-eqz v10, :cond_45

    const/high16 v10, 0x41200000    # 10.0f

    mul-float v8, v2, v10

    .line 450
    :cond_45
    iget v10, v0, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v10

    double-to-float v10, v10

    .line 451
    .local v10, "yawRad":F
    float-to-double v11, v10

    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v11, v11

    .line 452
    .local v11, "sinYaw":F
    float-to-double v12, v10

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    double-to-float v12, v12

    .line 454
    .local v12, "cosYaw":F
    move v13, v11

    .line 455
    .local v13, "dirX":F
    neg-float v14, v12

    .line 456
    .local v14, "dirZ":F
    move v15, v12

    .line 457
    .local v15, "rightX":F
    move/from16 v16, v11

    .line 459
    .local v16, "rightZ":F
    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->joyMoveY:F

    neg-float v9, v7

    mul-float/2addr v9, v13

    move/from16 v18, v4

    .end local v4    # "blockAtFeet":B
    .local v18, "blockAtFeet":B
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->joyMoveX:F

    mul-float v21, v15, v4

    add-float v9, v9, v21

    mul-float/2addr v9, v8

    .line 460
    .local v9, "moveX":F
    move/from16 v21, v5

    .end local v5    # "blockAtHead":B
    .local v21, "blockAtHead":B
    neg-float v5, v7

    mul-float/2addr v5, v14

    mul-float v23, v16, v4

    add-float v5, v5, v23

    mul-float/2addr v5, v8

    .line 462
    .local v5, "moveZ":F
    move/from16 v23, v6

    .end local v6    # "nextY":F
    .local v23, "nextY":F
    iget-boolean v6, v0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    if-eqz v6, :cond_48

    const/4 v6, 0x0

    cmpl-float v4, v4, v6

    if-nez v4, :cond_46

    cmpl-float v4, v7, v6

    if-eqz v4, :cond_48

    .line 463
    :cond_46
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    add-float/2addr v4, v9

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_47

    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    add-float/2addr v7, v5

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-eqz v4, :cond_48

    .line 464
    :cond_47
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    add-float/2addr v4, v9

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const v7, 0x3f8ccccd    # 1.1f

    add-float/2addr v6, v7

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_48

    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const v7, 0x3f8ccccd    # 1.1f

    add-float/2addr v6, v7

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    add-float/2addr v7, v5

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_48

    .line 465
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const v6, 0x3f8ccccd    # 1.1f

    add-float/2addr v4, v6

    iput v4, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 470
    :cond_48
    iget-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->onGround:Z

    if-eqz v4, :cond_4a

    iget-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    if-eqz v4, :cond_4a

    if-nez v3, :cond_4a

    .line 471
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    add-float/2addr v4, v9

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const/high16 v7, 0x3f000000    # 0.5f

    sub-float/2addr v6, v7

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_49

    const/4 v9, 0x0

    .line 472
    :cond_49
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const/high16 v7, 0x3f000000    # 0.5f

    sub-float/2addr v6, v7

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    add-float/2addr v7, v5

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_4a

    const/4 v5, 0x0

    .line 475
    :cond_4a
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    add-float/2addr v4, v9

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_4b

    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    add-float/2addr v4, v9

    iput v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    .line 476
    :cond_4b
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    add-float/2addr v7, v5

    invoke-direct {v0, v1, v4, v6, v7}, Lcom/EZdev/mc2/Gameplay;->checkCollision(Lcom/EZdev/mc2/WorldLogic;FFF)Z

    move-result v4

    if-nez v4, :cond_4c

    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    add-float/2addr v4, v5

    iput v4, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    .line 478
    :cond_4c
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const/high16 v6, -0x3e600000    # -20.0f

    cmpg-float v4, v4, v6

    if-gez v4, :cond_4d

    const/4 v4, 0x0

    iput-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->hasSpawned:Z

    const/high16 v4, 0x42c80000    # 100.0f

    iput v4, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    const/4 v4, 0x0

    iput v4, v0, Lcom/EZdev/mc2/Gameplay;->velocityY:F

    .line 481
    :cond_4d
    iget-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    if-eqz v4, :cond_59

    iget-boolean v4, v0, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v4, :cond_59

    .line 482
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v4, v6

    const v6, 0x3e4ccccd    # 0.2f

    sub-float/2addr v4, v6

    .line 483
    .local v4, "eyeHeight":F
    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->camX:F

    const/high16 v7, 0x40400000    # 3.0f

    mul-float v17, v13, v7

    add-float v6, v6, v17

    move/from16 v17, v8

    .end local v8    # "speed":F
    .local v17, "speed":F
    float-to-double v7, v6

    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v6, v6

    .line 484
    .local v6, "bx":I
    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v7

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v7, v7

    .line 485
    .local v7, "dirY":F
    const/high16 v8, 0x40400000    # 3.0f

    mul-float v22, v7, v8

    add-float v8, v4, v22

    move/from16 v22, v3

    move/from16 v28, v4

    .end local v3    # "inWater":Z
    .end local v4    # "eyeHeight":F
    .local v22, "inWater":Z
    .local v28, "eyeHeight":F
    float-to-double v3, v8

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    .line 486
    .local v3, "by":I
    iget v4, v0, Lcom/EZdev/mc2/Gameplay;->camZ:F

    const/high16 v8, 0x40400000    # 3.0f

    mul-float/2addr v8, v14

    add-float/2addr v4, v8

    move v8, v3

    .end local v3    # "by":I
    .local v8, "by":I
    float-to-double v3, v4

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    .line 489
    .local v3, "bz":I
    iget-object v4, v0, Lcom/EZdev/mc2/Gameplay;->raycastResult:[I

    invoke-virtual {v1, v0, v4}, Lcom/EZdev/mc2/WorldLogic;->raycastBlock(Lcom/EZdev/mc2/Gameplay;[I)[I

    move-result-object v4

    .line 490
    .local v4, "hit":[I
    move/from16 v24, v3

    .end local v3    # "bz":I
    .local v24, "bz":I
    if-eqz v4, :cond_58

    .line 491
    const/16 v19, 0x0

    aget v3, v4, v19

    move/from16 v30, v5

    .end local v5    # "moveZ":F
    .local v30, "moveZ":F
    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    if-ne v3, v5, :cond_57

    move/from16 v31, v6

    const/4 v3, 0x1

    .end local v6    # "bx":I
    .local v31, "bx":I
    aget v6, v4, v3

    iget v3, v0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    if-ne v6, v3, :cond_56

    move/from16 v32, v7

    const/4 v6, 0x2

    .end local v7    # "dirY":F
    .local v32, "dirY":F
    aget v7, v4, v6

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    if-ne v7, v6, :cond_55

    .line 492
    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    add-float/2addr v7, v2

    iput v7, v0, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    .line 493
    invoke-virtual {v1, v5, v3, v6}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v3

    .line 494
    .local v3, "hitType":B
    const/high16 v5, 0x3f800000    # 1.0f

    .line 495
    .local v5, "requiredTime":F
    const/4 v6, 0x1

    if-eq v3, v6, :cond_4e

    const/16 v6, 0xa

    if-eq v3, v6, :cond_4e

    const/4 v6, 0x4

    if-ne v3, v6, :cond_4f

    :cond_4e
    goto :goto_1d

    .line 496
    :cond_4f
    const/4 v6, 0x2

    if-ne v3, v6, :cond_50

    const/high16 v5, 0x40000000    # 2.0f

    goto :goto_1e

    .line 497
    :cond_50
    const/4 v6, 0x3

    if-ne v3, v6, :cond_51

    const/high16 v5, 0x3fc00000    # 1.5f

    goto :goto_1e

    .line 495
    :goto_1d
    const v5, 0x3e99999a    # 0.3f

    .line 500
    :cond_51
    :goto_1e
    iget-object v6, v0, Lcom/EZdev/mc2/Gameplay;->random:Ljava/security/SecureRandom;

    invoke-virtual {v6}, Ljava/util/Random;->nextFloat()F

    move-result v6

    const v7, 0x3dcccccd    # 0.1f

    cmpg-float v6, v6, v7

    if-gez v6, :cond_52

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    int-to-float v6, v6

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    int-to-float v7, v7

    move/from16 v25, v2

    .end local v2    # "dt":F
    .local v25, "dt":F
    iget v2, v0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    int-to-float v2, v2

    invoke-virtual {v0, v6, v7, v2, v3}, Lcom/EZdev/mc2/Gameplay;->addBlockParticles(FFFB)V

    goto :goto_1f

    .end local v25    # "dt":F
    .restart local v2    # "dt":F
    :cond_52
    move/from16 v25, v2

    .line 502
    .end local v2    # "dt":F
    .restart local v25    # "dt":F
    :goto_1f
    iget v2, v0, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    cmpl-float v2, v2, v5

    if-ltz v2, :cond_54

    .line 503
    iget v2, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    iget v7, v0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    move/from16 p1, v5

    const/4 v5, 0x0

    .end local v5    # "requiredTime":F
    .local p1, "requiredTime":F
    invoke-virtual {v1, v2, v6, v7, v5}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 504
    iget v2, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    int-to-float v2, v2

    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    int-to-float v5, v5

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    int-to-float v6, v6

    invoke-virtual {v0, v2, v5, v6, v3}, Lcom/EZdev/mc2/Gameplay;->addBlockParticles(FFFB)V

    .line 505
    iget v2, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    iget v5, v0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    iget v6, v0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    invoke-virtual {v1, v2, v5, v6, v3}, Lcom/EZdev/mc2/WorldLogic;->spawnItemEntity(IIIB)V

    .line 506
    iget-object v2, v0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v2, :cond_53

    iget-object v2, v2, Lcom/EZdev/mc2/MainActivity;->soundManager:Lcom/EZdev/mc2/SoundManager;

    if-eqz v2, :cond_53

    invoke-virtual {v2, v3}, Lcom/EZdev/mc2/SoundManager;->playSoundForBlock(B)V

    .line 507
    :cond_53
    const/4 v2, 0x0

    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    .line 508
    const/4 v2, -0x1

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    goto :goto_20

    .line 502
    .end local p1    # "requiredTime":F
    .restart local v5    # "requiredTime":F
    :cond_54
    move/from16 p1, v5

    .line 510
    .end local v3    # "hitType":B
    .end local v5    # "requiredTime":F
    :goto_20
    goto :goto_22

    .line 491
    .end local v25    # "dt":F
    .restart local v2    # "dt":F
    :cond_55
    move/from16 v25, v2

    .end local v2    # "dt":F
    .restart local v25    # "dt":F
    goto :goto_21

    .end local v25    # "dt":F
    .end local v32    # "dirY":F
    .restart local v2    # "dt":F
    .restart local v7    # "dirY":F
    :cond_56
    move/from16 v25, v2

    move/from16 v32, v7

    .end local v2    # "dt":F
    .end local v7    # "dirY":F
    .restart local v25    # "dt":F
    .restart local v32    # "dirY":F
    goto :goto_21

    .end local v25    # "dt":F
    .end local v31    # "bx":I
    .end local v32    # "dirY":F
    .restart local v2    # "dt":F
    .restart local v6    # "bx":I
    .restart local v7    # "dirY":F
    :cond_57
    move/from16 v25, v2

    move/from16 v31, v6

    move/from16 v32, v7

    .line 511
    .end local v2    # "dt":F
    .end local v6    # "bx":I
    .end local v7    # "dirY":F
    .restart local v25    # "dt":F
    .restart local v31    # "bx":I
    .restart local v32    # "dirY":F
    :goto_21
    const/4 v2, 0x0

    aget v2, v4, v2

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    const/4 v2, 0x1

    aget v2, v4, v2

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->targetY:I

    const/4 v2, 0x2

    aget v2, v4, v2

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    .line 512
    const/4 v2, 0x0

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    goto :goto_22

    .line 515
    .end local v25    # "dt":F
    .end local v30    # "moveZ":F
    .end local v31    # "bx":I
    .end local v32    # "dirY":F
    .restart local v2    # "dt":F
    .local v5, "moveZ":F
    .restart local v6    # "bx":I
    .restart local v7    # "dirY":F
    :cond_58
    move/from16 v25, v2

    move/from16 v30, v5

    move/from16 v31, v6

    move/from16 v32, v7

    const/4 v2, 0x0

    .end local v2    # "dt":F
    .end local v5    # "moveZ":F
    .end local v6    # "bx":I
    .end local v7    # "dirY":F
    .restart local v25    # "dt":F
    .restart local v30    # "moveZ":F
    .restart local v31    # "bx":I
    .restart local v32    # "dirY":F
    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    .line 516
    const/4 v2, -0x1

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->targetX:I

    goto :goto_22

    .line 481
    .end local v4    # "hit":[I
    .end local v17    # "speed":F
    .end local v22    # "inWater":Z
    .end local v24    # "bz":I
    .end local v25    # "dt":F
    .end local v28    # "eyeHeight":F
    .end local v30    # "moveZ":F
    .end local v31    # "bx":I
    .end local v32    # "dirY":F
    .restart local v2    # "dt":F
    .local v3, "inWater":Z
    .restart local v5    # "moveZ":F
    .local v8, "speed":F
    :cond_59
    move/from16 v25, v2

    move/from16 v22, v3

    move/from16 v30, v5

    move/from16 v17, v8

    .line 519
    .end local v2    # "dt":F
    .end local v3    # "inWater":Z
    .end local v5    # "moveZ":F
    .end local v8    # "speed":F
    .restart local v17    # "speed":F
    .restart local v22    # "inWater":Z
    .restart local v25    # "dt":F
    .restart local v30    # "moveZ":F
    :goto_22
    return-void
.end method
