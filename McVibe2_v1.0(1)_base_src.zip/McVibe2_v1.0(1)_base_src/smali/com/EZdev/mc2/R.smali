.class public final Lcom/EZdev/mc2/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/EZdev/mc2/R$color;,
        Lcom/EZdev/mc2/R$drawable;,
        Lcom/EZdev/mc2/R$mipmap;,
        Lcom/EZdev/mc2/R$raw;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
