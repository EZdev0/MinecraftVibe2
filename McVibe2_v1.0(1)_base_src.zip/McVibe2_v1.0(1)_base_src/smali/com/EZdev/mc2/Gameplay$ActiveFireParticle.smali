.class public Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
.super Ljava/lang/Object;
.source "Gameplay.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/Gameplay;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ActiveFireParticle"
.end annotation


# instance fields
.field public life:F

.field final synthetic this$0:Lcom/EZdev/mc2/Gameplay;

.field public type:B

.field public vx:F

.field public vy:F

.field public vz:F

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method public constructor <init>(Lcom/EZdev/mc2/Gameplay;FFFB)V
    .locals 0
    .param p1, "this$0"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F
    .param p5, "type"    # B

    .line 88
    iput-object p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0, p2, p3, p4, p5}, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->init(FFFB)V

    return-void
.end method

.method public constructor <init>(Lcom/EZdev/mc2/Gameplay;FFFF)V
    .locals 0
    .param p1, "this$0"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F
    .param p5, "intensity"    # F

    .line 97
    iput-object p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0, p2, p3, p4, p5}, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->init(FFFF)V

    return-void
.end method


# virtual methods
.method public init(FFFB)V
    .locals 4
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "type"    # B

    .line 90
    iput p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    iput p2, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    iput p3, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    .line 91
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v1, 0x3f000000    # 0.5f

    sub-float/2addr v0, v1

    const/high16 v2, 0x40c00000    # 6.0f

    mul-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vx:F

    .line 92
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    mul-float/2addr v0, v2

    const/high16 v3, 0x40400000    # 3.0f

    add-float/2addr v0, v3

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    .line 93
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    sub-float/2addr v0, v1

    mul-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vz:F

    .line 94
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    mul-float/2addr v0, v1

    const v1, 0x3f4ccccd    # 0.8f

    add-float/2addr v0, v1

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->life:F

    .line 95
    iput-byte p4, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->type:B

    .line 96
    return-void
.end method

.method public init(FFFF)V
    .locals 2
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "intensity"    # F

    .line 99
    iput p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    iput p2, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    iput p3, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    .line 100
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v1, 0x3f000000    # 0.5f

    sub-float/2addr v0, v1

    mul-float/2addr v0, p4

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vx:F

    .line 101
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    sub-float/2addr v0, v1

    mul-float/2addr v0, p4

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vy:F

    .line 102
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    sub-float/2addr v0, v1

    mul-float/2addr v0, p4

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->vz:F

    .line 103
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-static {v0}, Lcom/EZdev/mc2/Gameplay;->-$$Nest$fgetrandom(Lcom/EZdev/mc2/Gameplay;)Ljava/security/SecureRandom;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    const/high16 v1, 0x40400000    # 3.0f

    mul-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v0, v1

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->life:F

    .line 104
    const/16 v0, 0x63

    iput-byte v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->type:B

    .line 105
    return-void
.end method
