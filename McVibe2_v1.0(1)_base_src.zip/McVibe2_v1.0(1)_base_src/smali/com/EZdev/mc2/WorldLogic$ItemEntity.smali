.class public Lcom/EZdev/mc2/WorldLogic$ItemEntity;
.super Ljava/lang/Object;
.source "WorldLogic.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/WorldLogic;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ItemEntity"
.end annotation


# instance fields
.field public count:I

.field public hoverOffset:F

.field public life:F

.field public pickupDelay:F

.field final synthetic this$0:Lcom/EZdev/mc2/WorldLogic;

.field public type:B

.field public vy:F

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method public constructor <init>(Lcom/EZdev/mc2/WorldLogic;FFFB)V
    .locals 2
    .param p1, "this$0"    # Lcom/EZdev/mc2/WorldLogic;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F
    .param p5, "type"    # B

    .line 39
    iput-object p1, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->this$0:Lcom/EZdev/mc2/WorldLogic;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    const/high16 v0, 0x43960000    # 300.0f

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    .line 34
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->hoverOffset:F

    .line 35
    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->vy:F

    .line 36
    const/4 v0, 0x1

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    .line 37
    const/high16 v1, 0x3f000000    # 0.5f

    iput v1, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->pickupDelay:F

    .line 40
    iput p2, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    iput p3, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    iput p4, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    iput-byte p5, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    .line 41
    return-void
.end method

.method public constructor <init>(Lcom/EZdev/mc2/WorldLogic;FFFBI)V
    .locals 1
    .param p1, "this$0"    # Lcom/EZdev/mc2/WorldLogic;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F
    .param p5, "type"    # B
    .param p6, "count"    # I

    .line 42
    iput-object p1, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->this$0:Lcom/EZdev/mc2/WorldLogic;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    const/high16 v0, 0x43960000    # 300.0f

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    .line 34
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->hoverOffset:F

    .line 35
    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->vy:F

    .line 36
    const/4 v0, 0x1

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    .line 37
    const/high16 v0, 0x3f000000    # 0.5f

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->pickupDelay:F

    .line 43
    iput p2, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    iput p3, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    iput p4, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    iput-byte p5, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    iput p6, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    .line 44
    return-void
.end method


# virtual methods
.method public update(F)V
    .locals 7
    .param p1, "dt"    # F

    .line 46
    iget v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->hoverOffset:F

    add-float/2addr v0, p1

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->hoverOffset:F

    .line 47
    iget v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    sub-float/2addr v0, p1

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    .line 48
    iget v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->pickupDelay:F

    const/4 v1, 0x0

    cmpl-float v2, v0, v1

    if-lez v2, :cond_0

    sub-float/2addr v0, p1

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->pickupDelay:F

    .line 49
    :cond_0
    iget v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->vy:F

    const/high16 v2, 0x41700000    # 15.0f

    mul-float/2addr v2, p1

    sub-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->vy:F

    .line 50
    iget v2, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    mul-float/2addr v0, p1

    add-float/2addr v2, v0

    .line 51
    .local v2, "nextY":F
    iget-object v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->this$0:Lcom/EZdev/mc2/WorldLogic;

    iget v3, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    float-to-double v4, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    iget v5, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    invoke-virtual {v0, v3, v4, v5}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v0

    if-nez v0, :cond_1

    .line 52
    iput v2, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    goto :goto_0

    .line 54
    :cond_1
    iput v1, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->vy:F

    .line 55
    float-to-double v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v0, v1

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    .line 58
    :goto_0
    return-void
.end method
