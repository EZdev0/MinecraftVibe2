.class public final synthetic Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnCompletionListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/MusicManager;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/MusicManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda0;->f$0:Lcom/EZdev/mc2/MusicManager;

    return-void
.end method


# virtual methods
.method public final onCompletion(Landroid/media/MediaPlayer;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda0;->f$0:Lcom/EZdev/mc2/MusicManager;

    invoke-static {v0, p1}, Lcom/EZdev/mc2/MusicManager;->$r8$lambda$xhxcMOcG7a9uEcOtvyvh-hoihQU(Lcom/EZdev/mc2/MusicManager;Landroid/media/MediaPlayer;)V

    return-void
.end method
