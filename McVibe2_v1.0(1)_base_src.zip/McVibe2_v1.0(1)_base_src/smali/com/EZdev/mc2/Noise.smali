.class public Lcom/EZdev/mc2/Noise;
.super Ljava/lang/Object;
.source "Noise.java"


# static fields
.field private static final p:[I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 6
    const/16 v0, 0x200

    new-array v0, v0, [I

    sput-object v0, Lcom/EZdev/mc2/Noise;->p:[I

    .line 9
    const-wide/16 v0, 0x539

    invoke-static {v0, v1}, Lcom/EZdev/mc2/Noise;->init(J)V

    .line 10
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static fade(F)F
    .locals 3
    .param p0, "t"    # F

    .line 18
    mul-float v0, p0, p0

    mul-float/2addr v0, p0

    const/high16 v1, 0x40c00000    # 6.0f

    mul-float/2addr v1, p0

    const/high16 v2, 0x41700000    # 15.0f

    sub-float/2addr v1, v2

    mul-float/2addr v1, p0

    const/high16 v2, 0x41200000    # 10.0f

    add-float/2addr v1, v2

    mul-float/2addr v0, v1

    return v0
.end method

.method public static fbm2(FFI)F
    .locals 7
    .param p0, "x"    # F
    .param p1, "y"    # F
    .param p2, "octaves"    # I

    .line 43
    const/4 v0, 0x0

    .line 44
    .local v0, "total":F
    const/high16 v1, 0x3f800000    # 1.0f

    .line 45
    .local v1, "frequency":F
    const/high16 v2, 0x3f800000    # 1.0f

    .line 46
    .local v2, "amplitude":F
    const/4 v3, 0x0

    .line 47
    .local v3, "maxValue":F
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    if-ge v4, p2, :cond_0

    .line 48
    mul-float v5, p0, v1

    mul-float v6, p1, v1

    invoke-static {v5, v6}, Lcom/EZdev/mc2/Noise;->simplex2(FF)F

    move-result v5

    mul-float/2addr v5, v2

    add-float/2addr v0, v5

    .line 49
    add-float/2addr v3, v2

    .line 50
    const/high16 v5, 0x3f000000    # 0.5f

    mul-float/2addr v2, v5

    .line 51
    const/high16 v5, 0x40000000    # 2.0f

    mul-float/2addr v1, v5

    .line 47
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 53
    .end local v4    # "i":I
    div-float v4, v0, v3

    return v4
.end method

.method public static fbm3(FFFI)F
    .locals 8
    .param p0, "x"    # F
    .param p1, "y"    # F
    .param p2, "z"    # F
    .param p3, "octaves"    # I

    .line 58
    const/4 v0, 0x0

    .line 59
    .local v0, "total":F
    const/high16 v1, 0x3f800000    # 1.0f

    .line 60
    .local v1, "frequency":F
    const/high16 v2, 0x3f800000    # 1.0f

    .line 61
    .local v2, "amplitude":F
    const/4 v3, 0x0

    .line 62
    .local v3, "maxValue":F
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    if-ge v4, p3, :cond_0

    .line 63
    mul-float v5, p0, v1

    mul-float v6, p1, v1

    mul-float v7, p2, v1

    invoke-static {v5, v6, v7}, Lcom/EZdev/mc2/Noise;->simplex3(FFF)F

    move-result v5

    mul-float/2addr v5, v2

    add-float/2addr v0, v5

    .line 64
    add-float/2addr v3, v2

    .line 65
    const/high16 v5, 0x3f000000    # 0.5f

    mul-float/2addr v2, v5

    .line 66
    const/high16 v5, 0x40000000    # 2.0f

    mul-float/2addr v1, v5

    .line 62
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 68
    .end local v4    # "i":I
    div-float v4, v0, v3

    return v4
.end method

.method private static grad(IFFF)F
    .locals 5
    .param p0, "hash"    # I
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 21
    and-int/lit8 v0, p0, 0xf

    .line 22
    .local v0, "h":I
    const/16 v1, 0x8

    if-ge v0, v1, :cond_0

    move v1, p1

    goto :goto_0

    :cond_0
    move v1, p2

    .local v1, "u":F
    :goto_0
    const/4 v2, 0x4

    if-ge v0, v2, :cond_1

    move v2, p2

    goto :goto_2

    :cond_1
    const/16 v2, 0xc

    if-eq v0, v2, :cond_2

    const/16 v2, 0xe

    if-ne v0, v2, :cond_3

    :cond_2
    goto :goto_1

    :cond_3
    move v2, p3

    goto :goto_2

    :goto_1
    move v2, p1

    .line 23
    .local v2, "v":F
    :goto_2
    and-int/lit8 v3, v0, 0x1

    if-nez v3, :cond_4

    move v3, v1

    goto :goto_3

    :cond_4
    neg-float v3, v1

    :goto_3
    and-int/lit8 v4, v0, 0x2

    if-nez v4, :cond_5

    move v4, v2

    goto :goto_4

    :cond_5
    neg-float v4, v2

    :goto_4
    add-float/2addr v3, v4

    return v3
.end method

.method public static init(J)V
    .locals 6
    .param p0, "seed"    # J

    .line 13
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0, p0, p1}, Ljava/util/Random;-><init>(J)V

    .line 14
    .local v0, "random":Ljava/util/Random;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    const/16 v2, 0x100

    if-ge v1, v2, :cond_0

    sget-object v3, Lcom/EZdev/mc2/Noise;->p:[I

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    aput v2, v3, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 15
    .end local v1    # "i":I
    :cond_0
    const/4 v1, 0x0

    .restart local v1    # "i":I
    :goto_1
    if-ge v1, v2, :cond_1

    sget-object v3, Lcom/EZdev/mc2/Noise;->p:[I

    add-int/lit16 v4, v1, 0x100

    aget v5, v3, v1

    aput v5, v3, v4

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 16
    .end local v1    # "i":I
    :cond_1
    return-void
.end method

.method private static lerp(FFF)F
    .locals 1
    .param p0, "t"    # F
    .param p1, "a"    # F
    .param p2, "b"    # F

    .line 19
    sub-float v0, p2, p1

    mul-float/2addr v0, p0

    add-float/2addr v0, p1

    return v0
.end method

.method public static simplex2(FF)F
    .locals 1
    .param p0, "x"    # F
    .param p1, "y"    # F

    .line 38
    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lcom/EZdev/mc2/Noise;->simplex3(FFF)F

    move-result v0

    return v0
.end method

.method public static simplex3(FFF)F
    .locals 21
    .param p0, "x"    # F
    .param p1, "y"    # F
    .param p2, "z"    # F

    .line 27
    move/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    float-to-double v3, v0

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    and-int/lit16 v3, v3, 0xff

    .local v3, "X":I
    float-to-double v4, v1

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    and-int/lit16 v4, v4, 0xff

    .local v4, "Y":I
    float-to-double v5, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    and-int/lit16 v5, v5, 0xff

    .line 28
    .local v5, "Z":I
    float-to-double v6, v0

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-float v6, v6

    sub-float/2addr v0, v6

    .end local p0    # "x":F
    .local v0, "x":F
    float-to-double v6, v1

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-float v6, v6

    sub-float/2addr v1, v6

    .end local p1    # "y":F
    .local v1, "y":F
    float-to-double v6, v2

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-float v6, v6

    sub-float/2addr v2, v6

    .line 29
    .end local p2    # "z":F
    .local v2, "z":F
    invoke-static {v0}, Lcom/EZdev/mc2/Noise;->fade(F)F

    move-result v6

    .local v6, "u":F
    invoke-static {v1}, Lcom/EZdev/mc2/Noise;->fade(F)F

    move-result v7

    .local v7, "v":F
    invoke-static {v2}, Lcom/EZdev/mc2/Noise;->fade(F)F

    move-result v8

    .line 30
    .local v8, "w":F
    sget-object v9, Lcom/EZdev/mc2/Noise;->p:[I

    aget v10, v9, v3

    add-int/2addr v10, v4

    .local v10, "A":I
    aget v11, v9, v10

    add-int/2addr v11, v5

    .local v11, "AA":I
    add-int/lit8 v12, v10, 0x1

    aget v12, v9, v12

    add-int/2addr v12, v5

    .local v12, "AB":I
    add-int/lit8 v13, v3, 0x1

    aget v13, v9, v13

    add-int/2addr v13, v4

    .local v13, "B":I
    aget v14, v9, v13

    add-int/2addr v14, v5

    .local v14, "BA":I
    add-int/lit8 v15, v13, 0x1

    aget v15, v9, v15

    add-int/2addr v15, v5

    .line 31
    .local v15, "BB":I
    move/from16 v16, v3

    .end local v3    # "X":I
    .local v16, "X":I
    aget v3, v9, v11

    invoke-static {v3, v0, v1, v2}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v3

    move/from16 v17, v4

    .end local v4    # "Y":I
    .local v17, "Y":I
    aget v4, v9, v14

    const/high16 v18, 0x3f800000    # 1.0f

    move/from16 v19, v5

    .end local v5    # "Z":I
    .local v19, "Z":I
    sub-float v5, v0, v18

    invoke-static {v4, v5, v1, v2}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v4

    invoke-static {v6, v3, v4}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v3

    aget v4, v9, v12

    sub-float v5, v1, v18

    .line 32
    invoke-static {v4, v0, v5, v2}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v4

    aget v5, v9, v15

    move/from16 p0, v10

    .end local v10    # "A":I
    .local p0, "A":I
    sub-float v10, v0, v18

    move/from16 p1, v13

    .end local v13    # "B":I
    .local p1, "B":I
    sub-float v13, v1, v18

    invoke-static {v5, v10, v13, v2}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v5

    invoke-static {v6, v4, v5}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v4

    .line 31
    invoke-static {v7, v3, v4}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v3

    add-int/lit8 v4, v11, 0x1

    aget v4, v9, v4

    sub-float v5, v2, v18

    .line 33
    invoke-static {v4, v0, v1, v5}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v4

    add-int/lit8 v5, v14, 0x1

    aget v5, v9, v5

    sub-float v10, v0, v18

    sub-float v13, v2, v18

    invoke-static {v5, v10, v1, v13}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v5

    invoke-static {v6, v4, v5}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v4

    add-int/lit8 v5, v12, 0x1

    aget v5, v9, v5

    sub-float v10, v1, v18

    sub-float v13, v2, v18

    .line 34
    invoke-static {v5, v0, v10, v13}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v5

    add-int/lit8 v10, v15, 0x1

    aget v9, v9, v10

    sub-float v10, v0, v18

    sub-float v13, v1, v18

    move/from16 v20, v0

    .end local v0    # "x":F
    .local v20, "x":F
    sub-float v0, v2, v18

    invoke-static {v9, v10, v13, v0}, Lcom/EZdev/mc2/Noise;->grad(IFFF)F

    move-result v0

    invoke-static {v6, v5, v0}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v0

    .line 33
    invoke-static {v7, v4, v0}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v0

    .line 31
    invoke-static {v8, v3, v0}, Lcom/EZdev/mc2/Noise;->lerp(FFF)F

    move-result v0

    return v0
.end method
