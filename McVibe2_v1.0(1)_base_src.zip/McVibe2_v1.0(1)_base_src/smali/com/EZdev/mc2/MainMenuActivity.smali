.class public Lcom/EZdev/mc2/MainMenuActivity;
.super Landroid/app/Activity;
.source "MainMenuActivity.java"


# static fields
.field private static final TAG:Ljava/lang/String; = "MainMenuActivity"


# instance fields
.field private loadingPanel:Landroid/widget/LinearLayout;

.field private mainOverlay:Landroid/widget/FrameLayout;

.field private prefs:Landroid/content/SharedPreferences;

.field private root:Landroid/widget/LinearLayout;

.field private settingsPanel:Landroid/widget/LinearLayout;


# direct methods
.method public static synthetic $r8$lambda$1hMGZfO02V7opcNXmpnwL87ay1k(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$initMainMenuLayout$2(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$A3nwn4X4dhdHeqQqiGzFufKcpCk(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$createSettingsMenu$7(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$BT5SPgIIjc4QoEEXeRCbpD_NEt4(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/TextView;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupRenderDistanceControls$9(Landroid/widget/TextView;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Bam7xRt-pYfP1m7atdPLExeZs4o(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupSettingsToggles$12(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$cRbMrSdmBOoFA4sGhN5oa4JrDqA(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$initMainMenuLayout$6(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ez__3dmVgv7JIRwpJ4hRwC9wAxo(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$initMainMenuLayout$4(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$kwE8ivnV1HSUt7KfO1nqTYvNAzs(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/TextView;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupRenderDistanceControls$8(Landroid/widget/TextView;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$nkU2m4sOkjlY4cLjtH6SKl-0viQ(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$initMainMenuLayout$5(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$nlRFJy1gueZ1SEqY9H-YdoIjeUM(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupSettingsToggles$15(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$pi2cRYuvU4LRJ0AzsCd8_J3pjlI(Lcom/EZdev/mc2/MainMenuActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$showLoadingScreenAndOptimize$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$q4upwtPMrweI1AD6npRIdkE9LQo(Lcom/EZdev/mc2/MainMenuActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$initMainMenuLayout$3(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$qCPj8M5KBE1t-IYENbShhI_6w98(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupSettingsToggles$14(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$ubi9uUVPWb-DVl4VP_2z9KuNGs8(Lcom/EZdev/mc2/MainMenuActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$showLoadingScreenAndOptimize$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$wTgNWf5oqV6NHXHdXVJFeACoqIs(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupSettingsToggles$13(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$wdkYY2J5D-YFKBRnmL7XWo3SM-w(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupSettingsToggles$10(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$x9b85hID3x5YwAl-6ldJXc4gnjY(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/MainMenuActivity;->lambda$setupSettingsToggles$11(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 22
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;
    .locals 4
    .param p1, "text"    # Ljava/lang/String;

    .line 127
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 128
    .local v0, "b":Landroid/widget/Button;
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 129
    sget v1, Lcom/EZdev/mc2/R$color;->button_default:I

    invoke-virtual {p0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 130
    sget v1, Lcom/EZdev/mc2/R$color;->white:I

    invoke-virtual {p0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 131
    const/high16 v1, 0x41a00000    # 20.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 132
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x258

    const/16 v3, 0x78

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 133
    .local v1, "p":Landroid/widget/LinearLayout$LayoutParams;
    const/4 v2, 0x0

    const/16 v3, 0xf

    invoke-virtual {v1, v2, v3, v2, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 134
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 135
    return-object v0
.end method

.method private createSettingsMenu()V
    .locals 6

    .line 139
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    .line 140
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 141
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    sget v2, Lcom/EZdev/mc2/R$color;->settings_panel_background:I

    invoke-virtual {p0, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 142
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    const/16 v2, 0x3c

    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 143
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    .line 145
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 146
    .local v0, "title":Landroid/widget/TextView;
    const-string v1, "EINSTELLUNGEN"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 147
    sget v1, Lcom/EZdev/mc2/R$color;->white:I

    invoke-virtual {p0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 148
    const/high16 v1, 0x41d00000    # 26.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 149
    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 150
    iget-object v2, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 152
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->setupRenderDistanceControls()V

    .line 153
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->setupSettingsToggles()V

    .line 155
    const-string v2, "SCHLIESSEN"

    invoke-direct {p0, v2}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v2

    .line 156
    .local v2, "closeBtn":Landroid/widget/Button;
    sget v3, Lcom/EZdev/mc2/R$color;->button_secondary:I

    invoke-virtual {p0, v3}, Landroid/content/Context;->getColor(I)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 157
    new-instance v3, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda15;

    invoke-direct {v3, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda15;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 158
    iget-object v3, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 161
    new-instance v3, Landroid/widget/FrameLayout;

    invoke-direct {v3, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lcom/EZdev/mc2/MainMenuActivity;->mainOverlay:Landroid/widget/FrameLayout;

    .line 162
    iget-object v4, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 164
    new-instance v3, Landroid/widget/ScrollView;

    invoke-direct {v3, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 165
    .local v3, "scroll":Landroid/widget/ScrollView;
    iget-object v4, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 167
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x1

    invoke-direct {v4, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 168
    .local v4, "scrollParams":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v5, 0x32

    invoke-virtual {v4, v5, v5, v5, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 169
    iput v1, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 171
    const/16 v1, 0x8

    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 173
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->mainOverlay:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 175
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->mainOverlay:Landroid/widget/FrameLayout;

    invoke-virtual {p0, v1}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 176
    return-void
.end method

.method private hideSettings()V
    .locals 2

    .line 291
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 292
    return-void
.end method

.method private initMainMenuLayout()V
    .locals 7

    .line 79
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    .line 80
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 81
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    sget v1, Lcom/EZdev/mc2/R$color;->menu_background:I

    invoke-virtual {p0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 82
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 84
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 85
    .local v0, "title":Landroid/widget/TextView;
    const-string v2, "MINECRAFT 2 VIBE"

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 86
    sget v2, Lcom/EZdev/mc2/R$color;->white:I

    invoke-virtual {p0, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 87
    const/high16 v2, 0x42200000    # 40.0f

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 88
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 89
    const/4 v1, 0x0

    const/16 v2, 0x50

    invoke-virtual {v0, v1, v1, v1, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 90
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 92
    const-string v1, "NEUE WELT (SURVIVAL)"

    invoke-direct {p0, v1}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    .line 93
    .local v1, "btnSurvival":Landroid/widget/Button;
    new-instance v2, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda2;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 94
    iget-object v2, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 96
    const-string v2, "NEUE WELT (KREATIV)"

    invoke-direct {p0, v2}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v2

    .line 97
    .local v2, "btnCreative":Landroid/widget/Button;
    new-instance v3, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda3;

    invoke-direct {v3, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda3;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 98
    iget-object v3, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 100
    new-instance v3, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const-string v5, "world1"

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 101
    .local v3, "dir":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    array-length v4, v4

    if-lez v4, :cond_0

    .line 102
    const-string v4, "LADEN (SURVIVAL)"

    invoke-direct {p0, v4}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v4

    .line 103
    .local v4, "btnLoadS":Landroid/widget/Button;
    sget v5, Lcom/EZdev/mc2/R$color;->button_load:I

    invoke-virtual {p0, v5}, Landroid/content/Context;->getColor(I)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 104
    new-instance v5, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda4;

    invoke-direct {v5, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda4;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 105
    iget-object v5, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 107
    const-string v5, "LADEN (KREATIV)"

    invoke-direct {p0, v5}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v5

    .line 108
    .local v5, "btnLoadC":Landroid/widget/Button;
    sget v6, Lcom/EZdev/mc2/R$color;->button_load:I

    invoke-virtual {p0, v6}, Landroid/content/Context;->getColor(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 109
    new-instance v6, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda5;

    invoke-direct {v6, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda5;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 110
    iget-object v6, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 113
    .end local v4    # "btnLoadS":Landroid/widget/Button;
    .end local v5    # "btnLoadC":Landroid/widget/Button;
    :cond_0
    const-string v4, "EINSTELLUNGEN"

    invoke-direct {p0, v4}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v4

    .line 114
    .local v4, "btnSettings":Landroid/widget/Button;
    sget v5, Lcom/EZdev/mc2/R$color;->button_settings:I

    invoke-virtual {p0, v5}, Landroid/content/Context;->getColor(I)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 115
    new-instance v5, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda6;

    invoke-direct {v5, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda6;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 116
    iget-object v5, p0, Lcom/EZdev/mc2/MainMenuActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 117
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$7(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 157
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->hideSettings()V

    return-void
.end method

.method private synthetic lambda$initMainMenuLayout$2(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 93
    const/4 v0, 0x0

    invoke-direct {p0, v0, v0}, Lcom/EZdev/mc2/MainMenuActivity;->startGame(ZZ)V

    return-void
.end method

.method private synthetic lambda$initMainMenuLayout$3(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 97
    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/MainMenuActivity;->startGame(ZZ)V

    return-void
.end method

.method private synthetic lambda$initMainMenuLayout$4(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 104
    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/MainMenuActivity;->startGame(ZZ)V

    return-void
.end method

.method private synthetic lambda$initMainMenuLayout$5(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 109
    const/4 v0, 0x1

    invoke-direct {p0, v0, v0}, Lcom/EZdev/mc2/MainMenuActivity;->startGame(ZZ)V

    return-void
.end method

.method private synthetic lambda$initMainMenuLayout$6(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 115
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->showSettings()V

    return-void
.end method

.method private synthetic lambda$setupRenderDistanceControls$8(Landroid/widget/TextView;Landroid/view/View;)V
    .locals 3
    .param p1, "chunkText"    # Landroid/widget/TextView;
    .param p2, "v"    # Landroid/view/View;

    .line 204
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x2

    const-string v2, "RENDER_DISTANCE"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    .line 205
    .local v0, "d":I
    const/4 v1, 0x1

    if-le v0, v1, :cond_0

    .line 206
    add-int/lit8 v0, v0, -0x1

    .line 207
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 208
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Sichtweite (Chunks): "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 210
    :cond_0
    return-void
.end method

.method private synthetic lambda$setupRenderDistanceControls$9(Landroid/widget/TextView;Landroid/view/View;)V
    .locals 3
    .param p1, "chunkText"    # Landroid/widget/TextView;
    .param p2, "v"    # Landroid/view/View;

    .line 212
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x2

    const-string v2, "RENDER_DISTANCE"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    .line 213
    .local v0, "d":I
    const/4 v1, 0x6

    if-ge v0, v1, :cond_0

    .line 214
    add-int/lit8 v0, v0, 0x1

    .line 215
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 216
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Sichtweite (Chunks): "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 218
    :cond_0
    return-void
.end method

.method private synthetic lambda$setupSettingsToggles$10(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "fogBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 229
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "FOG_ENABLED"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/2addr v0, v2

    .line 230
    .local v0, "f":Z
    iget-object v2, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2, v1, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 231
    if-eqz v0, :cond_0

    const-string v1, "NEBEL: AN"

    goto :goto_0

    :cond_0
    const-string v1, "NEBEL: AUS"

    :goto_0
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 232
    return-void
.end method

.method private synthetic lambda$setupSettingsToggles$11(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "vulkanBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 238
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const-string v2, "FAST_RENDER"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 239
    .local v0, "f":Z
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 240
    if-eqz v0, :cond_0

    const-string v1, "VULKAN (FAST RENDER): AN"

    goto :goto_0

    :cond_0
    const-string v1, "VULKAN (FAST RENDER): AUS"

    :goto_0
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 241
    return-void
.end method

.method private synthetic lambda$setupSettingsToggles$12(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "musicBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 247
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "MUSIC_ENABLED"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/2addr v0, v2

    .line 248
    .local v0, "m":Z
    iget-object v2, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2, v1, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 249
    if-eqz v0, :cond_0

    const-string v1, "MUSIK: AN"

    goto :goto_0

    :cond_0
    const-string v1, "MUSIK: AUS"

    :goto_0
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 250
    return-void
.end method

.method private synthetic lambda$setupSettingsToggles$13(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "sfxBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 260
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "SFX_ENABLED"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/2addr v0, v2

    .line 261
    .local v0, "s":Z
    iget-object v2, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2, v1, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 262
    if-eqz v0, :cond_0

    const-string v1, "EFFEKTE: AN"

    goto :goto_0

    :cond_0
    const-string v1, "EFFEKTE: AUS"

    :goto_0
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 263
    return-void
.end method

.method private synthetic lambda$setupSettingsToggles$14(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "debugBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 270
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const-string v2, "SHOW_DEBUG"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 271
    .local v0, "d":Z
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 272
    if-eqz v0, :cond_0

    const-string v1, "DEBUG INFO: AN"

    goto :goto_0

    :cond_0
    const-string v1, "DEBUG INFO: AUS"

    :goto_0
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 273
    return-void
.end method

.method private synthetic lambda$setupSettingsToggles$15(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "glWarnBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 280
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const-string v2, "GL_WARN"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 281
    .local v0, "g":Z
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 282
    if-eqz v0, :cond_0

    const-string v1, "GL-WARNUNGEN: AN"

    goto :goto_0

    :cond_0
    const-string v1, "GL-WARNUNGEN: AUS"

    :goto_0
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 283
    return-void
.end method

.method private synthetic lambda$showLoadingScreenAndOptimize$0()V
    .locals 2

    .line 73
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->mainOverlay:Landroid/widget/FrameLayout;

    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->loadingPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 74
    return-void
.end method

.method private synthetic lambda$showLoadingScreenAndOptimize$1()V
    .locals 4

    .line 61
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    .line 62
    .local v0, "cacheFiles":[Ljava/io/File;
    if-eqz v0, :cond_0

    .line 63
    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v3, v0, v2

    .line 64
    .local v3, "f":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->delete()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 63
    nop

    .end local v3    # "f":Ljava/io/File;
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 68
    .end local v0    # "cacheFiles":[Ljava/io/File;
    :catch_0
    move-exception v0

    goto :goto_1

    .line 70
    :cond_0
    goto :goto_2

    .line 68
    :goto_1
    nop

    .line 69
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "MainMenuActivity"

    const-string v2, "Failed to optimize"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 72
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda8;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 75
    return-void
.end method

.method private setupRenderDistanceControls()V
    .locals 9

    .line 179
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 180
    .local v0, "chunkText":Landroid/widget/TextView;
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v2, "RENDER_DISTANCE"

    const/4 v3, 0x2

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 181
    .local v1, "currentDist":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Sichtweite (Chunks): "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 182
    sget v2, Lcom/EZdev/mc2/R$color;->yellow:I

    invoke-virtual {p0, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 183
    const/high16 v2, 0x41a00000    # 20.0f

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 184
    const/16 v2, 0x32

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v2, v3, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 185
    const/16 v2, 0x11

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 187
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 188
    .local v2, "plusMinus":Landroid/widget/LinearLayout;
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 190
    const-string v4, "- WENIGER"

    invoke-direct {p0, v4}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v4

    .line 191
    .local v4, "minusBtn":Landroid/widget/Button;
    sget v5, Lcom/EZdev/mc2/R$color;->button_minus:I

    invoke-virtual {p0, v5}, Landroid/content/Context;->getColor(I)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 192
    const-string v5, "+ MEHR"

    invoke-direct {p0, v5}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v5

    .line 193
    .local v5, "plusBtn":Landroid/widget/Button;
    sget v6, Lcom/EZdev/mc2/R$color;->button_plus:I

    invoke-virtual {p0, v6}, Landroid/content/Context;->getColor(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 195
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v6, v3, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v3, v6

    .line 196
    .local v3, "btnP":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v6, 0xa

    invoke-virtual {v3, v6, v6, v6, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 197
    invoke-virtual {v4, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 198
    invoke-virtual {v5, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 200
    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 201
    invoke-virtual {v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 203
    new-instance v6, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda0;

    invoke-direct {v6, p0, v0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/TextView;)V

    invoke-virtual {v4, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 211
    new-instance v6, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda1;

    invoke-direct {v6, p0, v0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda1;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/TextView;)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 220
    iget-object v6, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 221
    iget-object v6, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 222
    return-void
.end method

.method private setupSettingsToggles()V
    .locals 13

    .line 225
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "FOG_ENABLED"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    .line 226
    .local v0, "isFog":Z
    if-eqz v0, :cond_0

    const-string v1, "NEBEL: AN"

    goto :goto_0

    :cond_0
    const-string v1, "NEBEL: AUS"

    :goto_0
    invoke-direct {p0, v1}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    .line 227
    .local v1, "fogBtn":Landroid/widget/Button;
    sget v3, Lcom/EZdev/mc2/R$color;->button_purple:I

    invoke-virtual {p0, v3}, Landroid/content/Context;->getColor(I)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 228
    new-instance v3, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;

    invoke-direct {v3, p0, v1}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 234
    iget-object v3, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "FAST_RENDER"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    .line 235
    .local v3, "isFast":Z
    if-eqz v3, :cond_1

    const-string v4, "VULKAN (FAST RENDER): AN"

    goto :goto_1

    :cond_1
    const-string v4, "VULKAN (FAST RENDER): AUS"

    :goto_1
    invoke-direct {p0, v4}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v4

    .line 236
    .local v4, "vulkanBtn":Landroid/widget/Button;
    sget v6, Lcom/EZdev/mc2/R$color;->button_orange:I

    invoke-virtual {p0, v6}, Landroid/content/Context;->getColor(I)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 237
    new-instance v6, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda10;

    invoke-direct {v6, p0, v4}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda10;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V

    invoke-virtual {v4, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 243
    iget-object v6, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "MUSIC_ENABLED"

    invoke-interface {v6, v7, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    .line 244
    .local v6, "isMusic":Z
    if-eqz v6, :cond_2

    const-string v7, "MUSIK: AN"

    goto :goto_2

    :cond_2
    const-string v7, "MUSIK: AUS"

    :goto_2
    invoke-direct {p0, v7}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v7

    .line 245
    .local v7, "musicBtn":Landroid/widget/Button;
    sget v8, Lcom/EZdev/mc2/R$color;->button_teal:I

    invoke-virtual {p0, v8}, Landroid/content/Context;->getColor(I)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 246
    new-instance v8, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda11;

    invoke-direct {v8, p0, v7}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda11;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V

    invoke-virtual {v7, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 252
    iget-object v8, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 253
    iget-object v8, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 254
    iget-object v8, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 256
    iget-object v8, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v9, "SFX_ENABLED"

    invoke-interface {v8, v9, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    .line 257
    .local v2, "isSfx":Z
    if-eqz v2, :cond_3

    const-string v8, "EFFEKTE: AN"

    goto :goto_3

    :cond_3
    const-string v8, "EFFEKTE: AUS"

    :goto_3
    invoke-direct {p0, v8}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v8

    .line 258
    .local v8, "sfxBtn":Landroid/widget/Button;
    sget v9, Lcom/EZdev/mc2/R$color;->button_blue:I

    invoke-virtual {p0, v9}, Landroid/content/Context;->getColor(I)I

    move-result v9

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundColor(I)V

    .line 259
    new-instance v9, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda12;

    invoke-direct {v9, p0, v8}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda12;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 264
    iget-object v9, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 266
    iget-object v9, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "SHOW_DEBUG"

    invoke-interface {v9, v10, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    .line 267
    .local v9, "isDebug":Z
    if-eqz v9, :cond_4

    const-string v10, "DEBUG INFO: AN"

    goto :goto_4

    :cond_4
    const-string v10, "DEBUG INFO: AUS"

    :goto_4
    invoke-direct {p0, v10}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v10

    .line 268
    .local v10, "debugBtn":Landroid/widget/Button;
    sget v11, Lcom/EZdev/mc2/R$color;->button_purple:I

    invoke-virtual {p0, v11}, Landroid/content/Context;->getColor(I)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/view/View;->setBackgroundColor(I)V

    .line 269
    new-instance v11, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda13;

    invoke-direct {v11, p0, v10}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda13;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 274
    iget-object v11, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v11, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 276
    iget-object v11, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "GL_WARN"

    invoke-interface {v11, v12, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    .line 277
    .local v5, "isGLWarn":Z
    if-eqz v5, :cond_5

    const-string v11, "GL-WARNUNGEN: AN"

    goto :goto_5

    :cond_5
    const-string v11, "GL-WARNUNGEN: AUS"

    :goto_5
    invoke-direct {p0, v11}, Lcom/EZdev/mc2/MainMenuActivity;->createMenuBtn(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v11

    .line 278
    .local v11, "glWarnBtn":Landroid/widget/Button;
    sget v12, Lcom/EZdev/mc2/R$color;->button_settings:I

    invoke-virtual {p0, v12}, Landroid/content/Context;->getColor(I)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundColor(I)V

    .line 279
    new-instance v12, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda14;

    invoke-direct {v12, p0, v11}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda14;-><init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 284
    iget-object v12, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v12, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 285
    return-void
.end method

.method private showLoadingScreenAndOptimize()V
    .locals 5

    .line 44
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->loadingPanel:Landroid/widget/LinearLayout;

    .line 45
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 46
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->loadingPanel:Landroid/widget/LinearLayout;

    sget v1, Lcom/EZdev/mc2/R$color;->black:I

    invoke-virtual {p0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 47
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->loadingPanel:Landroid/widget/LinearLayout;

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 49
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 50
    .local v0, "t":Landroid/widget/TextView;
    const-string v2, "\u2699\ufe0f MAGIC TUNER OPTIMIERUNG L\u00c4UFT... \u2699\ufe0f\nClear Cache..."

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 51
    sget v2, Lcom/EZdev/mc2/R$color;->green:I

    invoke-virtual {p0, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 52
    const/high16 v2, 0x41a00000    # 20.0f

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 53
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 54
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->loadingPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 56
    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity;->mainOverlay:Landroid/widget/FrameLayout;

    iget-object v2, p0, Lcom/EZdev/mc2/MainMenuActivity;->loadingPanel:Landroid/widget/LinearLayout;

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 58
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda7;

    invoke-direct {v2, p0}, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda7;-><init>(Lcom/EZdev/mc2/MainMenuActivity;)V

    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 75
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 76
    return-void
.end method

.method private showSettings()V
    .locals 2

    .line 288
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 289
    return-void
.end method

.method private startGame(ZZ)V
    .locals 2
    .param p1, "isCreative"    # Z
    .param p2, "loadWorld"    # Z

    .line 120
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 121
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "CREATIVE_MODE"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 122
    const-string v1, "LOAD_WORLD"

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 123
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 124
    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 33
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 35
    const-string v0, "McPrefs"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity;->prefs:Landroid/content/SharedPreferences;

    .line 37
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->initMainMenuLayout()V

    .line 38
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->createSettingsMenu()V

    .line 40
    invoke-direct {p0}, Lcom/EZdev/mc2/MainMenuActivity;->showLoadingScreenAndOptimize()V

    .line 41
    return-void
.end method
