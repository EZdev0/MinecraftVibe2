.class public final synthetic Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/UIManager;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/UIManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda0;->f$0:Lcom/EZdev/mc2/UIManager;

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda0;->f$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v0, p1, p2}, Lcom/EZdev/mc2/UIManager;->$r8$lambda$_lZs74Q58sgF-jAN_9Sh1PIMsYU(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method
