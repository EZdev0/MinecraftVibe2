.class public final synthetic Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/UIManager;

.field public final synthetic f$1:B

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/UIManager;BI)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;->f$0:Lcom/EZdev/mc2/UIManager;

    iput-byte p2, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;->f$1:B

    iput p3, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;->f$2:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;->f$0:Lcom/EZdev/mc2/UIManager;

    iget-byte v1, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;->f$1:B

    iget v2, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;->f$2:I

    invoke-static {v0, v1, v2, p1}, Lcom/EZdev/mc2/UIManager;->$r8$lambda$caOUBdijvoqpGOjVnbP6xsApikM(Lcom/EZdev/mc2/UIManager;BILandroid/view/View;)V

    return-void
.end method
