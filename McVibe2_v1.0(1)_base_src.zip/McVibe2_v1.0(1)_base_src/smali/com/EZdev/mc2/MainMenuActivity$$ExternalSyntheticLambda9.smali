.class public final synthetic Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/MainMenuActivity;

.field public final synthetic f$1:Landroid/widget/Button;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;->f$0:Lcom/EZdev/mc2/MainMenuActivity;

    iput-object p2, p0, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;->f$1:Landroid/widget/Button;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;->f$0:Lcom/EZdev/mc2/MainMenuActivity;

    iget-object v1, p0, Lcom/EZdev/mc2/MainMenuActivity$$ExternalSyntheticLambda9;->f$1:Landroid/widget/Button;

    invoke-static {v0, v1, p1}, Lcom/EZdev/mc2/MainMenuActivity;->$r8$lambda$wdkYY2J5D-YFKBRnmL7XWo3SM-w(Lcom/EZdev/mc2/MainMenuActivity;Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method
