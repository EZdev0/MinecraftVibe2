.class public Lcom/EZdev/mc2/CrashHandlerActivity;
.super Landroid/app/Activity;
.source "CrashHandlerActivity.java"


# static fields
.field private static final MAX_ERROR_LOG_LENGTH:I = 0x2710


# direct methods
.method public static synthetic $r8$lambda$B0Ie4oiR4xcEZzO1Q6RNTNjYF9Y(Lcom/EZdev/mc2/CrashHandlerActivity;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/CrashHandlerActivity;->lambda$onCreate$1(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$JjTcvOqTjy_CWSzvEn2edPSM_rM(Lcom/EZdev/mc2/CrashHandlerActivity;ZLandroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/CrashHandlerActivity;->lambda$onCreate$2(ZLandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$Pg2DPsUW-cP6BtTg2q2ND9F7rhI(Lcom/EZdev/mc2/CrashHandlerActivity;Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/CrashHandlerActivity;->lambda$onCreate$0(Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private synthetic lambda$onCreate$0(Ljava/lang/String;Landroid/view/View;)V
    .locals 4
    .param p1, "finalLog"    # Ljava/lang/String;
    .param p2, "v"    # Landroid/view/View;

    .line 98
    const-string v0, "clipboard"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    .line 99
    .local v0, "clipboard":Landroid/content/ClipboardManager;
    const-string v1, "Crash Log"

    invoke-static {v1, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v1

    .line 100
    .local v1, "clip":Landroid/content/ClipData;
    if-eqz v0, :cond_0

    .line 101
    invoke-virtual {v0, v1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 102
    const-string v2, "Log kopiert!"

    const/4 v3, 0x0

    invoke-static {p0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 104
    :cond_0
    return-void
.end method

.method private synthetic lambda$onCreate$1(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 113
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 114
    return-void
.end method

.method private synthetic lambda$onCreate$2(ZLandroid/view/View;)V
    .locals 2
    .param p1, "canContinue"    # Z
    .param p2, "v"    # Landroid/view/View;

    .line 123
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/EZdev/mc2/MainMenuActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 124
    .local v0, "i":Landroid/content/Intent;
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 125
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 126
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 127
    if-nez p1, :cond_0

    .line 128
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 129
    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/System;->exit(I)V

    .line 131
    :cond_0
    return-void
.end method

.method private sanitize(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p1, "input"    # Ljava/lang/String;

    .line 138
    if-nez p1, :cond_0

    const/4 v0, 0x0

    return-object v0

    .line 142
    :cond_0
    const-string v0, "[\\p{Cc}\\p{Cf}\\p{Co}\\p{Cn}&&[^\\n\\r\\t]]"

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 16
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 28
    move-object/from16 v1, p0

    const-string v0, "crash_log.txt"

    invoke-super/range {p0 .. p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 30
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    .line 31
    .local v2, "intent":Landroid/content/Intent;
    const-string v3, "Unbekannter Fehler!"

    .line 34
    .local v3, "errorLog":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 35
    .local v4, "sb":Ljava/lang/StringBuilder;
    :try_start_0
    invoke-virtual {v1, v0}, Landroid/content/Context;->openFileInput(Ljava/lang/String;)Ljava/io/FileInputStream;

    move-result-object v5
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .local v5, "fis":Ljava/io/FileInputStream;
    :try_start_1
    new-instance v6, Ljava/io/BufferedReader;

    new-instance v7, Ljava/io/InputStreamReader;

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v7, v5, v8}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v6, v7}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 38
    .local v6, "reader":Ljava/io/BufferedReader;
    :goto_0
    :try_start_2
    invoke-virtual {v6}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v7

    move-object v8, v7

    .local v8, "line":Ljava/lang/String;
    if-eqz v7, :cond_0

    .line 39
    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "\n"

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 35
    .end local v8    # "line":Ljava/lang/String;
    :catchall_0
    move-exception v0

    move-object v7, v0

    goto :goto_2

    .line 41
    .restart local v8    # "line":Ljava/lang/String;
    :cond_0
    invoke-virtual {v1, v0}, Landroid/content/Context;->deleteFile(Ljava/lang/String;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 42
    .end local v8    # "line":Ljava/lang/String;
    :try_start_3
    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .end local v6    # "reader":Ljava/io/BufferedReader;
    if-eqz v5, :cond_1

    :try_start_4
    invoke-virtual {v5}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_1

    .end local v5    # "fis":Ljava/io/FileInputStream;
    :catch_0
    move-exception v0

    goto :goto_6

    .line 44
    :cond_1
    :goto_1
    goto :goto_7

    .line 35
    .restart local v5    # "fis":Ljava/io/FileInputStream;
    :catchall_1
    move-exception v0

    move-object v6, v0

    goto :goto_4

    .restart local v6    # "reader":Ljava/io/BufferedReader;
    :goto_2
    :try_start_5
    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_3

    :catchall_2
    move-exception v0

    move-object v8, v0

    :try_start_6
    invoke-virtual {v7, v8}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v2    # "intent":Landroid/content/Intent;
    .end local v3    # "errorLog":Ljava/lang/String;
    .end local v4    # "sb":Ljava/lang/StringBuilder;
    .end local v5    # "fis":Ljava/io/FileInputStream;
    .end local p1    # "savedInstanceState":Landroid/os/Bundle;
    :goto_3
    throw v7
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .end local v6    # "reader":Ljava/io/BufferedReader;
    .restart local v2    # "intent":Landroid/content/Intent;
    .restart local v3    # "errorLog":Ljava/lang/String;
    .restart local v4    # "sb":Ljava/lang/StringBuilder;
    .restart local v5    # "fis":Ljava/io/FileInputStream;
    .restart local p1    # "savedInstanceState":Landroid/os/Bundle;
    :goto_4
    if-eqz v5, :cond_2

    :try_start_7
    invoke-virtual {v5}, Ljava/io/FileInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_5

    :catchall_3
    move-exception v0

    move-object v7, v0

    :try_start_8
    invoke-virtual {v6, v7}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_5
    nop

    .end local v2    # "intent":Landroid/content/Intent;
    .end local v3    # "errorLog":Ljava/lang/String;
    .end local v4    # "sb":Ljava/lang/StringBuilder;
    .end local p1    # "savedInstanceState":Landroid/os/Bundle;
    throw v6
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0

    .line 42
    .end local v5    # "fis":Ljava/io/FileInputStream;
    .restart local v2    # "intent":Landroid/content/Intent;
    .restart local v3    # "errorLog":Ljava/lang/String;
    .restart local v4    # "sb":Ljava/lang/StringBuilder;
    .restart local p1    # "savedInstanceState":Landroid/os/Bundle;
    :goto_6
    nop

    .line 43
    .local v0, "e":Ljava/io/IOException;
    const-string v5, "CrashHandlerActivity"

    const-string v6, "Failed to read crash log"

    invoke-static {v5, v6, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 46
    .end local v0    # "e":Ljava/io/IOException;
    :goto_7
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    .line 47
    .local v0, "rawError":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    if-eqz v2, :cond_3

    .line 48
    const-string v5, "error"

    invoke-virtual {v2, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 49
    .local v5, "intentError":Ljava/lang/String;
    if-eqz v5, :cond_3

    .line 50
    move-object v0, v5

    .line 54
    .end local v5    # "intentError":Ljava/lang/String;
    :cond_3
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    const/4 v6, 0x0

    if-nez v5, :cond_5

    .line 55
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v7, 0x2710

    if-le v5, v7, :cond_4

    .line 56
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "... [Truncated]"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 58
    :cond_4
    invoke-direct {v1, v0}, Lcom/EZdev/mc2/CrashHandlerActivity;->sanitize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 61
    :cond_5
    if-eqz v2, :cond_6

    .line 62
    const-string v5, "canContinue"

    invoke-virtual {v2, v5, v6}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v5

    .local v5, "canContinue":Z
    goto :goto_8

    .line 64
    .end local v5    # "canContinue":Z
    :cond_6
    const/4 v5, 0x0

    .line 67
    .restart local v5    # "canContinue":Z
    :goto_8
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 68
    .local v7, "root":Landroid/widget/LinearLayout;
    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 69
    const-string v8, "#c0392b"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 70
    const/16 v8, 0x28

    invoke-virtual {v7, v8, v8, v8, v8}, Landroid/view/View;->setPadding(IIII)V

    .line 72
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 73
    .local v9, "title":Landroid/widget/TextView;
    if-eqz v5, :cond_7

    const-string v10, "FEHLER ERKANNT"

    goto :goto_9

    :cond_7
    const-string v10, "MINECRAFT 2 VIBE IST ABGEST\u00dcRZT :("

    :goto_9
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 74
    const/4 v10, -0x1

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 75
    const/high16 v11, 0x41c00000    # 24.0f

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 76
    const/16 v11, 0x11

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 77
    invoke-virtual {v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 79
    new-instance v11, Landroid/widget/ScrollView;

    invoke-direct {v11, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 80
    .local v11, "scroll":Landroid/widget/ScrollView;
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v12, v10, v6, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 82
    .local v12, "scrollParams":Landroid/widget/LinearLayout$LayoutParams;
    invoke-virtual {v12, v6, v8, v6, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 83
    invoke-virtual {v11, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 85
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 86
    .local v6, "logView":Landroid/widget/TextView;
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 87
    const-string v8, "#ecf0f1"

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 88
    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 89
    invoke-virtual {v11, v6}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 90
    invoke-virtual {v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 92
    move-object v8, v3

    .line 93
    .local v8, "finalLog":Ljava/lang/String;
    new-instance v13, Landroid/widget/Button;

    invoke-direct {v13, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 94
    .local v13, "copyBtn":Landroid/widget/Button;
    const-string v14, "LOG KOPIEREN"

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 95
    invoke-virtual {v13, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 96
    const/high16 v14, -0x1000000

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 97
    new-instance v15, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda0;

    invoke-direct {v15, v1, v8}, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/CrashHandlerActivity;Ljava/lang/String;)V

    invoke-virtual {v13, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 105
    invoke-virtual {v7, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 107
    if-eqz v5, :cond_8

    .line 108
    new-instance v15, Landroid/widget/Button;

    invoke-direct {v15, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 109
    .local v15, "continueBtn":Landroid/widget/Button;
    const-string v14, "FORTFAHREN"

    invoke-virtual {v15, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 110
    const-string v14, "#2ecc71"

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v15, v14}, Landroid/view/View;->setBackgroundColor(I)V

    .line 111
    invoke-virtual {v15, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 112
    new-instance v14, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda1;

    invoke-direct {v14, v1}, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda1;-><init>(Lcom/EZdev/mc2/CrashHandlerActivity;)V

    invoke-virtual {v15, v14}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    invoke-virtual {v7, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 118
    .end local v15    # "continueBtn":Landroid/widget/Button;
    :cond_8
    new-instance v14, Landroid/widget/Button;

    invoke-direct {v14, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 119
    .local v14, "restartBtn":Landroid/widget/Button;
    const-string v15, "NEUSTART (HAUPTMEN\u00dc)"

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 120
    invoke-virtual {v14, v10}, Landroid/view/View;->setBackgroundColor(I)V

    .line 121
    const/high16 v10, -0x1000000

    invoke-virtual {v14, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 122
    new-instance v10, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;

    invoke-direct {v10, v1, v5}, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;-><init>(Lcom/EZdev/mc2/CrashHandlerActivity;Z)V

    invoke-virtual {v14, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 132
    invoke-virtual {v7, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 134
    invoke-virtual {v1, v7}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 135
    return-void
.end method
