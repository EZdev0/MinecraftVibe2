.class public final synthetic Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/CrashHandlerActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/CrashHandlerActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda1;->f$0:Lcom/EZdev/mc2/CrashHandlerActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda1;->f$0:Lcom/EZdev/mc2/CrashHandlerActivity;

    invoke-static {v0, p1}, Lcom/EZdev/mc2/CrashHandlerActivity;->$r8$lambda$B0Ie4oiR4xcEZzO1Q6RNTNjYF9Y(Lcom/EZdev/mc2/CrashHandlerActivity;Landroid/view/View;)V

    return-void
.end method
