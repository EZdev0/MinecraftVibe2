.class public Lcom/EZdev/mc2/Gameplay$ActiveTNT;
.super Ljava/lang/Object;
.source "Gameplay.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/Gameplay;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "ActiveTNT"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/EZdev/mc2/Gameplay;

.field public timer:F

.field public vx:F

.field public vy:F

.field public vz:F

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method public constructor <init>(Lcom/EZdev/mc2/Gameplay;FFF)V
    .locals 1
    .param p1, "this$0"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "x"    # F
    .param p3, "y"    # F
    .param p4, "z"    # F

    .line 63
    iput-object p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->this$0:Lcom/EZdev/mc2/Gameplay;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 61
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    .line 62
    const/high16 v0, 0x40400000    # 3.0f

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->timer:F

    .line 63
    invoke-virtual {p0, p2, p3, p4}, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->init(FFF)V

    return-void
.end method


# virtual methods
.method public init(FFF)V
    .locals 1
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F

    .line 65
    iput p1, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    iput p2, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    iput p3, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    .line 66
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    .line 67
    const/high16 v0, 0x40400000    # 3.0f

    iput v0, p0, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->timer:F

    .line 68
    return-void
.end method
