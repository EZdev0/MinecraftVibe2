.class public Lcom/EZdev/mc2/SoundManager;
.super Ljava/lang/Object;
.source "SoundManager.java"


# instance fields
.field private context:Landroid/content/Context;

.field private grassSoundId:I

.field private isEnabled:Z

.field private lastTntTime:J

.field private random:Ljava/security/SecureRandom;

.field private reverb:Landroid/media/audiofx/EnvironmentalReverb;

.field private soundPool:Landroid/media/SoundPool;

.field private stoneSoundId:I

.field private tntSoundId:I

.field private waterSoundId:I

.field private woodSoundId:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 5
    .param p1, "context"    # Landroid/content/Context;

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    const/4 v0, -0x1

    iput v0, p0, Lcom/EZdev/mc2/SoundManager;->grassSoundId:I

    .line 16
    iput v0, p0, Lcom/EZdev/mc2/SoundManager;->stoneSoundId:I

    .line 17
    iput v0, p0, Lcom/EZdev/mc2/SoundManager;->woodSoundId:I

    .line 18
    iput v0, p0, Lcom/EZdev/mc2/SoundManager;->tntSoundId:I

    .line 19
    iput v0, p0, Lcom/EZdev/mc2/SoundManager;->waterSoundId:I

    .line 23
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/EZdev/mc2/SoundManager;->lastTntTime:J

    .line 26
    iput-object p1, p0, Lcom/EZdev/mc2/SoundManager;->context:Landroid/content/Context;

    .line 27
    const-string v0, "McPrefs"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "SFX_ENABLED"

    const/4 v3, 0x1

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/EZdev/mc2/SoundManager;->isEnabled:Z

    .line 28
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/SoundManager;->random:Ljava/security/SecureRandom;

    .line 30
    new-instance v0, Landroid/media/AudioAttributes$Builder;

    invoke-direct {v0}, Landroid/media/AudioAttributes$Builder;-><init>()V

    .line 31
    const/16 v2, 0xe

    invoke-virtual {v0, v2}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    .line 32
    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object v0

    .line 33
    invoke-virtual {v0}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object v0

    .line 35
    .local v0, "attributes":Landroid/media/AudioAttributes;
    new-instance v2, Landroid/media/SoundPool$Builder;

    invoke-direct {v2}, Landroid/media/SoundPool$Builder;-><init>()V

    .line 36
    const/16 v4, 0xa

    invoke-virtual {v2, v4}, Landroid/media/SoundPool$Builder;->setMaxStreams(I)Landroid/media/SoundPool$Builder;

    move-result-object v2

    .line 37
    invoke-virtual {v2, v0}, Landroid/media/SoundPool$Builder;->setAudioAttributes(Landroid/media/AudioAttributes;)Landroid/media/SoundPool$Builder;

    move-result-object v2

    .line 38
    invoke-virtual {v2}, Landroid/media/SoundPool$Builder;->build()Landroid/media/SoundPool;

    move-result-object v2

    iput-object v2, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    .line 41
    sget v4, Lcom/EZdev/mc2/R$raw;->grass:I

    invoke-virtual {v2, p1, v4, v3}, Landroid/media/SoundPool;->load(Landroid/content/Context;II)I

    move-result v2

    iput v2, p0, Lcom/EZdev/mc2/SoundManager;->grassSoundId:I

    .line 42
    iget-object v2, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    sget v4, Lcom/EZdev/mc2/R$raw;->stone:I

    invoke-virtual {v2, p1, v4, v3}, Landroid/media/SoundPool;->load(Landroid/content/Context;II)I

    move-result v2

    iput v2, p0, Lcom/EZdev/mc2/SoundManager;->stoneSoundId:I

    .line 43
    iget-object v2, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    sget v4, Lcom/EZdev/mc2/R$raw;->wood:I

    invoke-virtual {v2, p1, v4, v3}, Landroid/media/SoundPool;->load(Landroid/content/Context;II)I

    move-result v2

    iput v2, p0, Lcom/EZdev/mc2/SoundManager;->woodSoundId:I

    .line 44
    iget-object v2, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    sget v4, Lcom/EZdev/mc2/R$raw;->tnt:I

    invoke-virtual {v2, p1, v4, v3}, Landroid/media/SoundPool;->load(Landroid/content/Context;II)I

    move-result v2

    iput v2, p0, Lcom/EZdev/mc2/SoundManager;->tntSoundId:I

    .line 45
    iget-object v2, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    sget v4, Lcom/EZdev/mc2/R$raw;->water:I

    invoke-virtual {v2, p1, v4, v3}, Landroid/media/SoundPool;->load(Landroid/content/Context;II)I

    move-result v2

    iput v2, p0, Lcom/EZdev/mc2/SoundManager;->waterSoundId:I

    .line 49
    :try_start_0
    new-instance v2, Landroid/media/audiofx/EnvironmentalReverb;

    invoke-direct {v2, v1, v1}, Landroid/media/audiofx/EnvironmentalReverb;-><init>(II)V

    iput-object v2, p0, Lcom/EZdev/mc2/SoundManager;->reverb:Landroid/media/audiofx/EnvironmentalReverb;

    .line 50
    const/16 v1, 0x5dc

    invoke-virtual {v2, v1}, Landroid/media/audiofx/EnvironmentalReverb;->setDecayTime(I)V

    .line 51
    iget-object v1, p0, Lcom/EZdev/mc2/SoundManager;->reverb:Landroid/media/audiofx/EnvironmentalReverb;

    const/16 v2, -0x3e8

    invoke-virtual {v1, v2}, Landroid/media/audiofx/EnvironmentalReverb;->setRoomLevel(S)V

    .line 52
    iget-object v1, p0, Lcom/EZdev/mc2/SoundManager;->reverb:Landroid/media/audiofx/EnvironmentalReverb;

    invoke-virtual {v1, v3}, Landroid/media/audiofx/AudioEffect;->setEnabled(Z)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 55
    goto :goto_0

    .line 53
    :catch_0
    move-exception v1

    .line 54
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "SoundManager"

    const-string v3, "Reverb not supported"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 56
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_0
    return-void
.end method


# virtual methods
.method public isEnabled()Z
    .locals 1

    .line 100
    iget-boolean v0, p0, Lcom/EZdev/mc2/SoundManager;->isEnabled:Z

    return v0
.end method

.method public playSoundForBlock(B)V
    .locals 10
    .param p1, "blockId"    # B

    .line 65
    iget-boolean v0, p0, Lcom/EZdev/mc2/SoundManager;->isEnabled:Z

    if-nez v0, :cond_0

    return-void

    .line 67
    :cond_0
    const/4 v0, -0x1

    .line 68
    .local v0, "soundId":I
    const/high16 v1, 0x3f800000    # 1.0f

    .line 71
    .local v1, "volume":F
    const/4 v2, 0x1

    if-eq p1, v2, :cond_1

    const/16 v2, 0xa

    if-eq p1, v2, :cond_1

    const/4 v2, 0x4

    if-ne p1, v2, :cond_2

    :cond_1
    goto :goto_1

    .line 72
    :cond_2
    const/4 v2, 0x2

    if-eq p1, v2, :cond_3

    const/16 v2, 0x9

    if-ne p1, v2, :cond_4

    :cond_3
    goto :goto_0

    .line 73
    :cond_4
    const/4 v2, 0x3

    if-ne p1, v2, :cond_5

    iget v0, p0, Lcom/EZdev/mc2/SoundManager;->woodSoundId:I

    goto :goto_2

    .line 74
    :cond_5
    const/4 v2, 0x5

    if-ne p1, v2, :cond_7

    .line 75
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 76
    .local v2, "currentTime":J
    iget-wide v4, p0, Lcom/EZdev/mc2/SoundManager;->lastTntTime:J

    sub-long v4, v2, v4

    const-wide/16 v6, 0x96

    cmp-long v4, v4, v6

    if-lez v4, :cond_6

    .line 77
    iget v0, p0, Lcom/EZdev/mc2/SoundManager;->tntSoundId:I

    .line 78
    iput-wide v2, p0, Lcom/EZdev/mc2/SoundManager;->lastTntTime:J

    .line 79
    const v1, 0x3f4ccccd    # 0.8f

    .line 83
    .end local v2    # "currentTime":J
    goto :goto_2

    .line 81
    .restart local v2    # "currentTime":J
    :cond_6
    return-void

    .line 84
    .end local v2    # "currentTime":J
    :cond_7
    const/4 v2, 0x7

    if-ne p1, v2, :cond_8

    iget v0, p0, Lcom/EZdev/mc2/SoundManager;->waterSoundId:I

    goto :goto_2

    .line 85
    :cond_8
    iget v0, p0, Lcom/EZdev/mc2/SoundManager;->stoneSoundId:I

    goto :goto_2

    .line 72
    :goto_0
    iget v0, p0, Lcom/EZdev/mc2/SoundManager;->stoneSoundId:I

    goto :goto_2

    .line 71
    :goto_1
    iget v0, p0, Lcom/EZdev/mc2/SoundManager;->grassSoundId:I

    .line 87
    :goto_2
    const/4 v2, -0x1

    if-eq v0, v2, :cond_9

    .line 89
    iget-object v2, p0, Lcom/EZdev/mc2/SoundManager;->random:Ljava/security/SecureRandom;

    invoke-virtual {v2}, Ljava/util/Random;->nextFloat()F

    move-result v2

    const v3, 0x3ecccccd    # 0.4f

    mul-float/2addr v2, v3

    const v3, 0x3f4ccccd    # 0.8f

    add-float v9, v2, v3

    .line 90
    .local v9, "rate":F
    iget-object v2, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v3, v0

    move v4, v1

    move v5, v1

    move v8, v9

    invoke-virtual/range {v2 .. v8}, Landroid/media/SoundPool;->play(IFFIIF)I

    .line 92
    .end local v9    # "rate":F
    :cond_9
    return-void
.end method

.method public release()V
    .locals 2

    .line 104
    iget-object v0, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 105
    invoke-virtual {v0}, Landroid/media/SoundPool;->release()V

    .line 106
    iput-object v1, p0, Lcom/EZdev/mc2/SoundManager;->soundPool:Landroid/media/SoundPool;

    .line 108
    :cond_0
    iget-object v0, p0, Lcom/EZdev/mc2/SoundManager;->reverb:Landroid/media/audiofx/EnvironmentalReverb;

    if-eqz v0, :cond_1

    .line 109
    invoke-virtual {v0}, Landroid/media/audiofx/AudioEffect;->release()V

    .line 110
    iput-object v1, p0, Lcom/EZdev/mc2/SoundManager;->reverb:Landroid/media/audiofx/EnvironmentalReverb;

    .line 112
    :cond_1
    return-void
.end method

.method public toggleSFX()V
    .locals 3

    .line 95
    iget-boolean v0, p0, Lcom/EZdev/mc2/SoundManager;->isEnabled:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/SoundManager;->isEnabled:Z

    .line 96
    iget-object v0, p0, Lcom/EZdev/mc2/SoundManager;->context:Landroid/content/Context;

    const-string v1, "McPrefs"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "SFX_ENABLED"

    iget-boolean v2, p0, Lcom/EZdev/mc2/SoundManager;->isEnabled:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 97
    return-void
.end method

.method public updateReverb(Z)V
    .locals 1
    .param p1, "inCave"    # Z

    .line 59
    iget-object v0, p0, Lcom/EZdev/mc2/SoundManager;->reverb:Landroid/media/audiofx/EnvironmentalReverb;

    if-eqz v0, :cond_0

    .line 60
    invoke-virtual {v0, p1}, Landroid/media/audiofx/AudioEffect;->setEnabled(Z)I

    .line 62
    :cond_0
    return-void
.end method
