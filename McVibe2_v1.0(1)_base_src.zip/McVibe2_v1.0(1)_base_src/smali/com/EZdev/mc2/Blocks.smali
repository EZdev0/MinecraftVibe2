.class public Lcom/EZdev/mc2/Blocks;
.super Ljava/lang/Object;
.source "Blocks.java"


# static fields
.field public static final AIR:B = 0x0t

.field public static final BEDROCK:B = 0x9t

.field public static final DIRT:B = 0xat

.field public static final ENTITY_PIG:B = 0x64t

.field public static final FIRE:B = 0x6t

.field public static final GRASS:B = 0x1t

.field public static final LEAVES:B = 0x4t

.field public static final SAND:B = 0x8t

.field public static final SMOKE:B = 0x63t

.field public static final STONE:B = 0x2t

.field public static final TNT:B = 0x5t

.field public static final WATER:B = 0x7t

.field public static final WOOD:B = 0x3t


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
