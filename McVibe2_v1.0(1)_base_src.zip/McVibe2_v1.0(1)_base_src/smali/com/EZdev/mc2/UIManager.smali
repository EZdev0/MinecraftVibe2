.class public Lcom/EZdev/mc2/UIManager;
.super Ljava/lang/Object;
.source "UIManager.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/EZdev/mc2/UIManager$TouchOverlay;
    }
.end annotation


# instance fields
.field private activity:Lcom/EZdev/mc2/MainActivity;

.field public blockIds:[B

.field private chunkText:Landroid/widget/TextView;

.field public currentGLError:Ljava/lang/String;

.field private dX:F

.field private dY:F

.field private engine:Lcom/EZdev/mc2/MyGdxGame;

.field public fastRender:Z

.field private flyBtn:Landroid/widget/Button;

.field private hotbarButtons:[Landroid/widget/Button;

.field public inventory:[I

.field private prefs:Landroid/content/SharedPreferences;

.field private settingsPanel:Landroid/widget/LinearLayout;

.field public showDebug:Z

.field public showGLWarnings:Z

.field private sneakBtn:Landroid/widget/Button;

.field private sprintBtn:Landroid/widget/Button;

.field public tntUnlocked:Z

.field public touchOverlay:Lcom/EZdev/mc2/UIManager$TouchOverlay;

.field public uiEditorMode:Z


# direct methods
.method public static synthetic $r8$lambda$-jpPDbnx0te0MD_CPna8SGN8KIA(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$18(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$0MBVUV8ceLuMORLRXGeqfWrwEsU(Lcom/EZdev/mc2/UIManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/UIManager;->lambda$addToInventory$1()V

    return-void
.end method

.method public static synthetic $r8$lambda$86xogrym8KCGgUKAaP9ZcYPLN4M(Lcom/EZdev/mc2/UIManager;Ljava/lang/String;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->lambda$reportGLError$0(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$8oPDMQnOTJgsP4jmxG2qL72-ywM(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$20(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$9tZYdwhVRzGAZV-xGLxNXSuxy8A(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createToggles$10(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$AWXPZtO-Wk1IS2a88ZSRr4y8LtI(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createActionButtons$7(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$CHrBqlmdJ2hFsgxoE-nGppQyEfQ(Lcom/EZdev/mc2/UIManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/UIManager;->lambda$addToInventory$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$D3zGc6rk7UT_YHAMtkTpHVjGU0Q(Lcom/EZdev/mc2/UIManager;Landroid/widget/ScrollView;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$21(Landroid/widget/ScrollView;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$MXOV8LkZeXNyJlq7lbyScWNmPGo(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createActionButtons$8(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$Qsei1sQ01j02WFTsrksz2Yn2gJk(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createToggles$9(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$VEVqHv9_Hybc1km-b9vg_hBFYe0(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createToggles$11(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$_DfbCrG6pRfSIaCEMH6GfGJ8q-w(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$16(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$_lZs74Q58sgF-jAN_9Sh1PIMsYU(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createActionButtons$5(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$cBX8Di49Ej5MjUUMGJNI_giF8Ro(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$19(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$cYqDVCZgIeVmsixb_3tapEvXjJc(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createActionButtons$6(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$caOUBdijvoqpGOjVnbP6xsApikM(Lcom/EZdev/mc2/UIManager;BILandroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2, p3}, Lcom/EZdev/mc2/UIManager;->lambda$createHotbar$3(BILandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$pYAFxKkQtooKQvUNe4Vizbrlt_o(Lcom/EZdev/mc2/UIManager;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$13(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$rw9J6pYj-kYXYh5rTxrN18fowu0(Lcom/EZdev/mc2/UIManager;Landroid/widget/ScrollView;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$23(Landroid/widget/ScrollView;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$sbumL7j91Yy4XM4_jfRzRC7Ncuo(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$15(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$spTcqeDFzWc_sSbWnyW4f_T1wxM(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$14(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$tOsQp5nDYgG4xLICl3Lp5wb9Cv8(Lcom/EZdev/mc2/UIManager;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$12(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$tVHvS83jlGL5Hy5hGQCcv4wgYDE(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$17(Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$u0AfpE29kMpyk8_Mwd5KLAKeMNc(Lcom/EZdev/mc2/UIManager;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/UIManager;->lambda$createHotbar$4(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$x4QMTl2tx_h1n3jOf-utpzjj_LQ(Lcom/EZdev/mc2/UIManager;Landroid/view/View;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->lambda$createSettingsMenu$22(Landroid/view/View;)V

    return-void
.end method

.method public static bridge synthetic -$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;
    .locals 0

    .line 0
    iget-object p0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    return-object p0
.end method

.method public constructor <init>(Lcom/EZdev/mc2/MainActivity;Lcom/EZdev/mc2/MyGdxGame;)V
    .locals 7
    .param p1, "activity"    # Lcom/EZdev/mc2/MainActivity;
    .param p2, "engine"    # Lcom/EZdev/mc2/MyGdxGame;

    .line 53
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    const/4 v0, 0x6

    new-array v1, v0, [Landroid/widget/Button;

    iput-object v1, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    .line 32
    new-array v1, v0, [B

    fill-array-data v1, :array_0

    iput-object v1, p0, Lcom/EZdev/mc2/UIManager;->blockIds:[B

    .line 33
    new-array v1, v0, [I

    fill-array-data v1, :array_1

    iput-object v1, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    .line 37
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    .line 38
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    .line 39
    iput-boolean v2, p0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    .line 40
    iput-boolean v1, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    .line 41
    const/4 v3, 0x0

    iput-object v3, p0, Lcom/EZdev/mc2/UIManager;->currentGLError:Ljava/lang/String;

    .line 51
    iput-boolean v2, p0, Lcom/EZdev/mc2/UIManager;->tntUnlocked:Z

    .line 54
    iput-object p1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    .line 55
    iput-object p2, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    .line 56
    const-string v3, "McPrefs"

    invoke-virtual {p1, v3, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    iput-object v3, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    .line 57
    iget-object v4, p2, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    const-string v5, "RENDER_DISTANCE"

    const/4 v6, 0x2

    invoke-interface {v3, v5, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v4, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    .line 58
    iget-object v3, p2, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-object v4, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v5, "FOG_ENABLED"

    invoke-interface {v4, v5, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    iput-boolean v4, v3, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    .line 59
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "SHOW_DEBUG"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    iput-boolean v3, p0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    .line 60
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "FAST_RENDER"

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    iput-boolean v3, p0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    .line 61
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "GL_WARN"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    .line 62
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v3, "TNT_UNLOCKED"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Lcom/EZdev/mc2/UIManager;->tntUnlocked:Z

    .line 64
    iget-object v1, p2, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v1, v1, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    const/16 v3, 0x3e7

    if-eqz v1, :cond_1

    .line 65
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v2, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .end local v1    # "i":I
    :cond_0
    goto :goto_1

    .line 68
    :cond_1
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    const/4 v1, 0x5

    aput v1, v0, v2

    .line 70
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "FIRE_UNLOCKED"

    invoke-interface {v0, v4, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aput v3, v0, v1

    .line 72
    :cond_2
    :goto_1
    return-void

    nop

    :array_0
    .array-data 1
        0x1t
        0x2t
        0x3t
        0x4t
        0x5t
        0x6t
    .end array-data

    nop

    :array_1
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
    .end array-data
.end method

.method private createActionButtons(Landroid/widget/FrameLayout;)V
    .locals 21
    .param p1, "root"    # Landroid/widget/FrameLayout;

    .line 193
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "\u2b06\ufe0f"

    const-string v3, "#3498db"

    invoke-direct {v0, v2, v3}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v2

    .line 194
    .local v2, "jumpBtn":Landroid/widget/Button;
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "jumpBtn_X"

    const/high16 v5, -0x40800000    # -1.0f

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v3

    .local v3, "jX":F
    iget-object v4, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "jumpBtn_Y"

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v4

    .line 195
    .local v4, "jY":F
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v7, -0x2

    invoke-direct {v6, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 196
    .local v6, "lpJump":Landroid/widget/FrameLayout$LayoutParams;
    cmpl-float v8, v3, v5

    const/16 v9, 0xfa

    const/16 v10, 0x32

    const v11, 0x800055

    const v12, 0x800033

    const/4 v13, 0x0

    if-eqz v8, :cond_0

    .line 197
    iput v12, v6, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 198
    invoke-virtual {v2, v3}, Landroid/view/View;->setX(F)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setY(F)V

    goto :goto_0

    .line 200
    :cond_0
    iput v11, v6, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 201
    invoke-virtual {v6, v13, v13, v10, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 203
    :goto_0
    new-instance v8, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda0;

    invoke-direct {v8, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v2, v8}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 209
    invoke-virtual {v1, v2, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 212
    const-string v8, "\u26cf\ufe0f"

    const-string v14, "#e74c3c"

    invoke-direct {v0, v8, v14}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v8

    .line 213
    .local v8, "breakBtn":Landroid/widget/Button;
    iget-object v14, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v15, "breakBtn_X"

    invoke-interface {v14, v15, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v14

    .local v14, "bX":F
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v9, "breakBtn_Y"

    invoke-interface {v15, v9, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v9

    .line 214
    .local v9, "bY":F
    new-instance v15, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v15, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 215
    .local v15, "lpBreak":Landroid/widget/FrameLayout$LayoutParams;
    cmpl-float v17, v14, v5

    const/16 v7, 0xc8

    if-eqz v17, :cond_1

    .line 216
    iput v12, v15, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 217
    invoke-virtual {v8, v14}, Landroid/view/View;->setX(F)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setY(F)V

    goto :goto_1

    .line 219
    :cond_1
    iput v11, v15, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 220
    invoke-virtual {v15, v13, v13, v7, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 222
    :goto_1
    new-instance v7, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda1;

    invoke-direct {v7, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda1;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v8, v7}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 233
    invoke-virtual {v1, v8, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 236
    const-string v7, "\ud83e\uddf1"

    const-string v10, "#2ecc71"

    invoke-direct {v0, v7, v10}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v7

    .line 237
    .local v7, "placeBtn":Landroid/widget/Button;
    iget-object v10, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v13, "placeBtn_X"

    invoke-interface {v10, v13, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v10

    .local v10, "pX":F
    iget-object v13, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "placeBtn_Y"

    invoke-interface {v13, v11, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v11

    .line 238
    .local v11, "pY":F
    new-instance v13, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v12, -0x2

    invoke-direct {v13, v12, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v12, v13

    .line 239
    .local v12, "lpPlace":Landroid/widget/FrameLayout$LayoutParams;
    cmpl-float v13, v10, v5

    if-eqz v13, :cond_2

    .line 240
    const v13, 0x800033

    iput v13, v12, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 241
    invoke-virtual {v7, v10}, Landroid/view/View;->setX(F)V

    invoke-virtual {v7, v11}, Landroid/view/View;->setY(F)V

    goto :goto_2

    .line 243
    :cond_2
    const v13, 0x800055

    iput v13, v12, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 244
    const/4 v5, 0x0

    const/16 v13, 0x32

    invoke-virtual {v12, v5, v5, v13, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 246
    :goto_2
    new-instance v5, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda2;

    invoke-direct {v5, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda2;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v7, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 250
    invoke-virtual {v1, v7, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 252
    iget-object v5, v0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v5, v5, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v5, v5, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v5, :cond_4

    .line 254
    const-string v5, "\u2694\ufe0f"

    const-string v13, "#e67e22"

    invoke-direct {v0, v5, v13}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v5

    .line 255
    .local v5, "attackBtn":Landroid/widget/Button;
    iget-object v13, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v19, v2

    .end local v2    # "jumpBtn":Landroid/widget/Button;
    .local v19, "jumpBtn":Landroid/widget/Button;
    const-string v2, "attackBtn_X"

    move/from16 v20, v3

    const/high16 v3, -0x40800000    # -1.0f

    .end local v3    # "jX":F
    .local v20, "jX":F
    invoke-interface {v13, v2, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v2

    .local v2, "aX":F
    iget-object v13, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    move/from16 v18, v4

    .end local v4    # "jY":F
    .local v18, "jY":F
    const-string v4, "attackBtn_Y"

    invoke-interface {v13, v4, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v4

    .line 256
    .local v4, "aY":F
    new-instance v13, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x2

    invoke-direct {v13, v3, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v3, v13

    .line 257
    .local v3, "lpAttack":Landroid/widget/FrameLayout$LayoutParams;
    const/high16 v13, -0x40800000    # -1.0f

    cmpl-float v13, v2, v13

    if-eqz v13, :cond_3

    .line 258
    const v13, 0x800033

    iput v13, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 259
    invoke-virtual {v5, v2}, Landroid/view/View;->setX(F)V

    invoke-virtual {v5, v4}, Landroid/view/View;->setY(F)V

    move/from16 v16, v2

    move/from16 v17, v4

    goto :goto_3

    .line 261
    :cond_3
    const v13, 0x800055

    iput v13, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 262
    move/from16 v16, v2

    move/from16 v17, v4

    const/4 v2, 0x0

    const/16 v4, 0xc8

    const/16 v13, 0xfa

    .end local v2    # "aX":F
    .end local v4    # "aY":F
    .local v16, "aX":F
    .local v17, "aY":F
    invoke-virtual {v3, v2, v2, v4, v13}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 264
    :goto_3
    new-instance v2, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda3;

    invoke-direct {v2, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda3;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v5, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 268
    invoke-virtual {v1, v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_4

    .line 252
    .end local v5    # "attackBtn":Landroid/widget/Button;
    .end local v16    # "aX":F
    .end local v17    # "aY":F
    .end local v18    # "jY":F
    .end local v19    # "jumpBtn":Landroid/widget/Button;
    .end local v20    # "jX":F
    .local v2, "jumpBtn":Landroid/widget/Button;
    .local v3, "jX":F
    .local v4, "jY":F
    :cond_4
    move-object/from16 v19, v2

    move/from16 v20, v3

    move/from16 v18, v4

    .line 270
    .end local v2    # "jumpBtn":Landroid/widget/Button;
    .end local v3    # "jX":F
    .end local v4    # "jY":F
    .restart local v18    # "jY":F
    .restart local v19    # "jumpBtn":Landroid/widget/Button;
    .restart local v20    # "jX":F
    :goto_4
    return-void
.end method

.method private createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;
    .locals 5
    .param p1, "text"    # Ljava/lang/String;
    .param p2, "color"    # Ljava/lang/String;

    .line 473
    new-instance v0, Landroid/widget/Button;

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .local v0, "b":Landroid/widget/Button;
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 474
    const/16 v2, 0x1e

    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 475
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    const/4 v4, 0x0

    invoke-direct {v2, v1, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object v1, v2

    .line 476
    .local v1, "p":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v2, 0xa

    invoke-virtual {v1, v2, v2, v2, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private createCrosshair(Landroid/widget/FrameLayout;)V
    .locals 3
    .param p1, "root"    # Landroid/widget/FrameLayout;

    .line 115
    new-instance v0, Landroid/view/View;

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 116
    .local v0, "crosshair":Landroid/view/View;
    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 117
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, 0x6

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 118
    .local v1, "params":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v2, 0x11

    iput v2, v1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 119
    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 120
    return-void
.end method

.method private createHeading(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 4
    .param p1, "text"    # Ljava/lang/String;

    .line 338
    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 339
    .local v0, "h":Landroid/widget/TextView;
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, -0xff0001

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v1, 0x41900000    # 18.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 340
    const/16 v1, 0x28

    const/16 v2, 0xa

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v1, v3, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 341
    return-object v0
.end method

.method private createHotbar(Landroid/widget/FrameLayout;)V
    .locals 9
    .param p1, "root"    # Landroid/widget/FrameLayout;

    .line 123
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 124
    .local v0, "hotbar":Landroid/widget/LinearLayout;
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 125
    const-string v2, "#80000000"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 126
    const/16 v2, 0xf

    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/view/View;->setPadding(IIII)V

    .line 128
    const-string v3, "\ud83d\udfeb"

    const-string v4, "\ud83e\udea8"

    const-string v5, "\ud83e\udeb5"

    const-string v6, "\ud83c\udf43"

    const-string v7, "\ud83e\udde8"

    const-string v8, "\ud83d\udd25"

    filled-new-array/range {v3 .. v8}, [Ljava/lang/String;

    move-result-object v2

    .line 130
    .local v2, "icons":[Ljava/lang/String;
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_0
    array-length v4, v2

    if-ge v3, v4, :cond_0

    .line 131
    new-instance v4, Landroid/widget/Button;

    iget-object v5, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v4, v5}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 132
    .local v4, "btn":Landroid/widget/Button;
    const/high16 v5, 0x41a00000    # 20.0f

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 134
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x78

    invoke-direct {v5, v6, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 135
    .local v5, "p":Landroid/widget/LinearLayout$LayoutParams;
    const/16 v6, 0xa

    invoke-virtual {v5, v6, v1, v6, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 136
    invoke-virtual {v4, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 137
    invoke-virtual {v4, v1, v1, v1, v1}, Landroid/view/View;->setPadding(IIII)V

    .line 139
    iget-object v6, p0, Lcom/EZdev/mc2/UIManager;->blockIds:[B

    aget-byte v6, v6, v3

    .line 140
    .local v6, "id":B
    move v7, v3

    .line 141
    .local v7, "slotIndex":I
    new-instance v8, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;

    invoke-direct {v8, p0, v6, v7}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda19;-><init>(Lcom/EZdev/mc2/UIManager;BI)V

    invoke-virtual {v4, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 148
    iget-object v8, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    aput-object v4, v8, v3

    .line 149
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 130
    .end local v4    # "btn":Landroid/widget/Button;
    .end local v5    # "p":Landroid/widget/LinearLayout$LayoutParams;
    .end local v6    # "id":B
    .end local v7    # "slotIndex":I
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    nop

    .line 152
    .end local v3    # "i":I
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v3, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 153
    .local v3, "params":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v4, 0x51

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 154
    const/16 v4, 0x32

    invoke-virtual {v3, v1, v1, v1, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 156
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "hotbar_X"

    const/high16 v5, -0x40800000    # -1.0f

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v1

    .local v1, "hX":F
    iget-object v4, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "hotbar_Y"

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v4

    .line 157
    .local v4, "hY":F
    cmpl-float v5, v1, v5

    if-eqz v5, :cond_1

    invoke-virtual {v0, v1}, Landroid/view/View;->setX(F)V

    invoke-virtual {v0, v4}, Landroid/view/View;->setY(F)V

    .line 158
    :cond_1
    new-instance v5, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda20;

    invoke-direct {v5, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda20;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v0, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 160
    invoke-virtual {p1, v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 161
    return-void
.end method

.method private createSettingsMenu(Landroid/widget/FrameLayout;)V
    .locals 20
    .param p1, "root"    # Landroid/widget/FrameLayout;

    .line 345
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v2, Landroid/widget/ScrollView;

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v2, v3}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 346
    .local v2, "scroll":Landroid/widget/ScrollView;
    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 348
    new-instance v3, Landroid/widget/LinearLayout;

    iget-object v4, v0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    .line 349
    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 350
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    const-string v5, "#E62c3e50"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 351
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    const/16 v5, 0x3c

    invoke-virtual {v3, v5, v5, v5, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 352
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v4}, Landroid/view/View;->setClickable(Z)V

    .line 354
    new-instance v3, Landroid/widget/TextView;

    iget-object v5, v0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v3, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 355
    .local v3, "title":Landroid/widget/TextView;
    const-string v5, "EINSTELLUNGEN"

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v5, -0x1

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41d00000    # 26.0f

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v6, 0x11

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 356
    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v7, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 358
    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    const-string v8, "--- GRAFIK ---"

    invoke-direct {v0, v8}, Lcom/EZdev/mc2/UIManager;->createHeading(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 360
    new-instance v7, Landroid/widget/TextView;

    iget-object v8, v0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v7, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v7, v0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    .line 361
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Sichtweite (Chunks): "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v9, v0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v9, v9, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget v9, v9, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 362
    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    const/16 v8, -0x100

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    const/high16 v8, 0x41a00000    # 20.0f

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    const/4 v8, 0x0

    const/16 v9, 0x14

    invoke-virtual {v7, v8, v9, v8, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 363
    iget-object v7, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    iget-object v10, v0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    invoke-virtual {v7, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 365
    new-instance v7, Landroid/widget/LinearLayout;

    iget-object v10, v0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v7, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 366
    .local v7, "plusMinus":Landroid/widget/LinearLayout;
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 367
    const-string v10, "- WENIGER"

    const-string v11, "#e74c3c"

    invoke-direct {v0, v10, v11}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v10

    .line 368
    .local v10, "minusBtn":Landroid/widget/Button;
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v11, v8, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 369
    const-string v11, "+ MEHR"

    const-string v14, "#2ecc71"

    invoke-direct {v0, v11, v14}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v11

    .line 370
    .local v11, "plusBtn":Landroid/widget/Button;
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v14, v8, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 371
    invoke-virtual {v7, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 372
    new-instance v13, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda4;

    invoke-direct {v13, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda4;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v10, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 373
    new-instance v13, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda7;

    invoke-direct {v13, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda7;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v11, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 374
    iget-object v13, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v13, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 376
    iget-object v13, v0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v13, v13, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-boolean v13, v13, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    if-eqz v13, :cond_0

    const-string v13, "NEBEL: AN"

    goto :goto_0

    :cond_0
    const-string v13, "NEBEL: AUS"

    :goto_0
    const-string v14, "#9b59b6"

    invoke-direct {v0, v13, v14}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v13

    .line 377
    .local v13, "fogBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda8;

    invoke-direct {v15, v0, v13}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda8;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v13, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 382
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 384
    iget-boolean v15, v0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    if-eqz v15, :cond_1

    const-string v15, "VULKAN (FAST RENDER): AN"

    goto :goto_1

    :cond_1
    const-string v15, "VULKAN (FAST RENDER): AUS"

    :goto_1
    const-string v8, "#e67e22"

    invoke-direct {v0, v15, v8}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v8

    .line 385
    .local v8, "vulkanBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda9;

    invoke-direct {v15, v0, v8}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda9;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v8, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 390
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 392
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    const-string v9, "--- AUDIO ---"

    invoke-direct {v0, v9}, Lcom/EZdev/mc2/UIManager;->createHeading(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v15, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 394
    iget-object v9, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v15, "MUSIC_ENABLED"

    invoke-interface {v9, v15, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    if-eqz v9, :cond_2

    const-string v9, "MUSIK: AN"

    goto :goto_2

    :cond_2
    const-string v9, "MUSIK: AUS"

    :goto_2
    const-string v15, "#1abc9c"

    invoke-direct {v0, v9, v15}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v9

    .line 395
    .local v9, "musicBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda10;

    invoke-direct {v15, v0, v9}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda10;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v9, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 401
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 403
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "SFX_ENABLED"

    invoke-interface {v15, v12, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_3

    const-string v4, "EFFEKTE: AN"

    goto :goto_3

    :cond_3
    const-string v4, "EFFEKTE: AUS"

    :goto_3
    const-string v12, "#3498db"

    invoke-direct {v0, v4, v12}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v4

    .line 404
    .local v4, "sfxBtn":Landroid/widget/Button;
    new-instance v12, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda11;

    invoke-direct {v12, v0, v4}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda11;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v4, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 410
    iget-object v12, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v12, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 412
    iget-object v12, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    const-string v15, "--- SYSTEM ---"

    invoke-direct {v0, v15}, Lcom/EZdev/mc2/UIManager;->createHeading(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v15

    invoke-virtual {v12, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 414
    iget-boolean v12, v0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    if-eqz v12, :cond_4

    const-string v12, "UI EDITOR: AN"

    goto :goto_4

    :cond_4
    const-string v12, "UI EDITOR: AUS"

    :goto_4
    const-string v15, "#f1c40f"

    invoke-direct {v0, v12, v15}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v12

    .line 415
    .local v12, "uiEditorBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda12;

    invoke-direct {v15, v0, v12}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda12;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v12, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 422
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 424
    iget-boolean v15, v0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    if-eqz v15, :cond_5

    const-string v15, "DEBUG INFO: AN"

    goto :goto_5

    :cond_5
    const-string v15, "DEBUG INFO: AUS"

    :goto_5
    invoke-direct {v0, v15, v14}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v14

    .line 425
    .local v14, "debugBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda13;

    invoke-direct {v15, v0, v14}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda13;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 430
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 432
    iget-boolean v15, v0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    if-eqz v15, :cond_6

    const-string v15, "GL-WARNUNGEN: AN"

    goto :goto_6

    :cond_6
    const-string v15, "GL-WARNUNGEN: AUS"

    :goto_6
    const-string v6, "#8e44ad"

    invoke-direct {v0, v15, v6}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v6

    .line 433
    .local v6, "glWarnBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda14;

    invoke-direct {v15, v0, v6}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda14;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/Button;)V

    invoke-virtual {v6, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 439
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 441
    const-string v15, "SCHLIESSEN"

    const-string v5, "#95a5a6"

    invoke-direct {v0, v15, v5}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v5

    .line 442
    .local v5, "closeBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda15;

    invoke-direct {v15, v0, v2}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda15;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/ScrollView;)V

    invoke-virtual {v5, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 443
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 445
    const-string v15, "HAUPTMENUE"

    move-object/from16 v18, v3

    .end local v3    # "title":Landroid/widget/TextView;
    .local v18, "title":Landroid/widget/TextView;
    const-string v3, "#c0392b"

    invoke-direct {v0, v15, v3}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v3

    .line 446
    .local v3, "menuBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda5;

    invoke-direct {v15, v0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda5;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v3, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 450
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v15, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 452
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager;->settingsPanel:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v15}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 454
    new-instance v15, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v19, v3

    const/4 v3, -0x1

    .end local v3    # "menuBtn":Landroid/widget/Button;
    .local v19, "menuBtn":Landroid/widget/Button;
    invoke-direct {v15, v3, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v3, v15

    .line 455
    .local v3, "panelParams":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v15, 0x32

    invoke-virtual {v3, v15, v15, v15, v15}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 456
    const/16 v15, 0x11

    iput v15, v3, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 457
    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 460
    const-string v15, "\u2699\ufe0f"

    move-object/from16 v17, v3

    .end local v3    # "panelParams":Landroid/widget/FrameLayout$LayoutParams;
    .local v17, "panelParams":Landroid/widget/FrameLayout$LayoutParams;
    const-string v3, "#34495e"

    invoke-direct {v0, v15, v3}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v3

    .line 461
    .local v3, "gearBtn":Landroid/widget/Button;
    new-instance v15, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda6;

    invoke-direct {v15, v0, v2}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda6;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/widget/ScrollView;)V

    invoke-virtual {v3, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 463
    new-instance v15, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v0, -0x2

    invoke-direct {v15, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v0, v15

    .line 464
    .local v0, "gearParams":Landroid/widget/FrameLayout$LayoutParams;
    const/16 v15, 0x31

    iput v15, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    move-object/from16 v16, v2

    const/16 v2, 0x14

    const/4 v15, 0x0

    .end local v2    # "scroll":Landroid/widget/ScrollView;
    .local v16, "scroll":Landroid/widget/ScrollView;
    invoke-virtual {v0, v15, v2, v15, v15}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 465
    invoke-virtual {v1, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 466
    return-void
.end method

.method private createToggles(Landroid/widget/FrameLayout;)V
    .locals 14
    .param p1, "root"    # Landroid/widget/FrameLayout;

    .line 273
    const-string v0, "Sneak"

    const-string v1, "#95a5a6"

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v0

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager;->sneakBtn:Landroid/widget/Button;

    .line 274
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v2, "sneakBtn_X"

    const/high16 v3, -0x40800000    # -1.0f

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    .local v0, "snX":F
    iget-object v2, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "sneakBtn_Y"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v2

    .line 275
    .local v2, "snY":F
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v4, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 276
    .local v4, "lpSneak":Landroid/widget/FrameLayout$LayoutParams;
    cmpl-float v6, v0, v3

    const/16 v7, 0x32

    const/4 v8, 0x0

    const v9, 0x800033

    if-eqz v6, :cond_0

    .line 277
    iput v9, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 278
    iget-object v6, p0, Lcom/EZdev/mc2/UIManager;->sneakBtn:Landroid/widget/Button;

    invoke-virtual {v6, v0}, Landroid/view/View;->setX(F)V

    iget-object v6, p0, Lcom/EZdev/mc2/UIManager;->sneakBtn:Landroid/widget/Button;

    invoke-virtual {v6, v2}, Landroid/view/View;->setY(F)V

    goto :goto_0

    .line 280
    :cond_0
    iput v9, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 281
    const/16 v6, 0x96

    invoke-virtual {v4, v7, v6, v8, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 283
    :goto_0
    iget-object v6, p0, Lcom/EZdev/mc2/UIManager;->sneakBtn:Landroid/widget/Button;

    new-instance v10, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda16;

    invoke-direct {v10, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda16;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v6, v10}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 291
    iget-object v6, p0, Lcom/EZdev/mc2/UIManager;->sneakBtn:Landroid/widget/Button;

    invoke-virtual {p1, v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 294
    const-string v6, "Sprint"

    invoke-direct {p0, v6, v1}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v6

    iput-object v6, p0, Lcom/EZdev/mc2/UIManager;->sprintBtn:Landroid/widget/Button;

    .line 295
    iget-object v6, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "sprintBtn_X"

    invoke-interface {v6, v10, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v6

    .local v6, "spX":F
    iget-object v10, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "sprintBtn_Y"

    invoke-interface {v10, v11, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v10

    .line 296
    .local v10, "spY":F
    new-instance v11, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v11, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 297
    .local v11, "lpSprint":Landroid/widget/FrameLayout$LayoutParams;
    cmpl-float v12, v6, v3

    if-eqz v12, :cond_1

    .line 298
    iput v9, v11, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 299
    iget-object v12, p0, Lcom/EZdev/mc2/UIManager;->sprintBtn:Landroid/widget/Button;

    invoke-virtual {v12, v6}, Landroid/view/View;->setX(F)V

    iget-object v12, p0, Lcom/EZdev/mc2/UIManager;->sprintBtn:Landroid/widget/Button;

    invoke-virtual {v12, v10}, Landroid/view/View;->setY(F)V

    goto :goto_1

    .line 301
    :cond_1
    iput v9, v11, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 302
    const/16 v12, 0x12c

    invoke-virtual {v11, v7, v12, v8, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 304
    :goto_1
    iget-object v12, p0, Lcom/EZdev/mc2/UIManager;->sprintBtn:Landroid/widget/Button;

    new-instance v13, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda17;

    invoke-direct {v13, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda17;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v12, v13}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 312
    iget-object v12, p0, Lcom/EZdev/mc2/UIManager;->sprintBtn:Landroid/widget/Button;

    invoke-virtual {p1, v12, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 314
    iget-object v12, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v12, v12, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v12, v12, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-eqz v12, :cond_3

    .line 316
    const-string v12, "Fly"

    invoke-direct {p0, v12, v1}, Lcom/EZdev/mc2/UIManager;->createBtn(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, p0, Lcom/EZdev/mc2/UIManager;->flyBtn:Landroid/widget/Button;

    .line 317
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "flyBtn_X"

    invoke-interface {v1, v12, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v1

    .local v1, "fX":F
    iget-object v12, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const-string v13, "flyBtn_Y"

    invoke-interface {v12, v13, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v12

    .line 318
    .local v12, "fY":F
    new-instance v13, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v13, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v5, v13

    .line 319
    .local v5, "lpFly":Landroid/widget/FrameLayout$LayoutParams;
    cmpl-float v3, v1, v3

    if-eqz v3, :cond_2

    .line 320
    iput v9, v5, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 321
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->flyBtn:Landroid/widget/Button;

    invoke-virtual {v3, v1}, Landroid/view/View;->setX(F)V

    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->flyBtn:Landroid/widget/Button;

    invoke-virtual {v3, v12}, Landroid/view/View;->setY(F)V

    goto :goto_2

    .line 323
    :cond_2
    iput v9, v5, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 324
    const/16 v3, 0x1c2

    invoke-virtual {v5, v7, v3, v8, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 326
    :goto_2
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->flyBtn:Landroid/widget/Button;

    new-instance v7, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda18;

    invoke-direct {v7, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda18;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v3, v7}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 334
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->flyBtn:Landroid/widget/Button;

    invoke-virtual {p1, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 336
    .end local v1    # "fX":F
    .end local v5    # "lpFly":Landroid/widget/FrameLayout$LayoutParams;
    .end local v12    # "fY":F
    :cond_3
    return-void
.end method

.method private handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;
    .param p3, "idKey"    # Ljava/lang/String;

    .line 573
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    if-eqz v0, :cond_3

    .line 574
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    .line 575
    invoke-virtual {p1}, Landroid/view/View;->getX()F

    move-result v0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v2

    sub-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/UIManager;->dX:F

    .line 576
    invoke-virtual {p1}, Landroid/view/View;->getY()F

    move-result v0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v2

    sub-float/2addr v0, v2

    iput v0, p0, Lcom/EZdev/mc2/UIManager;->dY:F

    goto :goto_0

    .line 577
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v2, 0x2

    if-ne v0, v2, :cond_1

    .line 578
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v2, p0, Lcom/EZdev/mc2/UIManager;->dX:F

    add-float/2addr v0, v2

    invoke-virtual {p1, v0}, Landroid/view/View;->setX(F)V

    .line 579
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iget v2, p0, Lcom/EZdev/mc2/UIManager;->dY:F

    add-float/2addr v0, v2

    invoke-virtual {p1, v0}, Landroid/view/View;->setY(F)V

    goto :goto_0

    .line 580
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-ne v0, v1, :cond_2

    .line 581
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "_X"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Landroid/view/View;->getX()F

    move-result v3

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "_Y"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Landroid/view/View;->getY()F

    move-result v3

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 583
    :cond_2
    :goto_0
    return v1

    .line 585
    :cond_3
    const/4 v0, 0x0

    return v0
.end method

.method private synthetic lambda$addToInventory$1()V
    .locals 3

    .line 87
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    const-string v1, "ACHIEVEMENT: FEUERZEUG FREIGESCHALTET!"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$addToInventory$2()V
    .locals 3

    .line 92
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    const-string v1, "ACHIEVEMENT: TNT GEFUNDEN!"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$createActionButtons$5(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 204
    const-string v0, "jumpBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 205
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput-boolean v1, v0, Lcom/EZdev/mc2/Gameplay;->wantsToJump:Z

    goto :goto_0

    .line 206
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-eq v0, v1, :cond_2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v2, 0x3

    if-ne v0, v2, :cond_3

    :cond_2
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    const/4 v2, 0x0

    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->wantsToJump:Z

    .line 207
    :cond_3
    :goto_0
    return v1
.end method

.method private synthetic lambda$createActionButtons$6(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 223
    const-string v0, "breakBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 224
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_2

    .line 225
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v3, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v4, v3, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-eqz v4, :cond_1

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    invoke-virtual {v0, v3, v2, p0}, Lcom/EZdev/mc2/WorldLogic;->interact(Lcom/EZdev/mc2/Gameplay;ZLcom/EZdev/mc2/UIManager;)V

    goto :goto_0

    .line 226
    :cond_1
    iput-boolean v1, v3, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    goto :goto_0

    .line 227
    :cond_2
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-eq v0, v1, :cond_3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v3, 0x3

    if-ne v0, v3, :cond_4

    .line 228
    :cond_3
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    .line 229
    const/4 v2, 0x0

    iput v2, v0, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    .line 231
    :cond_4
    :goto_0
    return v1
.end method

.method private synthetic lambda$createActionButtons$7(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 247
    const-string v0, "placeBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 248
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v2, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    invoke-virtual {v2, v0, v1, p0}, Lcom/EZdev/mc2/WorldLogic;->interact(Lcom/EZdev/mc2/Gameplay;ZLcom/EZdev/mc2/UIManager;)V

    :cond_1
    return v1
.end method

.method private synthetic lambda$createActionButtons$8(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 4
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 265
    const-string v0, "attackBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 266
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v2, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3, p0}, Lcom/EZdev/mc2/WorldLogic;->interact(Lcom/EZdev/mc2/Gameplay;ZLcom/EZdev/mc2/UIManager;)V

    :cond_1
    return v1
.end method

.method private synthetic lambda$createHotbar$3(BILandroid/view/View;)V
    .locals 1
    .param p1, "id"    # B
    .param p2, "slotIndex"    # I
    .param p3, "v"    # Landroid/view/View;

    .line 142
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    if-eqz v0, :cond_0

    return-void

    .line 143
    :cond_0
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput-byte p1, v0, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    .line 144
    iput p2, v0, Lcom/EZdev/mc2/Gameplay;->activeSlot:I

    .line 145
    invoke-virtual {p0}, Lcom/EZdev/mc2/UIManager;->updateHotbarUI()V

    .line 146
    return-void
.end method

.method private synthetic lambda$createHotbar$4(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 1
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 158
    const-string v0, "hotbar"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private synthetic lambda$createSettingsMenu$12(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 372
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget v1, v0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    const/4 v2, 0x1

    if-le v1, v2, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    invoke-direct {p0}, Lcom/EZdev/mc2/UIManager;->updatePrefs()V

    :cond_0
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$13(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 373
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget v1, v0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    const/4 v2, 0x6

    if-ge v1, v2, :cond_0

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    invoke-direct {p0}, Lcom/EZdev/mc2/UIManager;->updatePrefs()V

    :cond_0
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$14(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "fogBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 378
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-boolean v1, v0, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    xor-int/lit8 v1, v1, 0x1

    iput-boolean v1, v0, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    .line 379
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-boolean v1, v1, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    const-string v2, "FOG_ENABLED"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 380
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-boolean v0, v0, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    if-eqz v0, :cond_0

    const-string v0, "NEBEL: AN"

    goto :goto_0

    :cond_0
    const-string v0, "NEBEL: AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 381
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$15(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "vulkanBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 386
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    .line 387
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "FAST_RENDER"

    iget-boolean v2, p0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 388
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    if-eqz v0, :cond_0

    const-string v0, "VULKAN (FAST RENDER): AN"

    goto :goto_0

    :cond_0
    const-string v0, "VULKAN (FAST RENDER): AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 389
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$16(Landroid/widget/Button;Landroid/view/View;)V
    .locals 1
    .param p1, "musicBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 396
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v0, v0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    if-eqz v0, :cond_1

    .line 397
    invoke-virtual {v0}, Lcom/EZdev/mc2/MusicManager;->toggleMusic()V

    .line 398
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v0, v0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    invoke-virtual {v0}, Lcom/EZdev/mc2/MusicManager;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "MUSIK: AN"

    goto :goto_0

    :cond_0
    const-string v0, "MUSIK: AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 400
    :cond_1
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$17(Landroid/widget/Button;Landroid/view/View;)V
    .locals 1
    .param p1, "sfxBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 405
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v0, v0, Lcom/EZdev/mc2/MainActivity;->soundManager:Lcom/EZdev/mc2/SoundManager;

    if-eqz v0, :cond_1

    .line 406
    invoke-virtual {v0}, Lcom/EZdev/mc2/SoundManager;->toggleSFX()V

    .line 407
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v0, v0, Lcom/EZdev/mc2/MainActivity;->soundManager:Lcom/EZdev/mc2/SoundManager;

    invoke-virtual {v0}, Lcom/EZdev/mc2/SoundManager;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "EFFEKTE: AN"

    goto :goto_0

    :cond_0
    const-string v0, "EFFEKTE: AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 409
    :cond_1
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$18(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "uiEditorBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 416
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    const/4 v1, 0x1

    xor-int/2addr v0, v1

    iput-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    .line 417
    if-eqz v0, :cond_0

    const-string v0, "UI EDITOR: AN"

    goto :goto_0

    :cond_0
    const-string v0, "UI EDITOR: AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 418
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->uiEditorMode:Z

    if-eqz v0, :cond_1

    .line 419
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    const-string v2, "Verschiebe Buttons mit Touch. Druecke SCHLIESSEN zum Speichern."

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 421
    :cond_1
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$19(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "debugBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 426
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    .line 427
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "SHOW_DEBUG"

    iget-boolean v2, p0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 428
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    if-eqz v0, :cond_0

    const-string v0, "DEBUG INFO: AN"

    goto :goto_0

    :cond_0
    const-string v0, "DEBUG INFO: AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 429
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$20(Landroid/widget/Button;Landroid/view/View;)V
    .locals 3
    .param p1, "glWarnBtn"    # Landroid/widget/Button;
    .param p2, "v"    # Landroid/view/View;

    .line 434
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    .line 435
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "GL_WARN"

    iget-boolean v2, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 436
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    if-eqz v0, :cond_0

    const-string v0, "GL-WARNUNGEN: AN"

    goto :goto_0

    :cond_0
    const-string v0, "GL-WARNUNGEN: AUS"

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 437
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    if-nez v0, :cond_1

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager;->currentGLError:Ljava/lang/String;

    .line 438
    :cond_1
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$21(Landroid/widget/ScrollView;Landroid/view/View;)V
    .locals 2
    .param p1, "scroll"    # Landroid/widget/ScrollView;
    .param p2, "v"    # Landroid/view/View;

    .line 442
    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->touchOverlay:Lcom/EZdev/mc2/UIManager$TouchOverlay;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private synthetic lambda$createSettingsMenu$22(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 447
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    iget-object v0, v0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/EZdev/mc2/MusicManager;->stopMusic()V

    .line 448
    :cond_0
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 449
    return-void
.end method

.method private synthetic lambda$createSettingsMenu$23(Landroid/widget/ScrollView;Landroid/view/View;)V
    .locals 2
    .param p1, "scroll"    # Landroid/widget/ScrollView;
    .param p2, "v"    # Landroid/view/View;

    .line 461
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->touchOverlay:Lcom/EZdev/mc2/UIManager$TouchOverlay;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method private synthetic lambda$createToggles$10(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 305
    const-string v0, "sprintBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 306
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-ne v0, v1, :cond_2

    .line 307
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isSprinting:Z

    xor-int/2addr v2, v1

    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isSprinting:Z

    .line 308
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->sprintBtn:Landroid/widget/Button;

    if-eqz v2, :cond_1

    const-string v2, "#2ecc71"

    goto :goto_0

    :cond_1
    const-string v2, "#95a5a6"

    :goto_0
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 310
    :cond_2
    return v1
.end method

.method private synthetic lambda$createToggles$11(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 327
    const-string v0, "flyBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 328
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-ne v0, v1, :cond_2

    .line 329
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    xor-int/2addr v2, v1

    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    .line 330
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->flyBtn:Landroid/widget/Button;

    if-eqz v2, :cond_1

    const-string v2, "#2ecc71"

    goto :goto_0

    :cond_1
    const-string v2, "#95a5a6"

    :goto_0
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 332
    :cond_2
    return v1
.end method

.method private synthetic lambda$createToggles$9(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3
    .param p1, "v"    # Landroid/view/View;
    .param p2, "e"    # Landroid/view/MotionEvent;

    .line 284
    const-string v0, "sneakBtn"

    invoke-direct {p0, p1, p2, v0}, Lcom/EZdev/mc2/UIManager;->handleTouch(Landroid/view/View;Landroid/view/MotionEvent;Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 285
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-ne v0, v1, :cond_2

    .line 286
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v0, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    xor-int/2addr v2, v1

    iput-boolean v2, v0, Lcom/EZdev/mc2/Gameplay;->isSneaking:Z

    .line 287
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->sneakBtn:Landroid/widget/Button;

    if-eqz v2, :cond_1

    const-string v2, "#2ecc71"

    goto :goto_0

    :cond_1
    const-string v2, "#95a5a6"

    :goto_0
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 289
    :cond_2
    return v1
.end method

.method private synthetic lambda$reportGLError$0(Ljava/lang/String;)V
    .locals 3
    .param p1, "errorMsg"    # Ljava/lang/String;

    .line 47
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "OpenGL Error: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lcom/EZdev/mc2/McApp;->triggerCrashHandler(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 48
    return-void
.end method

.method private updatePrefs()V
    .locals 3

    .line 468
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget v1, v1, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    const-string v2, "RENDER_DISTANCE"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 469
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->chunkText:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Sichtweite (Chunks): "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v2, v2, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget v2, v2, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 470
    return-void
.end method


# virtual methods
.method public addToInventory(BI)I
    .locals 8
    .param p1, "type"    # B
    .param p2, "amount"    # I

    .line 75
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->blockIds:[B

    array-length v2, v1

    if-ge v0, v2, :cond_4

    .line 76
    aget-byte v1, v1, v0

    if-ne v1, p1, :cond_3

    .line 77
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aget v2, v1, v0

    add-int/2addr v2, p2

    aput v2, v1, v0

    .line 78
    const/4 v3, 0x0

    .line 79
    .local v3, "rest":I
    const/16 v4, 0x3e7

    const/16 v5, 0x40

    if-le v2, v5, :cond_0

    if-eq v2, v4, :cond_0

    .line 80
    add-int/lit8 v3, v2, -0x40

    .line 81
    aput v5, v1, v0

    .line 84
    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v5, 0x1

    if-ne p1, v1, :cond_1

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    const/4 v6, 0x0

    const-string v7, "FIRE_UNLOCKED"

    invoke-interface {v1, v7, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_1

    .line 85
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v7, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 86
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aput v4, v1, v2

    .line 87
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v4, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda22;

    invoke-direct {v4, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda22;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v1, v4}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 89
    :cond_1
    if-ne p1, v2, :cond_2

    iget-boolean v1, p0, Lcom/EZdev/mc2/UIManager;->tntUnlocked:Z

    if-nez v1, :cond_2

    .line 90
    iput-boolean v5, p0, Lcom/EZdev/mc2/UIManager;->tntUnlocked:Z

    .line 91
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "TNT_UNLOCKED"

    invoke-interface {v1, v2, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 92
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v2, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda23;

    invoke-direct {v2, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda23;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v1, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 95
    :cond_2
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v2, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda24;

    invoke-direct {v2, p0}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda24;-><init>(Lcom/EZdev/mc2/UIManager;)V

    invoke-virtual {v1, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 96
    return v3

    .line 75
    .end local v3    # "rest":I
    :cond_3
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    nop

    .line 99
    .end local v0    # "i":I
    return p2
.end method

.method public reportGLError(Ljava/lang/String;)V
    .locals 2
    .param p1, "errorMsg"    # Ljava/lang/String;

    .line 44
    iget-boolean v0, p0, Lcom/EZdev/mc2/UIManager;->showGLWarnings:Z

    if-nez v0, :cond_0

    return-void

    .line 45
    :cond_0
    iput-object p1, p0, Lcom/EZdev/mc2/UIManager;->currentGLError:Ljava/lang/String;

    .line 46
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v1, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda21;

    invoke-direct {v1, p0, p1}, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda21;-><init>(Lcom/EZdev/mc2/UIManager;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 49
    return-void
.end method

.method public setupUI(Landroid/widget/FrameLayout;)V
    .locals 2
    .param p1, "root"    # Landroid/widget/FrameLayout;

    .line 102
    new-instance v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager;->activity:Lcom/EZdev/mc2/MainActivity;

    invoke-direct {v0, p0, v1}, Lcom/EZdev/mc2/UIManager$TouchOverlay;-><init>(Lcom/EZdev/mc2/UIManager;Landroid/content/Context;)V

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager;->touchOverlay:Lcom/EZdev/mc2/UIManager$TouchOverlay;

    .line 103
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 105
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->createCrosshair(Landroid/widget/FrameLayout;)V

    .line 106
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->createHotbar(Landroid/widget/FrameLayout;)V

    .line 107
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->createActionButtons(Landroid/widget/FrameLayout;)V

    .line 108
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->createToggles(Landroid/widget/FrameLayout;)V

    .line 109
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/UIManager;->createSettingsMenu(Landroid/widget/FrameLayout;)V

    .line 111
    invoke-virtual {p0}, Lcom/EZdev/mc2/UIManager;->updateHotbarUI()V

    .line 112
    return-void
.end method

.method public updateHotbarUI()V
    .locals 6

    .line 163
    const-string v0, "\ud83d\udfeb"

    const-string v1, "\ud83e\udea8"

    const-string v2, "\ud83e\udeb5"

    const-string v3, "\ud83c\udf43"

    const-string v4, "\ud83e\udde8"

    const-string v5, "\ud83d\udd25"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/String;

    move-result-object v0

    .line 164
    .local v0, "icons":[Ljava/lang/String;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_0
    iget-object v2, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    array-length v2, v2

    if-ge v1, v2, :cond_4

    .line 165
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 166
    .local v2, "shape":Landroid/graphics/drawable/GradientDrawable;
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 168
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-byte v3, v3, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    iget-object v4, p0, Lcom/EZdev/mc2/UIManager;->blockIds:[B

    aget-byte v4, v4, v1

    if-ne v3, v4, :cond_0

    .line 169
    const/16 v3, 0x8

    const/16 v4, -0x100

    invoke-virtual {v2, v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    goto :goto_1

    .line 171
    :cond_0
    const-string v3, "#222222"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    const/4 v4, 0x4

    invoke-virtual {v2, v4, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 174
    :goto_1
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->engine:Lcom/EZdev/mc2/MyGdxGame;

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v3, v3, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    const-string v4, "#555555"

    if-eqz v3, :cond_1

    .line 175
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 176
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    aget-object v3, v3, v1

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 178
    :cond_1
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aget v3, v3, v1

    if-lez v3, :cond_3

    .line 179
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 180
    const/4 v3, 0x5

    if-ne v1, v3, :cond_2

    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aget v3, v3, v1

    const/16 v4, 0x3e7

    if-ne v3, v4, :cond_2

    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    aget-object v3, v3, v1

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 181
    :cond_2
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    aget-object v3, v3, v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v0, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "\n"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aget v5, v5, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 183
    :cond_3
    const-string v3, "#88111111"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 184
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    aget-object v3, v3, v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v0, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "\n0"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 187
    :goto_2
    iget-object v3, p0, Lcom/EZdev/mc2/UIManager;->hotbarButtons:[Landroid/widget/Button;

    aget-object v3, v3, v1

    invoke-virtual {v3, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 164
    .end local v2    # "shape":Landroid/graphics/drawable/GradientDrawable;
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_4
    nop

    .line 189
    .end local v1    # "i":I
    return-void
.end method
