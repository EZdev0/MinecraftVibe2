.class public Lcom/EZdev/mc2/MyGdxGame;
.super Ljava/lang/Object;
.source "MyGdxGame.java"

# interfaces
.implements Landroid/opengl/GLSurfaceView$Renderer;


# static fields
.field private static final TAG:Ljava/lang/String; = "MyGdxGame"


# instance fields
.field public activity:Lcom/EZdev/mc2/MainActivity;

.field public currentFPS:I

.field private frames:I

.field public gameplay:Lcom/EZdev/mc2/Gameplay;

.field private lastFPSUpdate:J

.field private lastTime:J

.field private projectionMatrix:[F

.field private final random:Ljava/security/SecureRandom;

.field private screenRatio:F

.field private viewMatrix:[F

.field private vpMatrix:[F

.field public world:Lcom/EZdev/mc2/WorldLogic;


# direct methods
.method public constructor <init>(Lcom/EZdev/mc2/MainActivity;)V
    .locals 4
    .param p1, "act"    # Lcom/EZdev/mc2/MainActivity;

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/MyGdxGame;->random:Ljava/security/SecureRandom;

    .line 18
    new-instance v0, Lcom/EZdev/mc2/Gameplay;

    invoke-direct {v0}, Lcom/EZdev/mc2/Gameplay;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    .line 19
    new-instance v0, Lcom/EZdev/mc2/WorldLogic;

    invoke-direct {v0}, Lcom/EZdev/mc2/WorldLogic;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    .line 22
    const/16 v1, 0x10

    new-array v2, v1, [F

    iput-object v2, p0, Lcom/EZdev/mc2/MyGdxGame;->projectionMatrix:[F

    .line 23
    new-array v2, v1, [F

    iput-object v2, p0, Lcom/EZdev/mc2/MyGdxGame;->viewMatrix:[F

    .line 24
    new-array v1, v1, [F

    iput-object v1, p0, Lcom/EZdev/mc2/MyGdxGame;->vpMatrix:[F

    .line 28
    const/4 v1, 0x0

    iput v1, p0, Lcom/EZdev/mc2/MyGdxGame;->frames:I

    .line 29
    const-wide/16 v2, 0x0

    iput-wide v2, p0, Lcom/EZdev/mc2/MyGdxGame;->lastFPSUpdate:J

    .line 30
    iput v1, p0, Lcom/EZdev/mc2/MyGdxGame;->currentFPS:I

    .line 32
    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Lcom/EZdev/mc2/MyGdxGame;->screenRatio:F

    .line 35
    iput-object p1, p0, Lcom/EZdev/mc2/MyGdxGame;->activity:Lcom/EZdev/mc2/MainActivity;

    .line 36
    iget-object v1, p0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput-object p1, v1, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    .line 37
    new-instance v1, Lcom/EZdev/mc2/SaveManager;

    invoke-direct {v1, p1}, Lcom/EZdev/mc2/SaveManager;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->saveManager:Lcom/EZdev/mc2/SaveManager;

    .line 38
    return-void
.end method


# virtual methods
.method public onDrawFrame(Ljavax/microedition/khronos/opengles/GL10;)V
    .locals 31
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;

    .line 72
    move-object/from16 v0, p0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    .line 73
    .local v1, "now":J
    iget-wide v3, v0, Lcom/EZdev/mc2/MyGdxGame;->lastTime:J

    sub-long v3, v1, v3

    long-to-float v3, v3

    const v4, 0x4e6e6b28    # 1.0E9f

    div-float/2addr v3, v4

    .line 74
    .local v3, "dt":F
    iput-wide v1, v0, Lcom/EZdev/mc2/MyGdxGame;->lastTime:J

    .line 76
    iget v4, v0, Lcom/EZdev/mc2/MyGdxGame;->frames:I

    add-int/lit8 v4, v4, 0x1

    iput v4, v0, Lcom/EZdev/mc2/MyGdxGame;->frames:I

    .line 77
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iget-wide v6, v0, Lcom/EZdev/mc2/MyGdxGame;->lastFPSUpdate:J

    sub-long/2addr v4, v6

    const-wide/16 v6, 0x3e8

    cmp-long v4, v4, v6

    if-ltz v4, :cond_0

    .line 78
    iget v4, v0, Lcom/EZdev/mc2/MyGdxGame;->frames:I

    iput v4, v0, Lcom/EZdev/mc2/MyGdxGame;->currentFPS:I

    .line 79
    const/4 v4, 0x0

    iput v4, v0, Lcom/EZdev/mc2/MyGdxGame;->frames:I

    .line 80
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iput-wide v4, v0, Lcom/EZdev/mc2/MyGdxGame;->lastFPSUpdate:J

    .line 83
    :cond_0
    iget-object v4, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    invoke-virtual {v4, v3, v5}, Lcom/EZdev/mc2/Gameplay;->update(FLcom/EZdev/mc2/WorldLogic;)V

    .line 85
    iget-object v4, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v6, v5, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v5, v5, Lcom/EZdev/mc2/Gameplay;->camZ:F

    invoke-virtual {v4, v6, v5}, Lcom/EZdev/mc2/WorldLogic;->updateChunks(FF)V

    .line 87
    iget-object v4, v0, Lcom/EZdev/mc2/MyGdxGame;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v4, :cond_1

    iget-object v4, v4, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    if-eqz v4, :cond_1

    iget-object v4, v4, Lcom/EZdev/mc2/UIManager;->touchOverlay:Lcom/EZdev/mc2/UIManager$TouchOverlay;

    if-eqz v4, :cond_1

    .line 88
    invoke-virtual {v4}, Landroid/view/View;->postInvalidate()V

    .line 91
    :cond_1
    const/high16 v4, 0x428c0000    # 70.0f

    .line 92
    .local v4, "fov":F
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v6, v5, Lcom/EZdev/mc2/Gameplay;->isSprinting:Z

    if-nez v6, :cond_2

    iget-boolean v5, v5, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    if-eqz v5, :cond_3

    :cond_2
    const/high16 v4, 0x42b40000    # 90.0f

    .line 93
    :cond_3
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->projectionMatrix:[F

    const/4 v6, 0x0

    iget v8, v0, Lcom/EZdev/mc2/MyGdxGame;->screenRatio:F

    const v9, 0x3dcccccd    # 0.1f

    const/high16 v10, 0x43960000    # 300.0f

    move v7, v4

    invoke-static/range {v5 .. v10}, Landroid/opengl/Matrix;->perspectiveM([FIFFFF)V

    .line 95
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v6, v5, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v7, v5, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v6, v7

    const v7, 0x3e4ccccd    # 0.2f

    sub-float/2addr v6, v7

    .line 97
    .local v6, "eyeHeight":F
    const/4 v7, 0x0

    .local v7, "shakeX":F
    const/4 v8, 0x0

    .local v8, "shakeY":F
    const/4 v9, 0x0

    .line 98
    .local v9, "shakeZ":F
    iget v5, v5, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    const/4 v10, 0x0

    cmpl-float v5, v5, v10

    if-lez v5, :cond_4

    .line 99
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->random:Ljava/security/SecureRandom;

    invoke-virtual {v5}, Ljava/util/Random;->nextFloat()F

    move-result v5

    const/high16 v10, 0x3f000000    # 0.5f

    sub-float/2addr v5, v10

    iget-object v11, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v11, v11, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    mul-float v7, v5, v11

    .line 100
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->random:Ljava/security/SecureRandom;

    invoke-virtual {v5}, Ljava/util/Random;->nextFloat()F

    move-result v5

    sub-float/2addr v5, v10

    iget-object v11, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v11, v11, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    mul-float v8, v5, v11

    .line 101
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->random:Ljava/security/SecureRandom;

    invoke-virtual {v5}, Ljava/util/Random;->nextFloat()F

    move-result v5

    sub-float/2addr v5, v10

    iget-object v10, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v10, v10, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    mul-float v9, v5, v10

    .line 104
    :cond_4
    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v5, v5, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v10, v5

    invoke-static {v10, v11}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    move-result-wide v10

    iget-object v5, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v5, v5, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v12, v5

    invoke-static {v12, v13}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v12

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    mul-double/2addr v10, v12

    double-to-float v5, v10

    .line 105
    .local v5, "dirX":F
    iget-object v10, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v10, v10, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v10, v10

    .line 106
    .local v10, "dirY":F
    iget-object v11, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v11, v11, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v11, v11

    invoke-static {v11, v12}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v11

    invoke-static {v11, v12}, Ljava/lang/Math;->cos(D)D

    move-result-wide v11

    neg-double v11, v11

    iget-object v13, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v13, v13, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v13, v13

    invoke-static {v13, v14}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Math;->cos(D)D

    move-result-wide v13

    mul-double/2addr v11, v13

    double-to-float v11, v11

    .line 108
    .local v11, "dirZ":F
    iget-object v12, v0, Lcom/EZdev/mc2/MyGdxGame;->viewMatrix:[F

    const/4 v13, 0x0

    iget-object v14, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v15, v14, Lcom/EZdev/mc2/Gameplay;->camX:F

    add-float v16, v15, v7

    add-float v17, v6, v8

    iget v14, v14, Lcom/EZdev/mc2/Gameplay;->camZ:F

    add-float v18, v14, v9

    add-float/2addr v15, v5

    add-float v19, v15, v7

    add-float v15, v6, v10

    add-float v20, v15, v8

    add-float/2addr v14, v11

    add-float v21, v14, v9

    const/16 v22, 0x0

    const/high16 v23, 0x3f800000    # 1.0f

    const/16 v24, 0x0

    move/from16 v14, v16

    move/from16 v15, v17

    move/from16 v16, v18

    move/from16 v17, v19

    move/from16 v18, v20

    move/from16 v19, v21

    move/from16 v20, v22

    move/from16 v21, v23

    move/from16 v22, v24

    invoke-static/range {v12 .. v22}, Landroid/opengl/Matrix;->setLookAtM([FIFFFFFFFFF)V

    .line 112
    iget-object v12, v0, Lcom/EZdev/mc2/MyGdxGame;->vpMatrix:[F

    const/16 v26, 0x0

    iget-object v13, v0, Lcom/EZdev/mc2/MyGdxGame;->projectionMatrix:[F

    const/16 v28, 0x0

    iget-object v14, v0, Lcom/EZdev/mc2/MyGdxGame;->viewMatrix:[F

    const/16 v30, 0x0

    move-object/from16 v25, v12

    move-object/from16 v27, v13

    move-object/from16 v29, v14

    invoke-static/range {v25 .. v30}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 114
    const/16 v12, 0x4100

    invoke-static {v12}, Landroid/opengl/GLES20;->glClear(I)V

    .line 116
    sget v12, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    invoke-static {v12}, Landroid/opengl/GLES20;->glUseProgram(I)V

    .line 117
    sget v12, Lcom/EZdev/mc2/Booster;->timeHandle:I

    iget-object v13, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v13, v13, Lcom/EZdev/mc2/Gameplay;->gameTime:F

    invoke-static {v12, v13}, Landroid/opengl/GLES20;->glUniform1f(IF)V

    .line 119
    iget-object v12, v0, Lcom/EZdev/mc2/MyGdxGame;->world:Lcom/EZdev/mc2/WorldLogic;

    iget-object v13, v0, Lcom/EZdev/mc2/MyGdxGame;->vpMatrix:[F

    iget-object v14, v0, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    invoke-virtual {v12, v13, v14}, Lcom/EZdev/mc2/WorldLogic;->render([FLcom/EZdev/mc2/Gameplay;)V

    .line 121
    invoke-static {}, Landroid/opengl/GLES20;->glGetError()I

    move-result v12

    .line 122
    .local v12, "error":I
    if-eqz v12, :cond_5

    iget-object v13, v0, Lcom/EZdev/mc2/MyGdxGame;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v13, :cond_5

    iget-object v13, v13, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    if-eqz v13, :cond_5

    .line 123
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "OpenGL Fehler Code: "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Lcom/EZdev/mc2/UIManager;->reportGLError(Ljava/lang/String;)V

    .line 125
    :cond_5
    return-void
.end method

.method public onSurfaceChanged(Ljavax/microedition/khronos/opengles/GL10;II)V
    .locals 8
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;
    .param p2, "width"    # I
    .param p3, "height"    # I

    .line 65
    const/4 v0, 0x0

    invoke-static {v0, v0, p2, p3}, Landroid/opengl/GLES20;->glViewport(IIII)V

    .line 66
    int-to-float v0, p2

    int-to-float v1, p3

    div-float v5, v0, v1

    iput v5, p0, Lcom/EZdev/mc2/MyGdxGame;->screenRatio:F

    .line 67
    iget-object v2, p0, Lcom/EZdev/mc2/MyGdxGame;->projectionMatrix:[F

    const/4 v3, 0x0

    const/high16 v4, 0x428c0000    # 70.0f

    const v6, 0x3dcccccd    # 0.1f

    const/high16 v7, 0x43960000    # 300.0f

    invoke-static/range {v2 .. v7}, Landroid/opengl/Matrix;->perspectiveM([FIFFFF)V

    .line 68
    return-void
.end method

.method public onSurfaceCreated(Ljavax/microedition/khronos/opengles/GL10;Ljavax/microedition/khronos/egl/EGLConfig;)V
    .locals 4
    .param p1, "gl"    # Ljavax/microedition/khronos/opengles/GL10;
    .param p2, "config"    # Ljavax/microedition/khronos/egl/EGLConfig;

    .line 42
    const v0, 0x3f4ccccd    # 0.8f

    const/high16 v1, 0x3f800000    # 1.0f

    const/high16 v2, 0x3f000000    # 0.5f

    invoke-static {v2, v0, v1, v1}, Landroid/opengl/GLES20;->glClearColor(FFFF)V

    .line 43
    const/16 v0, 0xb71

    invoke-static {v0}, Landroid/opengl/GLES20;->glEnable(I)V

    .line 44
    const/16 v0, 0xb44

    invoke-static {v0}, Landroid/opengl/GLES20;->glDisable(I)V

    .line 46
    iget-object v0, p0, Lcom/EZdev/mc2/MyGdxGame;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v0, :cond_0

    .line 47
    const-string v1, "McPrefs"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 48
    .local v0, "prefs":Landroid/content/SharedPreferences;
    const-string v1, "FAST_RENDER"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 51
    :try_start_0
    invoke-static {}, Landroid/opengl/EGL14;->eglGetCurrentDisplay()Landroid/opengl/EGLDisplay;

    move-result-object v1

    invoke-static {v1, v2}, Landroid/opengl/EGL14;->eglSwapInterval(Landroid/opengl/EGLDisplay;I)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 54
    goto :goto_0

    .line 52
    :catch_0
    move-exception v1

    .line 53
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "MyGdxGame"

    const-string v3, "Failed to disable VSync"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 58
    .end local v0    # "prefs":Landroid/content/SharedPreferences;
    .end local v1    # "e":Ljava/lang/Exception;
    :cond_0
    :goto_0
    invoke-static {}, Lcom/EZdev/mc2/Booster;->initGeometry()V

    .line 59
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/EZdev/mc2/MyGdxGame;->lastTime:J

    .line 60
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/EZdev/mc2/MyGdxGame;->lastFPSUpdate:J

    .line 61
    return-void
.end method
