.class public final synthetic Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/CrashHandlerActivity;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/CrashHandlerActivity;Z)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;->f$0:Lcom/EZdev/mc2/CrashHandlerActivity;

    iput-boolean p2, p0, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;->f$1:Z

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;->f$0:Lcom/EZdev/mc2/CrashHandlerActivity;

    iget-boolean v1, p0, Lcom/EZdev/mc2/CrashHandlerActivity$$ExternalSyntheticLambda2;->f$1:Z

    invoke-static {v0, v1, p1}, Lcom/EZdev/mc2/CrashHandlerActivity;->$r8$lambda$JjTcvOqTjy_CWSzvEn2edPSM_rM(Lcom/EZdev/mc2/CrashHandlerActivity;ZLandroid/view/View;)V

    return-void
.end method
