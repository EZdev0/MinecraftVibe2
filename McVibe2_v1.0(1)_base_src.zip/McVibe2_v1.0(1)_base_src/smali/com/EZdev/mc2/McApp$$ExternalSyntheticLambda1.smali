.class public final synthetic Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/McApp;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/McApp;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda1;->f$0:Lcom/EZdev/mc2/McApp;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda1;->f$0:Lcom/EZdev/mc2/McApp;

    invoke-static {v0}, Lcom/EZdev/mc2/McApp;->$r8$lambda$OD2XPgqwR_TLKFjnPvxDhWcb8iU(Lcom/EZdev/mc2/McApp;)V

    return-void
.end method
