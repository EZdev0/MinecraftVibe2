.class public Lcom/EZdev/mc2/WorldLogic;
.super Ljava/lang/Object;
.source "WorldLogic.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    }
.end annotation


# instance fields
.field private chunks:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Long;",
            "Lcom/EZdev/mc2/Chunk;",
            ">;"
        }
    .end annotation
.end field

.field public droppedItems:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/WorldLogic$ItemEntity;",
            ">;"
        }
    .end annotation
.end field

.field public entities:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/EZdev/mc2/Entity;",
            ">;"
        }
    .end annotation
.end field

.field private finalMVP:[F

.field public fogEnabled:Z

.field private gameplayRef:Lcom/EZdev/mc2/Gameplay;

.field private modelMatrix:[F

.field private final random:Ljava/security/SecureRandom;

.field public renderDistance:I

.field public saveManager:Lcom/EZdev/mc2/SaveManager;

.field public worldSeed:J


# direct methods
.method public static synthetic $r8$lambda$3nJOX2YuuNk4EZB8w0XRZSGstjo(Lcom/EZdev/mc2/Gameplay;)V
    .locals 0

    .line 0
    invoke-static {p0}, Lcom/EZdev/mc2/WorldLogic;->lambda$interact$0(Lcom/EZdev/mc2/Gameplay;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->random:Ljava/security/SecureRandom;

    .line 13
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    .line 14
    const/16 v0, 0x10

    new-array v1, v0, [F

    iput-object v1, p0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    .line 15
    new-array v0, v0, [F

    iput-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    .line 17
    const-wide/16 v0, 0x539

    iput-wide v0, p0, Lcom/EZdev/mc2/WorldLogic;->worldSeed:J

    .line 18
    const/4 v0, 0x2

    iput v0, p0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    .line 19
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    .line 61
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    .line 27
    iget-wide v0, p0, Lcom/EZdev/mc2/WorldLogic;->worldSeed:J

    invoke-static {v0, v1}, Lcom/EZdev/mc2/Noise;->init(J)V

    .line 28
    return-void
.end method

.method private checkIgnitionIfTntPlaced(IIILcom/EZdev/mc2/Gameplay;)V
    .locals 16
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I
    .param p4, "g"    # Lcom/EZdev/mc2/Gameplay;

    .line 582
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    const/4 v5, 0x6

    new-array v6, v5, [[I

    const/4 v7, 0x1

    const/4 v8, 0x0

    filled-new-array {v7, v8, v8}, [I

    move-result-object v9

    aput-object v9, v6, v8

    const/4 v9, -0x1

    filled-new-array {v9, v8, v8}, [I

    move-result-object v10

    aput-object v10, v6, v7

    filled-new-array {v8, v7, v8}, [I

    move-result-object v10

    const/4 v11, 0x2

    aput-object v10, v6, v11

    const/4 v10, 0x3

    filled-new-array {v8, v9, v8}, [I

    move-result-object v12

    aput-object v12, v6, v10

    const/4 v10, 0x4

    filled-new-array {v8, v8, v7}, [I

    move-result-object v12

    aput-object v12, v6, v10

    const/4 v10, 0x5

    filled-new-array {v8, v8, v9}, [I

    move-result-object v9

    aput-object v9, v6, v10

    .line 583
    .local v6, "neighbors":[[I
    array-length v9, v6

    move v10, v8

    :goto_0
    if-ge v10, v9, :cond_1

    aget-object v12, v6, v10

    .line 584
    .local v12, "n":[I
    aget v13, v12, v8

    add-int/2addr v13, v1

    .line 585
    .local v13, "nx":I
    aget v14, v12, v7

    add-int/2addr v14, v2

    .line 586
    .local v14, "ny":I
    aget v15, v12, v11

    add-int/2addr v15, v3

    .line 587
    .local v15, "nz":I
    invoke-virtual {v0, v13, v14, v15}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v7

    if-ne v7, v5, :cond_0

    .line 588
    invoke-virtual {v0, v1, v2, v3, v8}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 589
    int-to-float v5, v1

    const/high16 v7, 0x3f000000    # 0.5f

    add-float/2addr v5, v7

    int-to-float v8, v2

    int-to-float v9, v3

    add-float/2addr v9, v7

    invoke-virtual {v4, v5, v8, v9}, Lcom/EZdev/mc2/Gameplay;->obtainTNT(FFF)Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    move-result-object v5

    .line 590
    .local v5, "newTNT":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    iget-object v7, v4, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 591
    return-void

    .line 587
    .end local v5    # "newTNT":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    :cond_0
    nop

    .line 583
    .end local v12    # "n":[I
    .end local v13    # "nx":I
    .end local v14    # "ny":I
    .end local v15    # "nz":I
    add-int/lit8 v10, v10, 0x1

    const/4 v7, 0x1

    goto :goto_0

    .line 594
    :cond_1
    return-void
.end method

.method private getChunkKey(II)J
    .locals 6
    .param p1, "cx"    # I
    .param p2, "cz"    # I

    .line 64
    int-to-long v0, p1

    const/16 v2, 0x20

    shl-long/2addr v0, v2

    int-to-long v2, p2

    const-wide v4, 0xffffffffL

    and-long/2addr v2, v4

    or-long/2addr v0, v2

    return-wide v0
.end method

.method private isPlayerInside(Lcom/EZdev/mc2/Gameplay;III)Z
    .locals 10
    .param p1, "g"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "bx"    # I
    .param p3, "by"    # I
    .param p4, "bz"    # I

    .line 597
    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 598
    :cond_0
    const v1, 0x3d4ccccd    # 0.05f

    .line 599
    .local v1, "shrink":F
    iget v2, p1, Lcom/EZdev/mc2/Gameplay;->camX:F

    iget v3, p1, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    const/high16 v4, 0x40000000    # 2.0f

    div-float v5, v3, v4

    sub-float v5, v2, v5

    add-float/2addr v5, v1

    .line 600
    .local v5, "pMinX":F
    div-float v6, v3, v4

    add-float/2addr v2, v6

    sub-float/2addr v2, v1

    .line 601
    .local v2, "pMaxX":F
    iget v6, p1, Lcom/EZdev/mc2/Gameplay;->camY:F

    const v7, 0x3dcccccd    # 0.1f

    add-float/2addr v7, v6

    .line 602
    .local v7, "pMinY":F
    iget v8, p1, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v6, v8

    sub-float/2addr v6, v1

    .line 603
    .local v6, "pMaxY":F
    iget v8, p1, Lcom/EZdev/mc2/Gameplay;->camZ:F

    div-float v9, v3, v4

    sub-float v9, v8, v9

    add-float/2addr v9, v1

    .line 604
    .local v9, "pMinZ":F
    div-float/2addr v3, v4

    add-float/2addr v8, v3

    sub-float/2addr v8, v1

    .line 605
    .local v8, "pMaxZ":F
    add-int/lit8 v3, p2, 0x1

    int-to-float v3, v3

    cmpg-float v3, v5, v3

    if-gez v3, :cond_1

    int-to-float v3, p2

    cmpl-float v3, v2, v3

    if-lez v3, :cond_1

    add-int/lit8 v3, p3, 0x1

    int-to-float v3, v3

    cmpg-float v3, v7, v3

    if-gez v3, :cond_1

    int-to-float v3, p3

    cmpl-float v3, v6, v3

    if-lez v3, :cond_1

    add-int/lit8 v3, p4, 0x1

    int-to-float v3, v3

    cmpg-float v3, v9, v3

    if-gez v3, :cond_1

    int-to-float v3, p4

    cmpl-float v3, v8, v3

    if-lez v3, :cond_1

    const/4 v0, 0x1

    :cond_1
    return v0
.end method

.method private static synthetic lambda$interact$0(Lcom/EZdev/mc2/Gameplay;)V
    .locals 3
    .param p0, "g"    # Lcom/EZdev/mc2/Gameplay;

    .line 537
    iget-object v0, p0, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    const-string v1, "TNT FREIGESCHALTET!"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private renderParticle(Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;[FFB)V
    .locals 10
    .param p1, "p"    # Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    .param p2, "vpMatrix"    # [F
    .param p3, "size"    # F
    .param p4, "type"    # B

    .line 460
    if-nez p1, :cond_0

    return-void

    .line 461
    :cond_0
    iget-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 462
    iget-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    iget v2, p1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->x:F

    iget v3, p1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->y:F

    iget v4, p1, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->z:F

    invoke-static {v0, v1, v2, v3, v4}, Landroid/opengl/Matrix;->translateM([FIFFF)V

    .line 463
    iget-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    invoke-static {v0, v1, p3, p3, p3}, Landroid/opengl/Matrix;->scaleM([FIFFF)V

    .line 464
    iget-object v2, p0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v3, 0x0

    const/4 v5, 0x0

    iget-object v6, p0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v7, 0x0

    move-object v4, p2

    invoke-static/range {v2 .. v7}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 465
    sget v0, Lcom/EZdev/mc2/Booster;->mvpHandle:I

    const/4 v2, 0x1

    iget-object v3, p0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    invoke-static {v0, v2, v1, v3, v1}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 466
    sget v4, Lcom/EZdev/mc2/Booster;->posHandle:I

    const/4 v5, 0x3

    const/16 v6, 0x1406

    const/4 v8, 0x0

    sget-object v9, Lcom/EZdev/mc2/Booster;->tntVertexBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v4 .. v9}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 468
    sget v0, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    invoke-static {v0, p4}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 469
    const/16 v0, 0x63

    if-ne p4, v0, :cond_1

    sget v0, Lcom/EZdev/mc2/Booster;->isFlashingHandle:I

    const/4 v2, 0x2

    invoke-static {v0, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 471
    :cond_1
    sget v3, Lcom/EZdev/mc2/Booster;->colorHandle:I

    const/4 v4, 0x4

    const/16 v5, 0x1406

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget-object v8, Lcom/EZdev/mc2/Booster;->tntColorBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v3 .. v8}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 472
    const/4 v0, 0x4

    const/16 v2, 0x24

    invoke-static {v0, v1, v2}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    .line 473
    sget v0, Lcom/EZdev/mc2/Booster;->isFlashingHandle:I

    invoke-static {v0, v1}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 474
    return-void
.end method

.method private updateNeighbors(II)V
    .locals 7
    .param p1, "cx"    # I
    .param p2, "cz"    # I

    .line 100
    const/4 v0, 0x4

    new-array v0, v0, [J

    add-int/lit8 v1, p1, 0x1

    invoke-direct {p0, v1, p2}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v1

    const/4 v3, 0x0

    aput-wide v1, v0, v3

    add-int/lit8 v1, p1, -0x1

    invoke-direct {p0, v1, p2}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v1

    const/4 v4, 0x1

    aput-wide v1, v0, v4

    add-int/lit8 v1, p2, 0x1

    invoke-direct {p0, p1, v1}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v1

    const/4 v4, 0x2

    aput-wide v1, v0, v4

    add-int/lit8 v1, p2, -0x1

    invoke-direct {p0, p1, v1}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v1

    const/4 v4, 0x3

    aput-wide v1, v0, v4

    .line 101
    .local v0, "ns":[J
    array-length v1, v0

    :goto_0
    if-ge v3, v1, :cond_1

    aget-wide v4, v0, v3

    .line 102
    .local v4, "nKey":J
    iget-object v2, p0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/EZdev/mc2/Chunk;

    .line 103
    .local v2, "n":Lcom/EZdev/mc2/Chunk;
    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lcom/EZdev/mc2/Chunk;->buildMesh()V

    .line 101
    .end local v2    # "n":Lcom/EZdev/mc2/Chunk;
    .end local v4    # "nKey":J
    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 105
    :cond_1
    return-void
.end method


# virtual methods
.method public checkIgnition(IIILcom/EZdev/mc2/Gameplay;)V
    .locals 16
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I
    .param p4, "g"    # Lcom/EZdev/mc2/Gameplay;

    .line 142
    move-object/from16 v0, p0

    move-object/from16 v1, p4

    const/4 v2, 0x6

    new-array v2, v2, [[I

    const/4 v3, 0x1

    const/4 v4, 0x0

    filled-new-array {v3, v4, v4}, [I

    move-result-object v5

    aput-object v5, v2, v4

    const/4 v5, -0x1

    filled-new-array {v5, v4, v4}, [I

    move-result-object v6

    aput-object v6, v2, v3

    filled-new-array {v4, v3, v4}, [I

    move-result-object v6

    const/4 v7, 0x2

    aput-object v6, v2, v7

    const/4 v6, 0x3

    filled-new-array {v4, v5, v4}, [I

    move-result-object v8

    aput-object v8, v2, v6

    const/4 v6, 0x4

    filled-new-array {v4, v4, v3}, [I

    move-result-object v8

    aput-object v8, v2, v6

    filled-new-array {v4, v4, v5}, [I

    move-result-object v5

    const/4 v6, 0x5

    aput-object v5, v2, v6

    .line 143
    .local v2, "neighbors":[[I
    array-length v5, v2

    move v8, v4

    :goto_0
    if-ge v8, v5, :cond_1

    aget-object v9, v2, v8

    .line 144
    .local v9, "n":[I
    aget v10, v9, v4

    add-int v10, p1, v10

    .line 145
    .local v10, "nx":I
    aget v11, v9, v3

    add-int v11, p2, v11

    .line 146
    .local v11, "ny":I
    aget v12, v9, v7

    add-int v12, p3, v12

    .line 147
    .local v12, "nz":I
    invoke-virtual {v0, v10, v11, v12}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v13

    if-ne v13, v6, :cond_0

    .line 148
    invoke-virtual {v0, v10, v11, v12, v4}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 149
    int-to-float v13, v10

    const/high16 v14, 0x3f000000    # 0.5f

    add-float/2addr v13, v14

    int-to-float v15, v11

    int-to-float v3, v12

    add-float/2addr v3, v14

    invoke-virtual {v1, v13, v15, v3}, Lcom/EZdev/mc2/Gameplay;->obtainTNT(FFF)Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    move-result-object v3

    .line 150
    .local v3, "newTNT":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    iget-object v13, v1, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v13, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 143
    .end local v3    # "newTNT":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    .end local v9    # "n":[I
    .end local v10    # "nx":I
    .end local v11    # "ny":I
    .end local v12    # "nz":I
    :cond_0
    add-int/lit8 v8, v8, 0x1

    const/4 v3, 0x1

    goto :goto_0

    .line 153
    :cond_1
    return-void
.end method

.method public explode(FFFF)V
    .locals 27
    .param p1, "ex"    # F
    .param p2, "ey"    # F
    .param p3, "ez"    # F
    .param p4, "radius"    # F

    .line 156
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    sub-float v4, v1, p4

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    .local v4, "minX":I
    add-float v5, v1, p4

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-int v5, v5

    .line 157
    .local v5, "maxX":I
    sub-float v6, v2, p4

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v6, v6

    .local v6, "minY":I
    add-float v7, v2, p4

    float-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v7

    double-to-int v7, v7

    .line 158
    .local v7, "maxY":I
    sub-float v8, v3, p4

    float-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->floor(D)D

    move-result-wide v8

    double-to-int v8, v8

    .local v8, "minZ":I
    add-float v9, v3, p4

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v9

    double-to-int v9, v9

    .line 159
    .local v9, "maxZ":I
    new-instance v10, Ljava/util/HashSet;

    invoke-direct {v10}, Ljava/util/HashSet;-><init>()V

    .line 161
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    iget-object v11, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    if-eqz v11, :cond_4

    .line 162
    iget v14, v11, Lcom/EZdev/mc2/Gameplay;->camX:F

    sub-float v15, v14, v1

    sub-float/2addr v14, v1

    mul-float/2addr v15, v14

    iget v14, v11, Lcom/EZdev/mc2/Gameplay;->camY:F

    sub-float v16, v14, v2

    sub-float/2addr v14, v2

    mul-float v16, v16, v14

    add-float v15, v15, v16

    iget v11, v11, Lcom/EZdev/mc2/Gameplay;->camZ:F

    sub-float v14, v11, v3

    sub-float/2addr v11, v3

    mul-float/2addr v14, v11

    add-float/2addr v15, v14

    float-to-double v14, v15

    invoke-static {v14, v15}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v14

    double-to-float v11, v14

    .line 163
    .local v11, "distToPlayer":F
    const/high16 v14, 0x41c80000    # 25.0f

    cmpg-float v15, v11, v14

    if-gez v15, :cond_0

    .line 164
    iget-object v15, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    sub-float v16, v14, v11

    div-float v14, v16, v14

    iput v14, v15, Lcom/EZdev/mc2/Gameplay;->shakeIntensity:F

    .line 165
    const v14, 0x3f19999a    # 0.6f

    iput v14, v15, Lcom/EZdev/mc2/Gameplay;->shakeTimer:F

    .line 168
    :cond_0
    iget-object v14, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    invoke-virtual {v14, v1, v2, v3}, Lcom/EZdev/mc2/Gameplay;->addExplosionParticles(FFF)V

    .line 170
    const/high16 v14, 0x40000000    # 2.0f

    mul-float v14, v14, p4

    .line 171
    .local v14, "r2":F
    mul-float v15, v14, v14

    .line 173
    .local v15, "r2sq":F
    iget-object v12, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    iget-object v12, v12, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    const/16 v18, 0x0

    if-eqz v17, :cond_2

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v13, v17

    check-cast v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    .line 174
    .local v13, "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    move/from16 v17, v11

    .end local v11    # "distToPlayer":F
    .local v17, "distToPlayer":F
    iget v11, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    sub-float/2addr v11, v1

    .line 175
    .local v11, "dx":F
    move-object/from16 v20, v12

    iget v12, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    sub-float/2addr v12, v2

    .line 176
    .local v12, "dy":F
    move-object/from16 v21, v10

    .end local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .local v21, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    iget v10, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    sub-float/2addr v10, v3

    .line 177
    .local v10, "dz":F
    mul-float v22, v11, v11

    mul-float v23, v12, v12

    add-float v22, v22, v23

    mul-float v23, v10, v10

    move/from16 v24, v9

    .end local v9    # "maxZ":I
    .local v24, "maxZ":I
    add-float v9, v22, v23

    .line 178
    .local v9, "distSq":F
    cmpl-float v18, v9, v18

    if-lez v18, :cond_1

    cmpg-float v18, v9, v15

    if-gtz v18, :cond_1

    .line 179
    move/from16 v22, v7

    move/from16 v23, v8

    .end local v7    # "maxY":I
    .end local v8    # "minZ":I
    .local v22, "maxY":I
    .local v23, "minZ":I
    float-to-double v7, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v7

    double-to-float v7, v7

    .line 180
    .local v7, "dist":F
    sub-float v8, v14, v7

    div-float/2addr v8, v14

    .line 181
    .local v8, "force":F
    move/from16 v25, v9

    .end local v9    # "distSq":F
    .local v25, "distSq":F
    iget v9, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    div-float v18, v11, v7

    mul-float v18, v18, v8

    const/high16 v19, 0x41700000    # 15.0f

    mul-float v18, v18, v19

    add-float v9, v9, v18

    iput v9, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    .line 182
    iget v9, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    div-float v18, v12, v7

    mul-float v18, v18, v8

    mul-float v18, v18, v19

    const/high16 v16, 0x40a00000    # 5.0f

    mul-float v26, v8, v16

    add-float v18, v18, v26

    add-float v9, v9, v18

    iput v9, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    .line 183
    iget v9, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    div-float v18, v10, v7

    mul-float v18, v18, v8

    mul-float v18, v18, v19

    add-float v9, v9, v18

    iput v9, v13, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    goto :goto_1

    .line 178
    .end local v22    # "maxY":I
    .end local v23    # "minZ":I
    .end local v25    # "distSq":F
    .local v7, "maxY":I
    .local v8, "minZ":I
    .restart local v9    # "distSq":F
    :cond_1
    move/from16 v22, v7

    move/from16 v23, v8

    move/from16 v25, v9

    .line 185
    .end local v7    # "maxY":I
    .end local v8    # "minZ":I
    .end local v9    # "distSq":F
    .end local v10    # "dz":F
    .end local v11    # "dx":F
    .end local v12    # "dy":F
    .end local v13    # "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    .restart local v22    # "maxY":I
    .restart local v23    # "minZ":I
    :goto_1
    move/from16 v11, v17

    move-object/from16 v12, v20

    move-object/from16 v10, v21

    move/from16 v7, v22

    move/from16 v8, v23

    move/from16 v9, v24

    goto/16 :goto_0

    .line 187
    .end local v17    # "distToPlayer":F
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .end local v22    # "maxY":I
    .end local v23    # "minZ":I
    .end local v24    # "maxZ":I
    .restart local v7    # "maxY":I
    .restart local v8    # "minZ":I
    .local v9, "maxZ":I
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .local v11, "distToPlayer":F
    :cond_2
    move/from16 v22, v7

    move/from16 v23, v8

    move/from16 v24, v9

    move-object/from16 v21, v10

    move/from16 v17, v11

    .end local v7    # "maxY":I
    .end local v8    # "minZ":I
    .end local v9    # "maxZ":I
    .end local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .end local v11    # "distToPlayer":F
    .restart local v17    # "distToPlayer":F
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v22    # "maxY":I
    .restart local v23    # "minZ":I
    .restart local v24    # "maxZ":I
    iget-object v7, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    nop

    if-eqz v8, :cond_5

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/EZdev/mc2/Entity;

    .line 188
    .local v8, "e":Lcom/EZdev/mc2/Entity;
    iget v9, v8, Lcom/EZdev/mc2/Entity;->x:F

    sub-float/2addr v9, v1

    .line 189
    .local v9, "dx":F
    iget v10, v8, Lcom/EZdev/mc2/Entity;->y:F

    sub-float/2addr v10, v2

    .line 190
    .local v10, "dy":F
    iget v11, v8, Lcom/EZdev/mc2/Entity;->z:F

    sub-float/2addr v11, v3

    .line 191
    .local v11, "dz":F
    mul-float v12, v9, v9

    mul-float v13, v10, v10

    add-float/2addr v12, v13

    mul-float v13, v11, v11

    add-float/2addr v12, v13

    .line 192
    .local v12, "distSq":F
    cmpl-float v13, v12, v18

    if-lez v13, :cond_3

    cmpg-float v13, v12, v15

    if-gtz v13, :cond_3

    .line 193
    float-to-double v2, v12

    invoke-static {v2, v3}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v2

    double-to-float v2, v2

    .line 194
    .local v2, "dist":F
    sub-float v3, v14, v2

    div-float/2addr v3, v14

    .line 195
    .local v3, "force":F
    iget v13, v8, Lcom/EZdev/mc2/Entity;->x:F

    div-float v20, v9, v2

    mul-float v20, v20, v3

    const/high16 v25, 0x41a00000    # 20.0f

    mul-float v20, v20, v25

    add-float v13, v13, v20

    iput v13, v8, Lcom/EZdev/mc2/Entity;->targetX:F

    .line 196
    iget v13, v8, Lcom/EZdev/mc2/Entity;->z:F

    div-float v20, v11, v2

    mul-float v20, v20, v3

    mul-float v20, v20, v25

    add-float v13, v13, v20

    iput v13, v8, Lcom/EZdev/mc2/Entity;->targetZ:F

    .line 197
    iget v13, v8, Lcom/EZdev/mc2/Entity;->vy:F

    const/high16 v19, 0x41700000    # 15.0f

    mul-float v20, v3, v19

    add-float v13, v13, v20

    iput v13, v8, Lcom/EZdev/mc2/Entity;->vy:F

    .line 199
    .end local v2    # "dist":F
    .end local v3    # "force":F
    .end local v8    # "e":Lcom/EZdev/mc2/Entity;
    .end local v9    # "dx":F
    .end local v10    # "dy":F
    .end local v11    # "dz":F
    .end local v12    # "distSq":F
    :cond_3
    move/from16 v2, p2

    move/from16 v3, p3

    goto :goto_2

    .line 161
    .end local v14    # "r2":F
    .end local v15    # "r2sq":F
    .end local v17    # "distToPlayer":F
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .end local v22    # "maxY":I
    .end local v23    # "minZ":I
    .end local v24    # "maxZ":I
    .restart local v7    # "maxY":I
    .local v8, "minZ":I
    .local v9, "maxZ":I
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    :cond_4
    move/from16 v22, v7

    move/from16 v23, v8

    move/from16 v24, v9

    move-object/from16 v21, v10

    .line 202
    .end local v7    # "maxY":I
    .end local v8    # "minZ":I
    .end local v9    # "maxZ":I
    .end local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v22    # "maxY":I
    .restart local v23    # "minZ":I
    .restart local v24    # "maxZ":I
    :cond_5
    mul-float v2, p4, p4

    .line 203
    .local v2, "radiusSq":F
    move v3, v4

    .local v3, "x":I
    :goto_3
    if-gt v3, v5, :cond_f

    .line 204
    move v7, v6

    .local v7, "y":I
    :goto_4
    move/from16 v8, v22

    .end local v22    # "maxY":I
    .local v8, "maxY":I
    if-gt v7, v8, :cond_e

    .line 205
    move/from16 v9, v23

    .local v9, "z":I
    :goto_5
    move/from16 v10, v24

    .end local v24    # "maxZ":I
    .local v10, "maxZ":I
    if-gt v9, v10, :cond_d

    .line 206
    int-to-float v11, v3

    const/high16 v12, 0x3f000000    # 0.5f

    add-float/2addr v11, v12

    sub-float/2addr v11, v1

    .line 207
    .local v11, "dx":F
    int-to-float v13, v7

    add-float/2addr v13, v12

    sub-float v13, v13, p2

    .line 208
    .local v13, "dy":F
    int-to-float v14, v9

    add-float/2addr v14, v12

    sub-float v14, v14, p3

    .line 209
    .local v14, "dz":F
    mul-float v15, v11, v11

    mul-float v17, v13, v13

    add-float v15, v15, v17

    mul-float v17, v14, v14

    add-float v15, v15, v17

    .line 210
    .local v15, "distSq":F
    cmpg-float v17, v15, v2

    if-gtz v17, :cond_c

    const/4 v12, 0x1

    if-lt v7, v12, :cond_c

    const/16 v12, 0x80

    if-ge v7, v12, :cond_c

    .line 211
    invoke-virtual {v0, v3, v7, v9}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v12

    .line 212
    .local v12, "block":B
    const/16 v1, 0x9

    if-ne v12, v1, :cond_6

    move/from16 v18, v2

    move/from16 v20, v4

    move/from16 v22, v5

    move/from16 v24, v10

    move-object/from16 v10, v21

    const/high16 v16, 0x40a00000    # 5.0f

    const/high16 v19, 0x41700000    # 15.0f

    goto/16 :goto_6

    .line 214
    :cond_6
    const/4 v1, 0x5

    move/from16 v18, v2

    .end local v2    # "radiusSq":F
    .local v18, "radiusSq":F
    const/4 v2, 0x0

    if-ne v12, v1, :cond_7

    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    if-eqz v1, :cond_7

    .line 215
    invoke-virtual {v0, v3, v7, v9, v2}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 216
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    int-to-float v2, v3

    const/high16 v17, 0x3f000000    # 0.5f

    add-float v2, v2, v17

    move/from16 v20, v4

    .end local v4    # "minX":I
    .local v20, "minX":I
    int-to-float v4, v7

    add-float v4, v4, v17

    move/from16 v22, v5

    .end local v5    # "maxX":I
    .local v22, "maxX":I
    int-to-float v5, v9

    add-float v5, v5, v17

    invoke-virtual {v1, v2, v4, v5}, Lcom/EZdev/mc2/Gameplay;->obtainTNT(FFF)Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    move-result-object v1

    .line 217
    .local v1, "newTNT":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    float-to-double v4, v15

    invoke-static {v4, v5}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v4

    double-to-float v2, v4

    .line 218
    .local v2, "dist":F
    sub-float v4, p4, v2

    div-float v4, v4, p4

    .line 219
    .local v4, "force":F
    div-float v5, v11, v2

    mul-float/2addr v5, v4

    const/high16 v19, 0x41700000    # 15.0f

    mul-float v5, v5, v19

    iput v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vx:F

    .line 220
    div-float v5, v13, v2

    mul-float/2addr v5, v4

    mul-float v5, v5, v19

    const/high16 v16, 0x40a00000    # 5.0f

    add-float v5, v5, v16

    iput v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vy:F

    .line 221
    div-float v5, v14, v2

    mul-float/2addr v5, v4

    mul-float v5, v5, v19

    iput v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->vz:F

    .line 222
    iget-object v5, v0, Lcom/EZdev/mc2/WorldLogic;->random:Ljava/security/SecureRandom;

    invoke-virtual {v5}, Ljava/util/Random;->nextFloat()F

    move-result v5

    const/high16 v24, 0x3fc00000    # 1.5f

    mul-float v5, v5, v24

    const/high16 v17, 0x3f000000    # 0.5f

    add-float v5, v5, v17

    iput v5, v1, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->timer:F

    .line 223
    iget-object v5, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    iget-object v5, v5, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 224
    .end local v1    # "newTNT":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    .end local v2    # "dist":F
    .end local v4    # "force":F
    move/from16 v24, v10

    move-object/from16 v10, v21

    goto/16 :goto_6

    .line 214
    .end local v20    # "minX":I
    .end local v22    # "maxX":I
    .local v4, "minX":I
    .restart local v5    # "maxX":I
    :cond_7
    move/from16 v20, v4

    move/from16 v22, v5

    const/high16 v16, 0x40a00000    # 5.0f

    const/high16 v19, 0x41700000    # 15.0f

    .line 224
    .end local v4    # "minX":I
    .end local v5    # "maxX":I
    .restart local v20    # "minX":I
    .restart local v22    # "maxX":I
    if-eqz v12, :cond_b

    const/4 v1, 0x7

    if-eq v12, v1, :cond_b

    .line 225
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    if-eqz v1, :cond_8

    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->random:Ljava/security/SecureRandom;

    invoke-virtual {v1}, Ljava/util/Random;->nextFloat()F

    move-result v1

    const v4, 0x3e4ccccd    # 0.2f

    cmpg-float v1, v1, v4

    if-gez v1, :cond_8

    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    int-to-float v4, v3

    int-to-float v5, v7

    int-to-float v2, v9

    invoke-virtual {v1, v4, v5, v2, v12}, Lcom/EZdev/mc2/Gameplay;->addBlockParticles(FFFB)V

    .line 228
    :cond_8
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    if-eqz v1, :cond_9

    iget-boolean v1, v1, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v1, :cond_9

    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->random:Ljava/security/SecureRandom;

    invoke-virtual {v1}, Ljava/util/Random;->nextFloat()F

    move-result v1

    const v2, 0x3e99999a    # 0.3f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_9

    .line 229
    invoke-virtual {v0, v3, v7, v9, v12}, Lcom/EZdev/mc2/WorldLogic;->spawnItemEntity(IIIB)V

    .line 232
    :cond_9
    int-to-double v1, v3

    const-wide/high16 v4, 0x4030000000000000L    # 16.0

    div-double/2addr v1, v4

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    .line 233
    .local v1, "cx":I
    move/from16 v24, v10

    move v2, v11

    .end local v10    # "maxZ":I
    .end local v11    # "dx":F
    .local v2, "dx":F
    .restart local v24    # "maxZ":I
    int-to-double v10, v9

    div-double/2addr v10, v4

    invoke-static {v10, v11}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int v4, v4

    .line 234
    .local v4, "cz":I
    iget-object v5, v0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-direct {v0, v1, v4}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    invoke-virtual {v5, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/EZdev/mc2/Chunk;

    .line 235
    .local v5, "c":Lcom/EZdev/mc2/Chunk;
    if-eqz v5, :cond_a

    .line 236
    iget-object v10, v5, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    mul-int/lit8 v11, v1, 0x10

    sub-int v11, v3, v11

    aget-object v10, v10, v11

    aget-object v10, v10, v7

    mul-int/lit8 v11, v4, 0x10

    sub-int v11, v9, v11

    const/16 v17, 0x0

    aput-byte v17, v10, v11

    .line 237
    move-object/from16 v10, v21

    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    invoke-virtual {v10, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_6

    .line 235
    .end local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    :cond_a
    move-object/from16 v10, v21

    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    goto :goto_6

    .line 224
    .end local v1    # "cx":I
    .end local v2    # "dx":F
    .end local v4    # "cz":I
    .end local v5    # "c":Lcom/EZdev/mc2/Chunk;
    .end local v24    # "maxZ":I
    .local v10, "maxZ":I
    .restart local v11    # "dx":F
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    :cond_b
    move/from16 v24, v10

    move v2, v11

    move-object/from16 v10, v21

    .end local v11    # "dx":F
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v2    # "dx":F
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v24    # "maxZ":I
    goto :goto_6

    .line 210
    .end local v12    # "block":B
    .end local v18    # "radiusSq":F
    .end local v20    # "minX":I
    .end local v22    # "maxX":I
    .end local v24    # "maxZ":I
    .local v2, "radiusSq":F
    .local v4, "minX":I
    .local v5, "maxX":I
    .local v10, "maxZ":I
    .restart local v11    # "dx":F
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    :cond_c
    move/from16 v18, v2

    move/from16 v20, v4

    move/from16 v22, v5

    move/from16 v24, v10

    move v2, v11

    move-object/from16 v10, v21

    const/high16 v16, 0x40a00000    # 5.0f

    const/high16 v19, 0x41700000    # 15.0f

    .line 205
    .end local v2    # "radiusSq":F
    .end local v4    # "minX":I
    .end local v5    # "maxX":I
    .end local v11    # "dx":F
    .end local v13    # "dy":F
    .end local v14    # "dz":F
    .end local v15    # "distSq":F
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v18    # "radiusSq":F
    .restart local v20    # "minX":I
    .restart local v22    # "maxX":I
    .restart local v24    # "maxZ":I
    :goto_6
    add-int/lit8 v9, v9, 0x1

    move/from16 v1, p1

    move-object/from16 v21, v10

    move/from16 v2, v18

    move/from16 v4, v20

    move/from16 v5, v22

    goto/16 :goto_5

    .end local v18    # "radiusSq":F
    .end local v20    # "minX":I
    .end local v22    # "maxX":I
    .end local v24    # "maxZ":I
    .restart local v2    # "radiusSq":F
    .restart local v4    # "minX":I
    .restart local v5    # "maxX":I
    .local v10, "maxZ":I
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    :cond_d
    move/from16 v18, v2

    move/from16 v20, v4

    move/from16 v22, v5

    move/from16 v24, v10

    move-object/from16 v10, v21

    const/high16 v16, 0x40a00000    # 5.0f

    const/high16 v19, 0x41700000    # 15.0f

    .line 204
    .end local v2    # "radiusSq":F
    .end local v4    # "minX":I
    .end local v5    # "maxX":I
    .end local v9    # "z":I
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .local v10, "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v18    # "radiusSq":F
    .restart local v20    # "minX":I
    .restart local v22    # "maxX":I
    .restart local v24    # "maxZ":I
    add-int/lit8 v7, v7, 0x1

    move/from16 v1, p1

    move/from16 v22, v8

    goto/16 :goto_4

    .end local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .end local v18    # "radiusSq":F
    .end local v20    # "minX":I
    .end local v22    # "maxX":I
    .restart local v2    # "radiusSq":F
    .restart local v4    # "minX":I
    .restart local v5    # "maxX":I
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    :cond_e
    move/from16 v18, v2

    move/from16 v20, v4

    move/from16 v22, v5

    move-object/from16 v10, v21

    const/high16 v16, 0x40a00000    # 5.0f

    const/high16 v19, 0x41700000    # 15.0f

    .line 203
    .end local v2    # "radiusSq":F
    .end local v4    # "minX":I
    .end local v5    # "maxX":I
    .end local v7    # "y":I
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v18    # "radiusSq":F
    .restart local v20    # "minX":I
    .restart local v22    # "maxX":I
    add-int/lit8 v3, v3, 0x1

    move/from16 v1, p1

    move/from16 v22, v8

    goto/16 :goto_3

    .end local v8    # "maxY":I
    .end local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .end local v18    # "radiusSq":F
    .end local v20    # "minX":I
    .restart local v2    # "radiusSq":F
    .restart local v4    # "minX":I
    .restart local v5    # "maxX":I
    .restart local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .local v22, "maxY":I
    :cond_f
    move/from16 v18, v2

    move/from16 v20, v4

    move-object/from16 v10, v21

    move/from16 v8, v22

    move/from16 v22, v5

    .line 244
    .end local v2    # "radiusSq":F
    .end local v3    # "x":I
    .end local v4    # "minX":I
    .end local v5    # "maxX":I
    .end local v21    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v8    # "maxY":I
    .restart local v10    # "chunksToUpdate":Ljava/util/HashSet;, "Ljava/util/HashSet<Lcom/EZdev/mc2/Chunk;>;"
    .restart local v18    # "radiusSq":F
    .restart local v20    # "minX":I
    .local v22, "maxX":I
    invoke-virtual {v10}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_7
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/EZdev/mc2/Chunk;

    .line 245
    .local v2, "c":Lcom/EZdev/mc2/Chunk;
    invoke-virtual {v2}, Lcom/EZdev/mc2/Chunk;->buildMesh()V

    .line 246
    iget-object v3, v0, Lcom/EZdev/mc2/WorldLogic;->saveManager:Lcom/EZdev/mc2/SaveManager;

    if-eqz v3, :cond_10

    invoke-virtual {v3, v2}, Lcom/EZdev/mc2/SaveManager;->saveChunk(Lcom/EZdev/mc2/Chunk;)V

    .line 247
    .end local v2    # "c":Lcom/EZdev/mc2/Chunk;
    :cond_10
    goto :goto_7

    .line 248
    :cond_11
    return-void
.end method

.method public getBlock(III)B
    .locals 7
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I

    .line 108
    const/4 v0, 0x0

    if-ltz p2, :cond_0

    const/16 v1, 0x80

    if-lt p2, v1, :cond_1

    :cond_0
    goto :goto_0

    .line 109
    :cond_1
    int-to-double v1, p1

    const-wide/high16 v3, 0x4030000000000000L    # 16.0

    div-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    .line 110
    .local v1, "cx":I
    int-to-double v5, p3

    div-double/2addr v5, v3

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v2

    double-to-int v2, v2

    .line 111
    .local v2, "cz":I
    invoke-direct {p0, v1, v2}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v3

    .line 112
    .local v3, "key":J
    iget-object v5, p0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/EZdev/mc2/Chunk;

    .line 113
    .local v5, "c":Lcom/EZdev/mc2/Chunk;
    if-eqz v5, :cond_2

    iget-object v0, v5, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    mul-int/lit8 v6, v1, 0x10

    sub-int v6, p1, v6

    aget-object v0, v0, v6

    aget-object v0, v0, p2

    mul-int/lit8 v6, v2, 0x10

    sub-int v6, p3, v6

    aget-byte v0, v0, v6

    return v0

    .line 114
    :cond_2
    return v0

    .line 108
    .end local v1    # "cx":I
    .end local v2    # "cz":I
    .end local v3    # "key":J
    .end local v5    # "c":Lcom/EZdev/mc2/Chunk;
    :goto_0
    return v0
.end method

.method public interact(Lcom/EZdev/mc2/Gameplay;ZLcom/EZdev/mc2/UIManager;)V
    .locals 21
    .param p1, "g"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "place"    # Z
    .param p3, "ui"    # Lcom/EZdev/mc2/UIManager;

    .line 503
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    if-nez v1, :cond_0

    return-void

    .line 504
    :cond_0
    iget-object v3, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    if-nez v3, :cond_1

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    .line 505
    :cond_1
    nop

    .line 506
    iget v3, v1, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v4, v1, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v3, v4

    const v4, 0x3e4ccccd    # 0.2f

    sub-float/2addr v3, v4

    .line 507
    .local v3, "eyeHeight":F
    iget v4, v1, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Math;->cos(D)D

    move-result-wide v4

    iget v6, v1, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    mul-double/2addr v4, v6

    double-to-float v4, v4

    .line 508
    .local v4, "dirX":F
    iget v5, v1, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    double-to-float v5, v5

    .line 509
    .local v5, "dirY":F
    iget v6, v1, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    move-result-wide v6

    neg-double v6, v6

    iget v8, v1, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v8

    mul-double/2addr v6, v8

    double-to-float v6, v6

    .line 510
    .local v6, "dirZ":F
    const/4 v7, -0x1

    .local v7, "lastX":I
    const/4 v8, -0x1

    .local v8, "lastY":I
    const/4 v9, -0x1

    .line 512
    .local v9, "lastZ":I
    const/4 v10, 0x0

    .local v10, "dist":F
    :goto_0
    const/high16 v11, 0x40c00000    # 6.0f

    cmpg-float v11, v10, v11

    if-gez v11, :cond_11

    .line 513
    iget v11, v1, Lcom/EZdev/mc2/Gameplay;->camX:F

    mul-float v13, v4, v10

    add-float/2addr v11, v13

    float-to-double v13, v11

    invoke-static {v13, v14}, Ljava/lang/Math;->floor(D)D

    move-result-wide v13

    double-to-int v11, v13

    .line 514
    .local v11, "bx":I
    mul-float v13, v5, v10

    add-float/2addr v13, v3

    float-to-double v13, v13

    invoke-static {v13, v14}, Ljava/lang/Math;->floor(D)D

    move-result-wide v13

    double-to-int v13, v13

    .line 515
    .local v13, "by":I
    iget v14, v1, Lcom/EZdev/mc2/Gameplay;->camZ:F

    mul-float v15, v6, v10

    add-float/2addr v14, v15

    float-to-double v14, v14

    invoke-static {v14, v15}, Ljava/lang/Math;->floor(D)D

    move-result-wide v14

    double-to-int v14, v14

    .line 517
    .local v14, "bz":I
    iget-object v15, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v15

    const/4 v12, 0x1

    sub-int/2addr v15, v12

    .local v15, "i":I
    :goto_1
    if-ltz v15, :cond_6

    .line 518
    iget-object v12, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/EZdev/mc2/Entity;

    .line 519
    .local v12, "e":Lcom/EZdev/mc2/Entity;
    if-nez v12, :cond_3

    move/from16 v17, v3

    .end local v3    # "eyeHeight":F
    .local v17, "eyeHeight":F
    iget-object v3, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v16, 0x1

    add-int/lit8 v3, v3, -0x1

    .local v3, "lastIdx":I
    if-ge v15, v3, :cond_2

    move/from16 v18, v4

    .end local v4    # "dirX":F
    .local v18, "dirX":F
    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v19

    move/from16 v20, v5

    .end local v5    # "dirY":F
    .local v20, "dirY":F
    move-object/from16 v5, v19

    check-cast v5, Lcom/EZdev/mc2/Entity;

    invoke-virtual {v4, v15, v5}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    .end local v18    # "dirX":F
    .end local v20    # "dirY":F
    .restart local v4    # "dirX":F
    .restart local v5    # "dirY":F
    :cond_2
    move/from16 v18, v4

    move/from16 v20, v5

    .end local v4    # "dirX":F
    .end local v5    # "dirY":F
    .restart local v18    # "dirX":F
    .restart local v20    # "dirY":F
    :goto_2
    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_3

    .line 520
    .end local v17    # "eyeHeight":F
    .end local v18    # "dirX":F
    .end local v20    # "dirY":F
    .local v3, "eyeHeight":F
    .restart local v4    # "dirX":F
    .restart local v5    # "dirY":F
    :cond_3
    move/from16 v17, v3

    move/from16 v18, v4

    move/from16 v20, v5

    .end local v3    # "eyeHeight":F
    .end local v4    # "dirX":F
    .end local v5    # "dirY":F
    .restart local v17    # "eyeHeight":F
    .restart local v18    # "dirX":F
    .restart local v20    # "dirY":F
    iget v3, v12, Lcom/EZdev/mc2/Entity;->x:F

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    if-ne v11, v3, :cond_5

    iget v3, v12, Lcom/EZdev/mc2/Entity;->y:F

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    if-ne v13, v3, :cond_5

    iget v3, v12, Lcom/EZdev/mc2/Entity;->z:F

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    if-ne v14, v3, :cond_5

    .line 521
    if-nez p2, :cond_5

    .line 522
    iget-object v3, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    .local v3, "lastIdx":I
    if-ge v15, v3, :cond_4

    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/EZdev/mc2/Entity;

    invoke-virtual {v4, v15, v5}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_4
    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 523
    return-void

    .line 517
    .end local v3    # "lastIdx":I
    .end local v12    # "e":Lcom/EZdev/mc2/Entity;
    :cond_5
    :goto_3
    add-int/lit8 v15, v15, -0x1

    move/from16 v3, v17

    move/from16 v4, v18

    move/from16 v5, v20

    const/4 v12, 0x1

    goto/16 :goto_1

    .end local v17    # "eyeHeight":F
    .end local v18    # "dirX":F
    .end local v20    # "dirY":F
    .local v3, "eyeHeight":F
    .restart local v4    # "dirX":F
    .restart local v5    # "dirY":F
    :cond_6
    move/from16 v17, v3

    move/from16 v18, v4

    move/from16 v20, v5

    .line 528
    .end local v3    # "eyeHeight":F
    .end local v4    # "dirX":F
    .end local v5    # "dirY":F
    .end local v15    # "i":I
    .restart local v17    # "eyeHeight":F
    .restart local v18    # "dirX":F
    .restart local v20    # "dirY":F
    invoke-virtual {v0, v11, v13, v14}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v3

    .line 529
    .local v3, "hitBlock":B
    if-lez v3, :cond_10

    const/4 v4, 0x6

    if-eq v3, v4, :cond_10

    const/4 v5, 0x7

    if-eq v3, v5, :cond_10

    .line 530
    const/16 v5, 0x9

    if-ne v3, v5, :cond_7

    return-void

    .line 532
    :cond_7
    const/4 v5, 0x5

    if-nez p2, :cond_9

    if-ne v3, v5, :cond_9

    iget-byte v12, v1, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    if-ne v12, v4, :cond_9

    .line 533
    if-eqz v2, :cond_8

    iget-boolean v4, v2, Lcom/EZdev/mc2/UIManager;->tntUnlocked:Z

    if-nez v4, :cond_8

    .line 534
    const/4 v4, 0x1

    iput-boolean v4, v2, Lcom/EZdev/mc2/UIManager;->tntUnlocked:Z

    .line 535
    iget-object v5, v1, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v5, :cond_8

    .line 536
    const-string v12, "McPrefs"

    const/4 v15, 0x0

    invoke-virtual {v5, v12, v15}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v12, "TNT_UNLOCKED"

    invoke-interface {v5, v12, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 537
    iget-object v4, v1, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    new-instance v5, Lcom/EZdev/mc2/WorldLogic$$ExternalSyntheticLambda0;

    invoke-direct {v5, v1}, Lcom/EZdev/mc2/WorldLogic$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/Gameplay;)V

    invoke-virtual {v4, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 540
    :cond_8
    const/4 v4, 0x0

    invoke-virtual {v0, v11, v13, v14, v4}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 541
    iget-object v4, v1, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    int-to-float v5, v11

    const/high16 v12, 0x3f000000    # 0.5f

    add-float/2addr v5, v12

    int-to-float v15, v13

    move/from16 v19, v6

    .end local v6    # "dirZ":F
    .local v19, "dirZ":F
    int-to-float v6, v14

    add-float/2addr v6, v12

    invoke-virtual {v1, v5, v15, v6}, Lcom/EZdev/mc2/Gameplay;->obtainTNT(FFF)Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 542
    return-void

    .line 532
    .end local v19    # "dirZ":F
    .restart local v6    # "dirZ":F
    :cond_9
    move/from16 v19, v6

    .line 544
    .end local v6    # "dirZ":F
    .restart local v19    # "dirZ":F
    if-eqz p2, :cond_d

    const/4 v6, -0x1

    if-eq v7, v6, :cond_d

    invoke-direct {v0, v1, v7, v8, v9}, Lcom/EZdev/mc2/WorldLogic;->isPlayerInside(Lcom/EZdev/mc2/Gameplay;III)Z

    move-result v6

    if-nez v6, :cond_d

    .line 545
    iget-boolean v6, v1, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v6, :cond_b

    if-eqz v2, :cond_b

    .line 546
    iget v6, v1, Lcom/EZdev/mc2/Gameplay;->activeSlot:I

    .line 547
    .local v6, "slot":I
    iget-object v12, v2, Lcom/EZdev/mc2/UIManager;->inventory:[I

    aget v15, v12, v6

    if-gtz v15, :cond_a

    return-void

    .line 548
    :cond_a
    const/16 v5, 0x3e7

    if-eq v15, v5, :cond_b

    .line 549
    const/4 v5, 0x1

    sub-int/2addr v15, v5

    aput v15, v12, v6

    .line 550
    invoke-virtual/range {p3 .. p3}, Lcom/EZdev/mc2/UIManager;->updateHotbarUI()V

    .line 554
    .end local v6    # "slot":I
    :cond_b
    iget-byte v5, v1, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    invoke-virtual {v0, v7, v8, v9, v5}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    .line 555
    iget-byte v5, v1, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    if-ne v5, v4, :cond_c

    .line 556
    invoke-virtual {v0, v7, v8, v9, v1}, Lcom/EZdev/mc2/WorldLogic;->checkIgnition(IIILcom/EZdev/mc2/Gameplay;)V

    .line 557
    iget-object v4, v1, Lcom/EZdev/mc2/Gameplay;->activeFires:Ljava/util/ArrayList;

    invoke-virtual {v1, v7, v8, v9}, Lcom/EZdev/mc2/Gameplay;->obtainFire(III)Lcom/EZdev/mc2/Gameplay$ActiveFire;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 559
    :cond_c
    iget-byte v4, v1, Lcom/EZdev/mc2/Gameplay;->activeBlock:B

    const/4 v5, 0x5

    if-ne v4, v5, :cond_f

    .line 560
    invoke-direct {v0, v7, v8, v9, v1}, Lcom/EZdev/mc2/WorldLogic;->checkIgnitionIfTntPlaced(IIILcom/EZdev/mc2/Gameplay;)V

    goto :goto_4

    .line 562
    :cond_d
    if-nez p2, :cond_f

    .line 563
    iget-boolean v4, v1, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-eqz v4, :cond_e

    .line 564
    int-to-float v4, v11

    int-to-float v5, v13

    int-to-float v6, v14

    invoke-virtual {v1, v4, v5, v6, v3}, Lcom/EZdev/mc2/Gameplay;->addBlockParticles(FFFB)V

    .line 565
    const/4 v4, 0x0

    invoke-virtual {v0, v11, v13, v14, v4}, Lcom/EZdev/mc2/WorldLogic;->setBlock(IIIB)V

    goto :goto_4

    .line 568
    :cond_e
    const/4 v4, 0x1

    iput-boolean v4, v1, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    .line 569
    iput v11, v1, Lcom/EZdev/mc2/Gameplay;->targetX:I

    iput v13, v1, Lcom/EZdev/mc2/Gameplay;->targetY:I

    iput v14, v1, Lcom/EZdev/mc2/Gameplay;->targetZ:I

    .line 572
    :cond_f
    :goto_4
    return-void

    .line 529
    .end local v19    # "dirZ":F
    .local v6, "dirZ":F
    :cond_10
    move/from16 v19, v6

    .line 574
    .end local v6    # "dirZ":F
    .restart local v19    # "dirZ":F
    move v7, v11

    move v8, v13

    move v9, v14

    .line 512
    .end local v3    # "hitBlock":B
    .end local v11    # "bx":I
    .end local v13    # "by":I
    .end local v14    # "bz":I
    const v3, 0x3dcccccd    # 0.1f

    add-float/2addr v10, v3

    move/from16 v3, v17

    move/from16 v4, v18

    move/from16 v6, v19

    move/from16 v5, v20

    goto/16 :goto_0

    .end local v17    # "eyeHeight":F
    .end local v18    # "dirX":F
    .end local v19    # "dirZ":F
    .end local v20    # "dirY":F
    .local v3, "eyeHeight":F
    .restart local v4    # "dirX":F
    .restart local v5    # "dirY":F
    .restart local v6    # "dirZ":F
    :cond_11
    move/from16 v17, v3

    move/from16 v18, v4

    move/from16 v20, v5

    move/from16 v19, v6

    .line 576
    .end local v3    # "eyeHeight":F
    .end local v4    # "dirX":F
    .end local v5    # "dirY":F
    .end local v6    # "dirZ":F
    .end local v10    # "dist":F
    .restart local v17    # "eyeHeight":F
    .restart local v18    # "dirX":F
    .restart local v19    # "dirZ":F
    .restart local v20    # "dirY":F
    if-nez p2, :cond_12

    .line 577
    const/4 v3, 0x0

    iput-boolean v3, v1, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    .line 579
    :cond_12
    return-void
.end method

.method public raycastBlock(Lcom/EZdev/mc2/Gameplay;)[I
    .locals 1
    .param p1, "g"    # Lcom/EZdev/mc2/Gameplay;

    .line 477
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/EZdev/mc2/WorldLogic;->raycastBlock(Lcom/EZdev/mc2/Gameplay;[I)[I

    move-result-object v0

    return-object v0
.end method

.method public raycastBlock(Lcom/EZdev/mc2/Gameplay;[I)[I
    .locals 11
    .param p1, "g"    # Lcom/EZdev/mc2/Gameplay;
    .param p2, "out"    # [I

    .line 481
    iget v0, p1, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v1, p1, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v0, v1

    const v1, 0x3e4ccccd    # 0.2f

    sub-float/2addr v0, v1

    .line 482
    .local v0, "eyeHeight":F
    iget v1, p1, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Math;->cos(D)D

    move-result-wide v1

    iget v3, p1, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Math;->sin(D)D

    move-result-wide v3

    mul-double/2addr v1, v3

    double-to-float v1, v1

    .line 483
    .local v1, "dirX":F
    iget v2, p1, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v2, v2

    invoke-static {v2, v3}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    double-to-float v2, v2

    .line 484
    .local v2, "dirY":F
    iget v3, p1, Lcom/EZdev/mc2/Gameplay;->pitch:F

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Math;->cos(D)D

    move-result-wide v3

    neg-double v3, v3

    iget v5, p1, Lcom/EZdev/mc2/Gameplay;->yaw:F

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v5

    mul-double/2addr v3, v5

    double-to-float v3, v3

    .line 486
    .local v3, "dirZ":F
    const/4 v4, 0x0

    .local v4, "dist":F
    :goto_0
    const/high16 v5, 0x40c00000    # 6.0f

    cmpg-float v5, v4, v5

    if-gez v5, :cond_2

    .line 487
    iget v5, p1, Lcom/EZdev/mc2/Gameplay;->camX:F

    mul-float v6, v1, v4

    add-float/2addr v5, v6

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    .line 488
    .local v5, "bx":I
    mul-float v6, v2, v4

    add-float/2addr v6, v0

    float-to-double v6, v6

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v6

    double-to-int v6, v6

    .line 489
    .local v6, "by":I
    iget v7, p1, Lcom/EZdev/mc2/Gameplay;->camZ:F

    mul-float v8, v3, v4

    add-float/2addr v7, v8

    float-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->floor(D)D

    move-result-wide v7

    double-to-int v7, v7

    .line 490
    .local v7, "bz":I
    invoke-virtual {p0, v5, v6, v7}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v8

    .line 491
    .local v8, "hitBlock":B
    if-lez v8, :cond_1

    const/4 v9, 0x6

    if-eq v8, v9, :cond_1

    const/4 v9, 0x7

    if-eq v8, v9, :cond_1

    .line 492
    if-eqz p2, :cond_0

    array-length v9, p2

    const/4 v10, 0x3

    if-lt v9, v10, :cond_0

    .line 493
    const/4 v9, 0x0

    aput v5, p2, v9

    const/4 v9, 0x1

    aput v6, p2, v9

    const/4 v9, 0x2

    aput v7, p2, v9

    .line 494
    return-object p2

    .line 496
    :cond_0
    filled-new-array {v5, v6, v7}, [I

    move-result-object v9

    return-object v9

    .line 486
    .end local v5    # "bx":I
    .end local v6    # "by":I
    .end local v7    # "bz":I
    .end local v8    # "hitBlock":B
    :cond_1
    const v5, 0x3dcccccd    # 0.1f

    add-float/2addr v4, v5

    goto :goto_0

    :cond_2
    nop

    .line 499
    .end local v4    # "dist":F
    const/4 v4, 0x0

    return-object v4
.end method

.method public render([FLcom/EZdev/mc2/Gameplay;)V
    .locals 48
    .param p1, "vpMatrix"    # [F
    .param p2, "gameplay"    # Lcom/EZdev/mc2/Gameplay;

    .line 252
    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    if-eqz v8, :cond_0

    if-nez v7, :cond_1

    :cond_0
    goto/16 :goto_11

    .line 253
    :cond_1
    iget-object v1, v8, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    if-nez v1, :cond_2

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v8, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    .line 254
    :cond_2
    iget-object v1, v8, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    if-nez v1, :cond_3

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v8, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    .line 255
    :cond_3
    iget-object v1, v8, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    if-nez v1, :cond_4

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v8, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    .line 256
    :cond_4
    iput-object v8, v0, Lcom/EZdev/mc2/WorldLogic;->gameplayRef:Lcom/EZdev/mc2/Gameplay;

    .line 258
    const v9, 0x3c83126f    # 0.016f

    .line 260
    .local v9, "dt":F
    iget v1, v8, Lcom/EZdev/mc2/Gameplay;->gameTime:F

    const v10, 0x3d4ccccd    # 0.05f

    mul-float/2addr v1, v10

    float-to-double v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    mul-double/2addr v1, v3

    add-double/2addr v1, v3

    double-to-float v11, v1

    .line 261
    .local v11, "dayCycle":F
    const v12, 0x3ecccccd    # 0.4f

    mul-float v1, v11, v12

    const v13, 0x3dcccccd    # 0.1f

    add-float/2addr v1, v13

    .local v1, "rCol":F
    const v2, 0x3f19999a    # 0.6f

    mul-float v3, v11, v2

    const v14, 0x3e4ccccd    # 0.2f

    add-float/2addr v3, v14

    .local v3, "gCol":F
    mul-float v4, v11, v2

    add-float/2addr v4, v12

    .line 262
    .local v4, "bCol":F
    iget-boolean v5, v8, Lcom/EZdev/mc2/Gameplay;->isRaining:Z

    if-eqz v5, :cond_5

    .line 263
    const/high16 v5, 0x3f000000    # 0.5f

    mul-float/2addr v1, v5

    mul-float/2addr v3, v2

    const v2, 0x3f333333    # 0.7f

    mul-float/2addr v4, v2

    move v15, v1

    move v6, v3

    move v5, v4

    goto :goto_0

    .line 262
    :cond_5
    move v15, v1

    move v6, v3

    move v5, v4

    .line 265
    .end local v1    # "rCol":F
    .end local v3    # "gCol":F
    .end local v4    # "bCol":F
    .local v5, "bCol":F
    .local v6, "gCol":F
    .local v15, "rCol":F
    :goto_0
    const/high16 v4, 0x3f800000    # 1.0f

    invoke-static {v15, v6, v5, v4}, Landroid/opengl/GLES20;->glClearColor(FFFF)V

    .line 267
    sget v1, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    invoke-static {v1}, Landroid/opengl/GLES20;->glUseProgram(I)V

    .line 268
    sget v1, Lcom/EZdev/mc2/Booster;->posHandle:I

    invoke-static {v1}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    .line 269
    sget v1, Lcom/EZdev/mc2/Booster;->colorHandle:I

    invoke-static {v1}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    .line 271
    sget v1, Lcom/EZdev/mc2/Booster;->fogEnabledHandle:I

    iget-boolean v2, v0, Lcom/EZdev/mc2/WorldLogic;->fogEnabled:Z

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 272
    sget v1, Lcom/EZdev/mc2/Booster;->fogEndHandle:I

    iget v2, v0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    int-to-float v2, v2

    const/high16 v3, 0x41800000    # 16.0f

    mul-float/2addr v2, v3

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1f(IF)V

    .line 273
    sget v1, Lcom/EZdev/mc2/Booster;->isFlashingHandle:I

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 274
    sget v1, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 276
    const/16 v16, 0xbe2

    invoke-static/range {v16 .. v16}, Landroid/opengl/GLES20;->glEnable(I)V

    .line 277
    const/16 v1, 0x302

    const/16 v4, 0x303

    invoke-static {v1, v4}, Landroid/opengl/GLES20;->glBlendFunc(II)V

    .line 279
    iget v1, v8, Lcom/EZdev/mc2/Gameplay;->camX:F

    div-float v18, v1, v3

    .line 280
    .local v18, "camChunkX":F
    iget v1, v8, Lcom/EZdev/mc2/Gameplay;->camZ:F

    div-float v19, v1, v3

    .line 281
    .local v19, "camChunkZ":F
    iget v1, v0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    add-int/lit8 v3, v1, 0x1

    const/4 v4, 0x1

    add-int/2addr v1, v4

    mul-int/2addr v3, v1

    int-to-float v3, v3

    .line 283
    .local v3, "renderRadiusSq":F
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v20

    :goto_1
    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v13, 0x0

    if-eqz v1, :cond_9

    invoke-interface/range {v20 .. v20}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v22, v1

    check-cast v22, Ljava/util/Map$Entry;

    .line 284
    .local v22, "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Long;Lcom/EZdev/mc2/Chunk;>;"
    invoke-interface/range {v22 .. v22}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/EZdev/mc2/Chunk;

    .line 285
    .local v1, "c":Lcom/EZdev/mc2/Chunk;
    iget-object v4, v1, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    if-eqz v4, :cond_8

    iget v4, v1, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    if-nez v4, :cond_6

    const/4 v4, 0x1

    const v10, 0x3d4ccccd    # 0.05f

    const v13, 0x3dcccccd    # 0.1f

    goto :goto_1

    .line 287
    :cond_6
    iget v4, v1, Lcom/EZdev/mc2/Chunk;->chunkX:I

    int-to-float v4, v4

    sub-float v24, v4, v18

    .line 288
    .local v24, "dx":F
    iget v4, v1, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    int-to-float v4, v4

    sub-float v25, v4, v19

    .line 289
    .local v25, "dz":F
    mul-float v4, v24, v24

    mul-float v26, v25, v25

    add-float v4, v4, v26

    cmpl-float v4, v4, v3

    if-lez v4, :cond_7

    const/4 v4, 0x1

    const v10, 0x3d4ccccd    # 0.05f

    const v13, 0x3dcccccd    # 0.1f

    goto :goto_1

    .line 291
    :cond_7
    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    invoke-static {v4, v2}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 292
    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    iget v14, v1, Lcom/EZdev/mc2/Chunk;->chunkX:I

    mul-int/lit8 v14, v14, 0x10

    int-to-float v14, v14

    iget v12, v1, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    mul-int/lit8 v12, v12, 0x10

    int-to-float v12, v12

    invoke-static {v4, v2, v14, v13, v12}, Landroid/opengl/Matrix;->translateM([FIFFF)V

    .line 293
    iget-object v4, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v12, 0x0

    const/4 v13, 0x0

    iget-object v14, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/16 v28, 0x0

    move-object v10, v1

    .end local v1    # "c":Lcom/EZdev/mc2/Chunk;
    .local v10, "c":Lcom/EZdev/mc2/Chunk;
    move-object v1, v4

    move v4, v2

    move v2, v12

    move v12, v3

    .end local v3    # "renderRadiusSq":F
    .local v12, "renderRadiusSq":F
    move-object/from16 v3, p1

    const/high16 v17, 0x3f800000    # 1.0f

    move v4, v13

    move/from16 v23, v5

    .end local v5    # "bCol":F
    .local v23, "bCol":F
    move-object v5, v14

    move v14, v6

    .end local v6    # "gCol":F
    .local v14, "gCol":F
    move/from16 v6, v28

    invoke-static/range {v1 .. v6}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 294
    sget v1, Lcom/EZdev/mc2/Booster;->mvpHandle:I

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1, v5, v6, v2, v6}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 295
    sget v1, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    invoke-static {v1, v6}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 296
    iget-object v1, v10, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    invoke-virtual {v1, v6}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    .line 297
    sget v29, Lcom/EZdev/mc2/Booster;->posHandle:I

    const/16 v30, 0x3

    const/16 v31, 0x1406

    const/16 v32, 0x0

    const/16 v33, 0x0

    iget-object v1, v10, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    move-object/from16 v34, v1

    invoke-static/range {v29 .. v34}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 298
    iget-object v1, v10, Lcom/EZdev/mc2/Chunk;->colorBuffer:Ljava/nio/FloatBuffer;

    invoke-virtual {v1, v6}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    .line 299
    sget v29, Lcom/EZdev/mc2/Booster;->colorHandle:I

    const/16 v30, 0x4

    iget-object v1, v10, Lcom/EZdev/mc2/Chunk;->colorBuffer:Ljava/nio/FloatBuffer;

    move-object/from16 v34, v1

    invoke-static/range {v29 .. v34}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 300
    iget v1, v10, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    const/4 v2, 0x4

    invoke-static {v2, v6, v1}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    .line 301
    .end local v10    # "c":Lcom/EZdev/mc2/Chunk;
    .end local v22    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Long;Lcom/EZdev/mc2/Chunk;>;"
    .end local v24    # "dx":F
    .end local v25    # "dz":F
    move v4, v5

    move v2, v6

    move v3, v12

    move v6, v14

    move/from16 v5, v23

    const v10, 0x3d4ccccd    # 0.05f

    const v12, 0x3ecccccd    # 0.4f

    const v13, 0x3dcccccd    # 0.1f

    const v14, 0x3e4ccccd    # 0.2f

    goto/16 :goto_1

    .line 285
    .end local v12    # "renderRadiusSq":F
    .end local v14    # "gCol":F
    .end local v23    # "bCol":F
    .restart local v1    # "c":Lcom/EZdev/mc2/Chunk;
    .restart local v3    # "renderRadiusSq":F
    .restart local v5    # "bCol":F
    .restart local v6    # "gCol":F
    .restart local v22    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Long;Lcom/EZdev/mc2/Chunk;>;"
    :cond_8
    move-object v10, v1

    move v12, v3

    move/from16 v23, v5

    move v14, v6

    const/4 v5, 0x1

    const/high16 v17, 0x3f800000    # 1.0f

    move v6, v2

    .end local v1    # "c":Lcom/EZdev/mc2/Chunk;
    .end local v3    # "renderRadiusSq":F
    .end local v5    # "bCol":F
    .end local v6    # "gCol":F
    .restart local v10    # "c":Lcom/EZdev/mc2/Chunk;
    .restart local v12    # "renderRadiusSq":F
    .restart local v14    # "gCol":F
    .restart local v23    # "bCol":F
    move v4, v5

    move v6, v14

    move/from16 v5, v23

    const v10, 0x3d4ccccd    # 0.05f

    const v12, 0x3ecccccd    # 0.4f

    const v13, 0x3dcccccd    # 0.1f

    const v14, 0x3e4ccccd    # 0.2f

    goto/16 :goto_1

    .line 303
    .end local v10    # "c":Lcom/EZdev/mc2/Chunk;
    .end local v12    # "renderRadiusSq":F
    .end local v14    # "gCol":F
    .end local v22    # "entry":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/Long;Lcom/EZdev/mc2/Chunk;>;"
    .end local v23    # "bCol":F
    .restart local v3    # "renderRadiusSq":F
    .restart local v5    # "bCol":F
    .restart local v6    # "gCol":F
    :cond_9
    move v12, v3

    move/from16 v23, v5

    move v14, v6

    const/high16 v17, 0x3f800000    # 1.0f

    move v6, v2

    move v5, v4

    .end local v3    # "renderRadiusSq":F
    .end local v5    # "bCol":F
    .end local v6    # "gCol":F
    .restart local v12    # "renderRadiusSq":F
    .restart local v14    # "gCol":F
    .restart local v23    # "bCol":F
    invoke-static/range {v16 .. v16}, Landroid/opengl/GLES20;->glDisable(I)V

    .line 305
    sget-object v1, Lcom/EZdev/mc2/Booster;->tntVertexBuffer:Ljava/nio/FloatBuffer;

    if-eqz v1, :cond_24

    .line 306
    sget v1, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    const/16 v2, 0x64

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 307
    const/4 v1, 0x0

    move v10, v1

    .local v10, "i":I
    :goto_2
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v10, v1, :cond_c

    .line 308
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lcom/EZdev/mc2/Entity;

    .line 309
    .local v3, "e":Lcom/EZdev/mc2/Entity;
    if-nez v3, :cond_b

    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v5

    .local v1, "lastIdx":I
    if-ge v10, v1, :cond_a

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/EZdev/mc2/Entity;

    invoke-virtual {v2, v10, v4}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_a
    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move v13, v5

    move/from16 v27, v11

    const v16, 0x3ecccccd    # 0.4f

    move v11, v6

    goto :goto_3

    .line 310
    .end local v1    # "lastIdx":I
    :cond_b
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    invoke-static {v1, v6}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 311
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    iget v2, v3, Lcom/EZdev/mc2/Entity;->x:F

    const v16, 0x3ecccccd    # 0.4f

    sub-float v2, v2, v16

    iget v4, v3, Lcom/EZdev/mc2/Entity;->y:F

    iget v5, v3, Lcom/EZdev/mc2/Entity;->z:F

    sub-float v5, v5, v16

    invoke-static {v1, v6, v2, v4, v5}, Landroid/opengl/Matrix;->translateM([FIFFF)V

    .line 312
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const v2, 0x3f4ccccd    # 0.8f

    invoke-static {v1, v6, v2, v2, v2}, Landroid/opengl/Matrix;->scaleM([FIFFF)V

    .line 313
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v2, 0x0

    const/4 v4, 0x0

    iget-object v5, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/16 v22, 0x0

    move-object/from16 v24, v3

    .end local v3    # "e":Lcom/EZdev/mc2/Entity;
    .local v24, "e":Lcom/EZdev/mc2/Entity;
    move-object/from16 v3, p1

    const/16 v13, 0x24

    const/4 v13, 0x1

    move/from16 v27, v11

    move v11, v6

    .end local v11    # "dayCycle":F
    .local v27, "dayCycle":F
    move/from16 v6, v22

    invoke-static/range {v1 .. v6}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 314
    sget v1, Lcom/EZdev/mc2/Booster;->mvpHandle:I

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    invoke-static {v1, v13, v11, v2, v11}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 315
    sget v29, Lcom/EZdev/mc2/Booster;->posHandle:I

    const/16 v30, 0x3

    const/16 v31, 0x1406

    const/16 v32, 0x0

    const/16 v33, 0x0

    sget-object v34, Lcom/EZdev/mc2/Booster;->tntVertexBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v29 .. v34}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 316
    sget v1, Lcom/EZdev/mc2/Booster;->colorHandle:I

    const/4 v2, 0x4

    const/16 v3, 0x1406

    const/4 v5, 0x0

    sget-object v6, Lcom/EZdev/mc2/Booster;->tntColorBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v1 .. v6}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 317
    const/4 v1, 0x4

    const/16 v2, 0x24

    invoke-static {v1, v11, v2}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    .line 307
    .end local v24    # "e":Lcom/EZdev/mc2/Entity;
    :goto_3
    add-int/lit8 v10, v10, 0x1

    move v6, v11

    move v5, v13

    move/from16 v11, v27

    const/4 v13, 0x0

    goto/16 :goto_2

    .end local v27    # "dayCycle":F
    .restart local v11    # "dayCycle":F
    :cond_c
    move v13, v5

    move/from16 v27, v11

    move v11, v6

    .line 320
    .end local v10    # "i":I
    .end local v11    # "dayCycle":F
    .restart local v27    # "dayCycle":F
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v13

    move v10, v1

    .restart local v10    # "i":I
    :goto_4
    const v16, 0x3e19999a    # 0.15f

    if-ltz v10, :cond_1e

    .line 321
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v5, v1

    check-cast v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;

    .line 322
    .local v5, "item":Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    if-nez v5, :cond_e

    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v13

    .restart local v1    # "lastIdx":I
    if-ge v10, v1, :cond_d

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/EZdev/mc2/WorldLogic$ItemEntity;

    invoke-virtual {v2, v10, v3}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_d
    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move/from16 v35, v9

    move/from16 v24, v12

    const/4 v11, 0x0

    goto/16 :goto_b

    .line 323
    .end local v1    # "lastIdx":I
    :cond_e
    invoke-virtual {v5, v9}, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->update(F)V

    .line 325
    iget v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    const/4 v2, 0x0

    cmpg-float v1, v1, v2

    if-gtz v1, :cond_10

    .line 326
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v13

    .restart local v1    # "lastIdx":I
    if-ge v10, v1, :cond_f

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/EZdev/mc2/WorldLogic$ItemEntity;

    invoke-virtual {v2, v10, v3}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_f
    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 327
    move/from16 v35, v9

    move/from16 v24, v12

    const/4 v11, 0x0

    goto/16 :goto_b

    .line 332
    .end local v1    # "lastIdx":I
    :cond_10
    const/4 v1, 0x0

    .local v1, "j":I
    :goto_5
    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_14

    .line 333
    if-eq v10, v1, :cond_12

    .line 334
    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;

    .line 335
    .local v2, "other":Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    if-eqz v2, :cond_11

    iget-byte v3, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    iget-byte v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    if-ne v3, v4, :cond_11

    iget v3, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    const/16 v4, 0x40

    if-ge v3, v4, :cond_11

    iget v6, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    if-ge v6, v4, :cond_11

    .line 336
    iget v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    iget v11, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    sub-float/2addr v4, v11

    .local v4, "dxi":F
    iget v11, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    iget v13, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    sub-float/2addr v11, v13

    .local v11, "dyi":F
    iget v13, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    move/from16 v24, v12

    .end local v12    # "renderRadiusSq":F
    .local v24, "renderRadiusSq":F
    iget v12, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    sub-float/2addr v13, v12

    .line 337
    .local v13, "dzi":F
    mul-float v12, v4, v4

    mul-float v28, v11, v11

    add-float v12, v12, v28

    mul-float v28, v13, v13

    add-float v12, v12, v28

    const/high16 v28, 0x3e800000    # 0.25f

    cmpg-float v12, v12, v28

    if-gez v12, :cond_13

    .line 338
    rsub-int/lit8 v3, v3, 0x40

    .local v3, "space":I
    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    .line 339
    .local v6, "transfer":I
    iget v12, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    add-int/2addr v12, v6

    iput v12, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    iget v12, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    sub-int/2addr v12, v6

    iput v12, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    .line 340
    if-gtz v12, :cond_13

    const/4 v12, 0x0

    iput v12, v2, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    goto :goto_6

    .line 335
    .end local v3    # "space":I
    .end local v4    # "dxi":F
    .end local v6    # "transfer":I
    .end local v11    # "dyi":F
    .end local v13    # "dzi":F
    .end local v24    # "renderRadiusSq":F
    .restart local v12    # "renderRadiusSq":F
    :cond_11
    move/from16 v24, v12

    .end local v12    # "renderRadiusSq":F
    .restart local v24    # "renderRadiusSq":F
    goto :goto_6

    .line 333
    .end local v2    # "other":Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    .end local v24    # "renderRadiusSq":F
    .restart local v12    # "renderRadiusSq":F
    :cond_12
    move/from16 v24, v12

    .line 332
    .end local v12    # "renderRadiusSq":F
    .restart local v24    # "renderRadiusSq":F
    :cond_13
    :goto_6
    add-int/lit8 v1, v1, 0x1

    move/from16 v12, v24

    const/4 v11, 0x0

    const/4 v13, 0x1

    goto :goto_5

    .end local v24    # "renderRadiusSq":F
    .restart local v12    # "renderRadiusSq":F
    :cond_14
    move/from16 v24, v12

    .line 349
    .end local v1    # "j":I
    .end local v12    # "renderRadiusSq":F
    .restart local v24    # "renderRadiusSq":F
    iget v1, v8, Lcom/EZdev/mc2/Gameplay;->camY:F

    iget v2, v8, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    sub-float v11, v1, v2

    .line 350
    .local v11, "playerCenterY":F
    iget v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    iget v2, v8, Lcom/EZdev/mc2/Gameplay;->camX:F

    sub-float v12, v1, v2

    .line 351
    .local v12, "dx":F
    iget v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    sub-float v13, v1, v11

    .line 352
    .local v13, "dy":F
    iget v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    iget v2, v8, Lcom/EZdev/mc2/Gameplay;->camZ:F

    sub-float v28, v1, v2

    .line 353
    .local v28, "dz":F
    mul-float v1, v12, v12

    mul-float v2, v13, v13

    add-float/2addr v1, v2

    mul-float v2, v28, v28

    add-float v6, v1, v2

    .line 355
    .local v6, "distanceSq":F
    iget v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->pickupDelay:F

    const/4 v2, 0x0

    cmpg-float v1, v1, v2

    if-gtz v1, :cond_1d

    iget-boolean v1, v8, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    if-nez v1, :cond_1d

    .line 356
    const/high16 v1, 0x3fc00000    # 1.5f

    cmpg-float v1, v6, v1

    if-gez v1, :cond_16

    iget-object v1, v8, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v1, :cond_16

    iget-object v1, v1, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    if-eqz v1, :cond_16

    .line 357
    iget-byte v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    iget v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    invoke-virtual {v1, v2, v4}, Lcom/EZdev/mc2/UIManager;->addToInventory(BI)I

    move-result v1

    .line 358
    .local v1, "overflow":I
    if-nez v1, :cond_15

    .line 359
    const/4 v2, 0x0

    iput v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    goto :goto_7

    .line 361
    :cond_15
    iput v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    .line 364
    .end local v1    # "overflow":I
    :cond_16
    :goto_7
    const/high16 v1, 0x40c00000    # 6.0f

    cmpg-float v1, v6, v1

    if-gez v1, :cond_1c

    .line 365
    float-to-double v1, v6

    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v1

    double-to-float v1, v1

    .line 368
    .local v1, "dist":F
    const/4 v2, 0x0

    iput v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->vy:F

    .line 371
    iget v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    div-float v4, v12, v1

    const/high16 v31, 0x41200000    # 10.0f

    mul-float v4, v4, v31

    mul-float/2addr v4, v9

    sub-float/2addr v2, v4

    iput v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    .line 372
    iget v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    div-float v32, v13, v1

    mul-float v32, v32, v31

    mul-float v32, v32, v9

    sub-float v4, v4, v32

    iput v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    .line 373
    iget v3, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    div-float v33, v28, v1

    mul-float v33, v33, v31

    mul-float v33, v33, v9

    sub-float v3, v3, v33

    iput v3, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    .line 376
    move/from16 v31, v1

    .end local v1    # "dist":F
    .local v31, "dist":F
    iget v1, v8, Lcom/EZdev/mc2/Gameplay;->camX:F

    move/from16 v33, v6

    .end local v6    # "distanceSq":F
    .local v33, "distanceSq":F
    iget v6, v8, Lcom/EZdev/mc2/Gameplay;->playerWidth:F

    const/high16 v32, 0x40000000    # 2.0f

    div-float v34, v6, v32

    sub-float v34, v1, v34

    .line 377
    .local v34, "pMinX":F
    div-float v35, v6, v32

    add-float v1, v1, v35

    .line 378
    .local v1, "pMaxX":F
    move/from16 v35, v9

    .end local v9    # "dt":F
    .local v35, "dt":F
    iget v9, v8, Lcom/EZdev/mc2/Gameplay;->camY:F

    .line 379
    .local v9, "pMinY":F
    move/from16 v36, v11

    .end local v11    # "playerCenterY":F
    .local v36, "playerCenterY":F
    iget v11, v8, Lcom/EZdev/mc2/Gameplay;->camY:F

    move/from16 v37, v12

    .end local v12    # "dx":F
    .local v37, "dx":F
    iget v12, v8, Lcom/EZdev/mc2/Gameplay;->playerHeight:F

    add-float/2addr v11, v12

    const v12, 0x3e4ccccd    # 0.2f

    add-float/2addr v11, v12

    .line 380
    .local v11, "pMaxY":F
    iget v12, v8, Lcom/EZdev/mc2/Gameplay;->camZ:F

    div-float v38, v6, v32

    sub-float v38, v12, v38

    .line 381
    .local v38, "pMinZ":F
    div-float v6, v6, v32

    add-float/2addr v12, v6

    .line 384
    .local v12, "pMaxZ":F
    sub-float v6, v2, v16

    .local v6, "iMinX":F
    add-float v2, v2, v16

    .line 385
    .local v2, "iMaxX":F
    sub-float v32, v4, v16

    .local v32, "iMinY":F
    add-float v4, v4, v16

    .line 386
    .local v4, "iMaxY":F
    sub-float v39, v3, v16

    .local v39, "iMinZ":F
    add-float v3, v3, v16

    .line 388
    .local v3, "iMaxZ":F
    cmpg-float v40, v34, v2

    if-gtz v40, :cond_17

    cmpl-float v40, v1, v6

    if-ltz v40, :cond_17

    cmpg-float v40, v9, v4

    if-gtz v40, :cond_17

    cmpl-float v40, v11, v32

    if-ltz v40, :cond_17

    cmpg-float v40, v38, v3

    if-gtz v40, :cond_17

    cmpl-float v40, v12, v39

    if-ltz v40, :cond_17

    const/16 v40, 0x1

    goto :goto_8

    :cond_17
    const/16 v40, 0x0

    .line 392
    .local v40, "intersect":Z
    :goto_8
    if-eqz v40, :cond_1b

    .line 393
    move/from16 v41, v1

    .end local v1    # "pMaxX":F
    .local v41, "pMaxX":F
    iget-object v1, v8, Lcom/EZdev/mc2/Gameplay;->activity:Lcom/EZdev/mc2/MainActivity;

    if-eqz v1, :cond_1a

    iget-object v1, v1, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    if-eqz v1, :cond_1a

    .line 394
    move/from16 v42, v2

    .end local v2    # "iMaxX":F
    .local v42, "iMaxX":F
    iget-byte v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    move/from16 v43, v3

    .end local v3    # "iMaxZ":F
    .local v43, "iMaxZ":F
    iget v3, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    invoke-virtual {v1, v2, v3}, Lcom/EZdev/mc2/UIManager;->addToInventory(BI)I

    move-result v1

    .line 395
    .local v1, "overflow":I
    if-lez v1, :cond_18

    .line 396
    iput v1, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->count:I

    goto :goto_a

    .line 398
    :cond_18
    const/4 v3, 0x0

    iput v3, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->life:F

    .line 399
    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v16, 0x1

    add-int/lit8 v2, v2, -0x1

    .line 400
    .local v2, "lastIdx":I
    if-ge v10, v2, :cond_19

    iget-object v3, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v16

    move/from16 v44, v1

    .end local v1    # "overflow":I
    .local v44, "overflow":I
    move-object/from16 v1, v16

    check-cast v1, Lcom/EZdev/mc2/WorldLogic$ItemEntity;

    invoke-virtual {v3, v10, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_9

    .end local v44    # "overflow":I
    .restart local v1    # "overflow":I
    :cond_19
    move/from16 v44, v1

    .line 401
    .end local v1    # "overflow":I
    .restart local v44    # "overflow":I
    :goto_9
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 402
    const/4 v11, 0x0

    goto/16 :goto_b

    .line 393
    .end local v42    # "iMaxX":F
    .end local v43    # "iMaxZ":F
    .end local v44    # "overflow":I
    .local v2, "iMaxX":F
    .restart local v3    # "iMaxZ":F
    :cond_1a
    move/from16 v42, v2

    move/from16 v43, v3

    .end local v2    # "iMaxX":F
    .end local v3    # "iMaxZ":F
    .restart local v42    # "iMaxX":F
    .restart local v43    # "iMaxZ":F
    goto :goto_a

    .line 392
    .end local v41    # "pMaxX":F
    .end local v42    # "iMaxX":F
    .end local v43    # "iMaxZ":F
    .local v1, "pMaxX":F
    .restart local v2    # "iMaxX":F
    .restart local v3    # "iMaxZ":F
    :cond_1b
    move/from16 v41, v1

    move/from16 v42, v2

    move/from16 v43, v3

    .end local v1    # "pMaxX":F
    .end local v2    # "iMaxX":F
    .end local v3    # "iMaxZ":F
    .restart local v41    # "pMaxX":F
    .restart local v42    # "iMaxX":F
    .restart local v43    # "iMaxZ":F
    goto :goto_a

    .line 364
    .end local v4    # "iMaxY":F
    .end local v31    # "dist":F
    .end local v32    # "iMinY":F
    .end local v33    # "distanceSq":F
    .end local v34    # "pMinX":F
    .end local v35    # "dt":F
    .end local v36    # "playerCenterY":F
    .end local v37    # "dx":F
    .end local v38    # "pMinZ":F
    .end local v39    # "iMinZ":F
    .end local v40    # "intersect":Z
    .end local v41    # "pMaxX":F
    .end local v42    # "iMaxX":F
    .end local v43    # "iMaxZ":F
    .local v6, "distanceSq":F
    .local v9, "dt":F
    .local v11, "playerCenterY":F
    .local v12, "dx":F
    :cond_1c
    move/from16 v33, v6

    move/from16 v35, v9

    move/from16 v36, v11

    move/from16 v37, v12

    .end local v6    # "distanceSq":F
    .end local v9    # "dt":F
    .end local v11    # "playerCenterY":F
    .end local v12    # "dx":F
    .restart local v33    # "distanceSq":F
    .restart local v35    # "dt":F
    .restart local v36    # "playerCenterY":F
    .restart local v37    # "dx":F
    goto :goto_a

    .line 355
    .end local v33    # "distanceSq":F
    .end local v35    # "dt":F
    .end local v36    # "playerCenterY":F
    .end local v37    # "dx":F
    .restart local v6    # "distanceSq":F
    .restart local v9    # "dt":F
    .restart local v11    # "playerCenterY":F
    .restart local v12    # "dx":F
    :cond_1d
    move/from16 v33, v6

    move/from16 v35, v9

    move/from16 v36, v11

    move/from16 v37, v12

    .line 414
    .end local v6    # "distanceSq":F
    .end local v9    # "dt":F
    .end local v11    # "playerCenterY":F
    .end local v12    # "dx":F
    .restart local v33    # "distanceSq":F
    .restart local v35    # "dt":F
    .restart local v36    # "playerCenterY":F
    .restart local v37    # "dx":F
    :goto_a
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 415
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    iget v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->x:F

    sub-float v2, v2, v16

    iget v3, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->y:F

    iget v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->hoverOffset:F

    const/high16 v6, 0x40400000    # 3.0f

    mul-float/2addr v4, v6

    float-to-double v11, v4

    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v4, v11

    const v6, 0x3dcccccd    # 0.1f

    mul-float/2addr v4, v6

    add-float/2addr v3, v4

    iget v4, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->z:F

    sub-float v4, v4, v16

    const/4 v6, 0x0

    invoke-static {v1, v6, v2, v3, v4}, Landroid/opengl/Matrix;->translateM([FIFFF)V

    .line 416
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/16 v39, 0x0

    iget v2, v5, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->hoverOffset:F

    const/high16 v3, 0x42480000    # 50.0f

    mul-float v40, v2, v3

    const/16 v41, 0x0

    const/high16 v42, 0x3f800000    # 1.0f

    const/16 v43, 0x0

    move-object/from16 v38, v1

    invoke-static/range {v38 .. v43}, Landroid/opengl/Matrix;->rotateM([FIFFFF)V

    .line 417
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v2, 0x0

    const v6, 0x3e99999a    # 0.3f

    invoke-static {v1, v2, v6, v6, v6}, Landroid/opengl/Matrix;->scaleM([FIFFF)V

    .line 418
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v2, 0x0

    const/4 v4, 0x0

    iget-object v6, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v9, 0x0

    const/4 v11, 0x0

    move-object/from16 v3, p1

    move-object v12, v5

    .end local v5    # "item":Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    .local v12, "item":Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    move-object v5, v6

    move/from16 v16, v33

    .end local v33    # "distanceSq":F
    .local v16, "distanceSq":F
    move v6, v9

    invoke-static/range {v1 .. v6}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 419
    sget v1, Lcom/EZdev/mc2/Booster;->mvpHandle:I

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v4, v3, v2, v3}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 420
    sget v1, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    iget-byte v2, v12, Lcom/EZdev/mc2/WorldLogic$ItemEntity;->type:B

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 421
    sget v38, Lcom/EZdev/mc2/Booster;->posHandle:I

    const/16 v39, 0x3

    const/16 v40, 0x1406

    const/16 v41, 0x0

    const/16 v42, 0x0

    sget-object v43, Lcom/EZdev/mc2/Booster;->tntVertexBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v38 .. v43}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 422
    sget v1, Lcom/EZdev/mc2/Booster;->colorHandle:I

    const/4 v2, 0x4

    const/16 v3, 0x1406

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v6, Lcom/EZdev/mc2/Booster;->tntColorBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v1 .. v6}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 423
    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v3, 0x24

    invoke-static {v2, v1, v3}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    .line 320
    .end local v12    # "item":Lcom/EZdev/mc2/WorldLogic$ItemEntity;
    .end local v13    # "dy":F
    .end local v16    # "distanceSq":F
    .end local v28    # "dz":F
    .end local v36    # "playerCenterY":F
    .end local v37    # "dx":F
    :goto_b
    add-int/lit8 v10, v10, -0x1

    move/from16 v12, v24

    move/from16 v9, v35

    const/4 v11, 0x0

    const/4 v13, 0x1

    goto/16 :goto_4

    .end local v24    # "renderRadiusSq":F
    .end local v35    # "dt":F
    .restart local v9    # "dt":F
    .local v12, "renderRadiusSq":F
    :cond_1e
    move/from16 v35, v9

    move/from16 v24, v12

    const v6, 0x3e99999a    # 0.3f

    .line 426
    .end local v9    # "dt":F
    .end local v10    # "i":I
    .end local v12    # "renderRadiusSq":F
    .restart local v24    # "renderRadiusSq":F
    .restart local v35    # "dt":F
    sget v1, Lcom/EZdev/mc2/Booster;->isFlashingHandle:I

    const/4 v2, 0x1

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 427
    sget v1, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    const/4 v2, 0x5

    invoke-static {v1, v2}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 428
    iget-object v1, v8, Lcom/EZdev/mc2/Gameplay;->tickingTNTs:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_c
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1f

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v10, v1

    check-cast v10, Lcom/EZdev/mc2/Gameplay$ActiveTNT;

    .line 429
    .local v10, "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroid/opengl/Matrix;->setIdentityM([FI)V

    .line 430
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    iget v3, v10, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->x:F

    iget v4, v10, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->y:F

    iget v5, v10, Lcom/EZdev/mc2/Gameplay$ActiveTNT;->z:F

    invoke-static {v1, v2, v3, v4, v5}, Landroid/opengl/Matrix;->translateM([FIFFF)V

    .line 431
    iget v1, v8, Lcom/EZdev/mc2/Gameplay;->gameTime:F

    float-to-double v1, v1

    const-wide/high16 v3, 0x402e000000000000L    # 15.0

    mul-double/2addr v1, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v1, v1

    const v11, 0x3d4ccccd    # 0.05f

    mul-float/2addr v1, v11

    add-float v12, v1, v17

    .line 432
    .local v12, "scale":F
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v2, 0x0

    invoke-static {v1, v2, v12, v12, v12}, Landroid/opengl/Matrix;->scaleM([FIFFF)V

    .line 433
    iget-object v1, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v2, 0x0

    const/4 v4, 0x0

    iget-object v5, v0, Lcom/EZdev/mc2/WorldLogic;->modelMatrix:[F

    const/4 v13, 0x0

    move-object/from16 v3, p1

    move/from16 v21, v6

    move v6, v13

    invoke-static/range {v1 .. v6}, Landroid/opengl/Matrix;->multiplyMM([FI[FI[FI)V

    .line 434
    sget v1, Lcom/EZdev/mc2/Booster;->mvpHandle:I

    iget-object v2, v0, Lcom/EZdev/mc2/WorldLogic;->finalMVP:[F

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v4, v3, v2, v3}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    .line 435
    sget v36, Lcom/EZdev/mc2/Booster;->posHandle:I

    const/16 v37, 0x3

    const/16 v38, 0x1406

    const/16 v39, 0x0

    const/16 v40, 0x0

    sget-object v41, Lcom/EZdev/mc2/Booster;->tntVertexBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v36 .. v41}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 436
    sget v42, Lcom/EZdev/mc2/Booster;->colorHandle:I

    const/16 v43, 0x4

    const/16 v44, 0x1406

    const/16 v45, 0x0

    const/16 v46, 0x0

    sget-object v47, Lcom/EZdev/mc2/Booster;->tntColorBuffer:Ljava/nio/FloatBuffer;

    invoke-static/range {v42 .. v47}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    .line 437
    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v3, 0x24

    invoke-static {v2, v1, v3}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    .line 438
    .end local v10    # "tnt":Lcom/EZdev/mc2/Gameplay$ActiveTNT;
    .end local v12    # "scale":F
    move/from16 v6, v21

    goto :goto_c

    .line 439
    :cond_1f
    move/from16 v21, v6

    const/4 v1, 0x0

    sget v2, Lcom/EZdev/mc2/Booster;->isFlashingHandle:I

    invoke-static {v2, v1}, Landroid/opengl/GLES20;->glUniform1i(II)V

    .line 441
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_d
    iget-object v2, v8, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_22

    .line 442
    iget-object v2, v8, Lcom/EZdev/mc2/Gameplay;->fireParticles:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    .line 443
    .local v2, "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    if-eqz v2, :cond_21

    .line 444
    iget-byte v3, v2, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->type:B

    const/16 v4, 0x63

    if-ne v3, v4, :cond_20

    move/from16 v6, v21

    goto :goto_e

    :cond_20
    move/from16 v6, v16

    :goto_e
    move v4, v6

    .line 445
    .local v4, "size":F
    invoke-direct {v0, v2, v7, v4, v3}, Lcom/EZdev/mc2/WorldLogic;->renderParticle(Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;[FFB)V

    .line 441
    .end local v2    # "p":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    .end local v4    # "size":F
    :cond_21
    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    :cond_22
    nop

    .line 448
    .end local v1    # "i":I
    const/4 v1, 0x0

    .restart local v1    # "i":I
    :goto_f
    iget-object v2, v8, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_25

    .line 449
    iget-object v2, v8, Lcom/EZdev/mc2/Gameplay;->blockParticles:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;

    .line 450
    .local v2, "bp":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    if-eqz v2, :cond_23

    .line 451
    iget-byte v3, v2, Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;->type:B

    const v4, 0x3dcccccd    # 0.1f

    invoke-direct {v0, v2, v7, v4, v3}, Lcom/EZdev/mc2/WorldLogic;->renderParticle(Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;[FFB)V

    goto :goto_10

    .line 450
    :cond_23
    const v4, 0x3dcccccd    # 0.1f

    .line 448
    .end local v2    # "bp":Lcom/EZdev/mc2/Gameplay$ActiveFireParticle;
    :goto_10
    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    .line 305
    .end local v1    # "i":I
    .end local v24    # "renderRadiusSq":F
    .end local v27    # "dayCycle":F
    .end local v35    # "dt":F
    .restart local v9    # "dt":F
    .local v11, "dayCycle":F
    .local v12, "renderRadiusSq":F
    :cond_24
    move/from16 v35, v9

    move/from16 v27, v11

    move/from16 v24, v12

    .line 455
    .end local v9    # "dt":F
    .end local v11    # "dayCycle":F
    .end local v12    # "renderRadiusSq":F
    .restart local v24    # "renderRadiusSq":F
    .restart local v27    # "dayCycle":F
    .restart local v35    # "dt":F
    :cond_25
    sget v1, Lcom/EZdev/mc2/Booster;->posHandle:I

    invoke-static {v1}, Landroid/opengl/GLES20;->glDisableVertexAttribArray(I)V

    .line 456
    sget v1, Lcom/EZdev/mc2/Booster;->colorHandle:I

    invoke-static {v1}, Landroid/opengl/GLES20;->glDisableVertexAttribArray(I)V

    .line 457
    return-void

    .line 252
    .end local v14    # "gCol":F
    .end local v15    # "rCol":F
    .end local v18    # "camChunkX":F
    .end local v19    # "camChunkZ":F
    .end local v23    # "bCol":F
    .end local v24    # "renderRadiusSq":F
    .end local v27    # "dayCycle":F
    .end local v35    # "dt":F
    :goto_11
    return-void
.end method

.method public setBlock(IIIB)V
    .locals 8
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I
    .param p4, "type"    # B

    .line 118
    if-ltz p2, :cond_0

    const/16 v0, 0x80

    if-lt p2, v0, :cond_1

    :cond_0
    goto :goto_0

    .line 120
    :cond_1
    invoke-virtual {p0, p1, p2, p3}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v0

    const/16 v1, 0x9

    if-ne v0, v1, :cond_2

    if-nez p4, :cond_2

    return-void

    .line 122
    :cond_2
    int-to-double v0, p1

    const-wide/high16 v2, 0x4030000000000000L    # 16.0

    div-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-int v0, v0

    .line 123
    .local v0, "cx":I
    int-to-double v4, p3

    div-double/2addr v4, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    .line 124
    .local v1, "cz":I
    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v2

    .line 125
    .local v2, "key":J
    iget-object v4, p0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/EZdev/mc2/Chunk;

    .line 126
    .local v4, "c":Lcom/EZdev/mc2/Chunk;
    if-eqz v4, :cond_7

    .line 127
    mul-int/lit8 v5, v0, 0x10

    sub-int v5, p1, v5

    .line 128
    .local v5, "lx":I
    mul-int/lit8 v6, v1, 0x10

    sub-int v6, p3, v6

    .line 129
    .local v6, "lz":I
    iget-object v7, v4, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v7, v7, v5

    aget-object v7, v7, p2

    aput-byte p4, v7, v6

    .line 130
    invoke-virtual {v4}, Lcom/EZdev/mc2/Chunk;->buildMesh()V

    .line 132
    iget-object v7, p0, Lcom/EZdev/mc2/WorldLogic;->saveManager:Lcom/EZdev/mc2/SaveManager;

    if-eqz v7, :cond_3

    invoke-virtual {v7, v4}, Lcom/EZdev/mc2/SaveManager;->saveChunk(Lcom/EZdev/mc2/Chunk;)V

    .line 134
    :cond_3
    if-nez v5, :cond_4

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/WorldLogic;->updateNeighbors(II)V

    .line 135
    :cond_4
    const/16 v7, 0xf

    if-ne v5, v7, :cond_5

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/WorldLogic;->updateNeighbors(II)V

    .line 136
    :cond_5
    if-nez v6, :cond_6

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/WorldLogic;->updateNeighbors(II)V

    .line 137
    :cond_6
    if-ne v6, v7, :cond_7

    invoke-direct {p0, v0, v1}, Lcom/EZdev/mc2/WorldLogic;->updateNeighbors(II)V

    .line 139
    .end local v5    # "lx":I
    .end local v6    # "lz":I
    :cond_7
    return-void

    .line 118
    .end local v0    # "cx":I
    .end local v1    # "cz":I
    .end local v2    # "key":J
    .end local v4    # "c":Lcom/EZdev/mc2/Chunk;
    :goto_0
    return-void
.end method

.method public spawnItemEntity(FFFBI)V
    .locals 9
    .param p1, "x"    # F
    .param p2, "y"    # F
    .param p3, "z"    # F
    .param p4, "type"    # B
    .param p5, "count"    # I

    .line 71
    iget-object v0, p0, Lcom/EZdev/mc2/WorldLogic;->droppedItems:Ljava/util/ArrayList;

    new-instance v8, Lcom/EZdev/mc2/WorldLogic$ItemEntity;

    const/4 v1, 0x0

    invoke-static {v1, p5}, Ljava/lang/Math;->max(II)I

    move-result v7

    move-object v1, v8

    move-object v2, p0

    move v3, p1

    move v4, p2

    move v5, p3

    move v6, p4

    invoke-direct/range {v1 .. v7}, Lcom/EZdev/mc2/WorldLogic$ItemEntity;-><init>(Lcom/EZdev/mc2/WorldLogic;FFFBI)V

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 72
    return-void
.end method

.method public spawnItemEntity(IIIB)V
    .locals 8
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I
    .param p4, "type"    # B

    .line 68
    int-to-float v0, p1

    const/high16 v1, 0x3f000000    # 0.5f

    add-float v3, v0, v1

    int-to-float v0, p2

    add-float v4, v0, v1

    int-to-float v0, p3

    add-float v5, v0, v1

    const/4 v7, 0x1

    move-object v2, p0

    move v6, p4

    invoke-virtual/range {v2 .. v7}, Lcom/EZdev/mc2/WorldLogic;->spawnItemEntity(FFFBI)V

    .line 69
    return-void
.end method

.method public updateChunks(FF)V
    .locals 13
    .param p1, "playerX"    # F
    .param p2, "playerZ"    # F

    .line 75
    float-to-double v0, p1

    const-wide/high16 v2, 0x4030000000000000L    # 16.0

    div-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->floor(D)D

    move-result-wide v0

    double-to-int v0, v0

    .line 76
    .local v0, "playerChunkX":I
    float-to-double v4, p2

    div-double/2addr v4, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    double-to-int v1, v1

    .line 78
    .local v1, "playerChunkZ":I
    iget v2, p0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    neg-int v2, v2

    .local v2, "x":I
    :goto_0
    iget v3, p0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    if-gt v2, v3, :cond_5

    .line 79
    neg-int v3, v3

    .local v3, "z":I
    :goto_1
    iget v4, p0, Lcom/EZdev/mc2/WorldLogic;->renderDistance:I

    if-gt v3, v4, :cond_4

    .line 80
    mul-int v5, v2, v2

    mul-int v6, v3, v3

    add-int/2addr v5, v6

    mul-int/2addr v4, v4

    if-le v5, v4, :cond_0

    goto/16 :goto_3

    .line 82
    :cond_0
    add-int v4, v0, v2

    add-int v5, v1, v3

    invoke-direct {p0, v4, v5}, Lcom/EZdev/mc2/WorldLogic;->getChunkKey(II)J

    move-result-wide v4

    .line 83
    .local v4, "key":J
    iget-object v6, p0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3

    .line 84
    new-instance v6, Lcom/EZdev/mc2/Chunk;

    add-int v7, v0, v2

    add-int v8, v1, v3

    invoke-direct {v6, p0, v7, v8}, Lcom/EZdev/mc2/Chunk;-><init>(Lcom/EZdev/mc2/WorldLogic;II)V

    .line 85
    .local v6, "newChunk":Lcom/EZdev/mc2/Chunk;
    iget-object v7, p0, Lcom/EZdev/mc2/WorldLogic;->chunks:Ljava/util/HashMap;

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    invoke-virtual {v7, v8, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 86
    add-int v7, v0, v2

    add-int v8, v1, v3

    invoke-direct {p0, v7, v8}, Lcom/EZdev/mc2/WorldLogic;->updateNeighbors(II)V

    .line 88
    iget-object v7, p0, Lcom/EZdev/mc2/WorldLogic;->random:Ljava/security/SecureRandom;

    invoke-virtual {v7}, Ljava/util/Random;->nextFloat()F

    move-result v7

    const v8, 0x3e4ccccd    # 0.2f

    cmpg-float v7, v7, v8

    if-gez v7, :cond_2

    .line 89
    const/high16 v7, 0x42fe0000    # 127.0f

    .line 90
    .local v7, "ey":F
    :goto_2
    const/4 v8, 0x0

    cmpl-float v8, v7, v8

    if-lez v8, :cond_1

    add-int v8, v0, v2

    mul-int/lit8 v8, v8, 0x10

    add-int/lit8 v8, v8, 0x8

    float-to-int v9, v7

    add-int v10, v1, v3

    mul-int/lit8 v10, v10, 0x10

    add-int/lit8 v10, v10, 0x8

    invoke-virtual {p0, v8, v9, v10}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v8

    if-nez v8, :cond_1

    const/high16 v8, 0x3f800000    # 1.0f

    sub-float/2addr v7, v8

    goto :goto_2

    .line 91
    :cond_1
    const/high16 v8, 0x42480000    # 50.0f

    cmpl-float v8, v7, v8

    if-lez v8, :cond_2

    iget-object v8, p0, Lcom/EZdev/mc2/WorldLogic;->entities:Ljava/util/ArrayList;

    new-instance v9, Lcom/EZdev/mc2/Entity;

    add-int v10, v0, v2

    mul-int/lit8 v10, v10, 0x10

    add-int/lit8 v10, v10, 0x8

    int-to-float v10, v10

    const v11, 0x3f8ccccd    # 1.1f

    add-float/2addr v11, v7

    add-int v12, v1, v3

    mul-int/lit8 v12, v12, 0x10

    add-int/lit8 v12, v12, 0x8

    int-to-float v12, v12

    invoke-direct {v9, v10, v11, v12}, Lcom/EZdev/mc2/Entity;-><init>(FFF)V

    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 93
    .end local v7    # "ey":F
    :cond_2
    return-void

    .line 79
    .end local v4    # "key":J
    .end local v6    # "newChunk":Lcom/EZdev/mc2/Chunk;
    :cond_3
    :goto_3
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1

    :cond_4
    nop

    .line 78
    .end local v3    # "z":I
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :cond_5
    nop

    .line 97
    .end local v2    # "x":I
    return-void
.end method
