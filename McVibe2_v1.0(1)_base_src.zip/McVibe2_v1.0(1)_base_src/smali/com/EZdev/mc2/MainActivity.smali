.class public Lcom/EZdev/mc2/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# instance fields
.field public engine:Lcom/EZdev/mc2/MyGdxGame;

.field public musicManager:Lcom/EZdev/mc2/MusicManager;

.field public soundManager:Lcom/EZdev/mc2/SoundManager;

.field private surfaceView:Landroid/opengl/GLSurfaceView;

.field public uiManager:Lcom/EZdev/mc2/UIManager;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 11
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 19
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 21
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "LOAD_WORLD"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    .line 22
    .local v0, "loadWorld":Z
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    const-string v3, "CREATIVE_MODE"

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    .line 24
    .local v1, "isCreative":Z
    if-nez v0, :cond_0

    .line 25
    new-instance v3, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v4

    const-string v5, "world1"

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 26
    .local v3, "dir":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-virtual {v3}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 27
    invoke-virtual {v3}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v4

    array-length v5, v4

    :goto_0
    nop

    if-ge v2, v5, :cond_0

    aget-object v6, v4, v2

    .line 28
    .local v6, "f":Ljava/io/File;
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    .line 27
    .end local v6    # "f":Ljava/io/File;
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 33
    .end local v3    # "dir":Ljava/io/File;
    :cond_0
    new-instance v2, Landroid/opengl/GLSurfaceView;

    invoke-direct {v2, p0}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    iput-object v2, p0, Lcom/EZdev/mc2/MainActivity;->surfaceView:Landroid/opengl/GLSurfaceView;

    .line 34
    const/4 v3, 0x2

    invoke-virtual {v2, v3}, Landroid/opengl/GLSurfaceView;->setEGLContextClientVersion(I)V

    .line 35
    iget-object v4, p0, Lcom/EZdev/mc2/MainActivity;->surfaceView:Landroid/opengl/GLSurfaceView;

    const/16 v5, 0x8

    const/16 v6, 0x8

    const/16 v7, 0x8

    const/16 v8, 0x8

    const/16 v9, 0x10

    const/4 v10, 0x0

    invoke-virtual/range {v4 .. v10}, Landroid/opengl/GLSurfaceView;->setEGLConfigChooser(IIIIII)V

    .line 37
    new-instance v2, Lcom/EZdev/mc2/MyGdxGame;

    invoke-direct {v2, p0}, Lcom/EZdev/mc2/MyGdxGame;-><init>(Lcom/EZdev/mc2/MainActivity;)V

    iput-object v2, p0, Lcom/EZdev/mc2/MainActivity;->engine:Lcom/EZdev/mc2/MyGdxGame;

    .line 38
    iget-object v3, v2, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput-boolean v1, v3, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    .line 39
    if-eqz v1, :cond_1

    const/4 v4, 0x1

    iput-boolean v4, v3, Lcom/EZdev/mc2/Gameplay;->isFlying:Z

    .line 41
    :cond_1
    iget-object v3, p0, Lcom/EZdev/mc2/MainActivity;->surfaceView:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v3, v2}, Landroid/opengl/GLSurfaceView;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V

    .line 43
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 44
    .local v2, "root":Landroid/widget/FrameLayout;
    iget-object v3, p0, Lcom/EZdev/mc2/MainActivity;->surfaceView:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 46
    new-instance v3, Lcom/EZdev/mc2/UIManager;

    iget-object v4, p0, Lcom/EZdev/mc2/MainActivity;->engine:Lcom/EZdev/mc2/MyGdxGame;

    invoke-direct {v3, p0, v4}, Lcom/EZdev/mc2/UIManager;-><init>(Lcom/EZdev/mc2/MainActivity;Lcom/EZdev/mc2/MyGdxGame;)V

    iput-object v3, p0, Lcom/EZdev/mc2/MainActivity;->uiManager:Lcom/EZdev/mc2/UIManager;

    .line 47
    invoke-virtual {v3, v2}, Lcom/EZdev/mc2/UIManager;->setupUI(Landroid/widget/FrameLayout;)V

    .line 49
    invoke-virtual {p0, v2}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 51
    new-instance v3, Lcom/EZdev/mc2/MusicManager;

    invoke-direct {v3, p0}, Lcom/EZdev/mc2/MusicManager;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    .line 52
    invoke-virtual {v3}, Lcom/EZdev/mc2/MusicManager;->startMusic()V

    .line 54
    new-instance v3, Lcom/EZdev/mc2/SoundManager;

    invoke-direct {v3, p0}, Lcom/EZdev/mc2/SoundManager;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lcom/EZdev/mc2/MainActivity;->soundManager:Lcom/EZdev/mc2/SoundManager;

    .line 55
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 59
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    iget-object v0, p0, Lcom/EZdev/mc2/MainActivity;->soundManager:Lcom/EZdev/mc2/SoundManager;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/EZdev/mc2/SoundManager;->release()V

    :cond_0
    return-void
.end method

.method public onPause()V
    .locals 1

    .line 57
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    iget-object v0, p0, Lcom/EZdev/mc2/MainActivity;->surfaceView:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0}, Landroid/opengl/GLSurfaceView;->onPause()V

    iget-object v0, p0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/EZdev/mc2/MusicManager;->stopMusic()V

    :cond_0
    return-void
.end method

.method public onResume()V
    .locals 1

    .line 58
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    iget-object v0, p0, Lcom/EZdev/mc2/MainActivity;->surfaceView:Landroid/opengl/GLSurfaceView;

    invoke-virtual {v0}, Landroid/opengl/GLSurfaceView;->onResume()V

    iget-object v0, p0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/EZdev/mc2/MusicManager;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/EZdev/mc2/MainActivity;->musicManager:Lcom/EZdev/mc2/MusicManager;

    invoke-virtual {v0}, Lcom/EZdev/mc2/MusicManager;->startMusic()V

    :cond_0
    return-void
.end method
