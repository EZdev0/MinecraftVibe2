.class public Lcom/EZdev/mc2/McApp;
.super Landroid/app/Application;
.source "McApp.java"


# static fields
.field private static final ANR_TIMEOUT:I = 0x1388


# instance fields
.field private volatile lastTick:J

.field private final uiHandler:Landroid/os/Handler;

.field private watchdogThread:Ljava/lang/Thread;


# direct methods
.method public static synthetic $r8$lambda$OD2XPgqwR_TLKFjnPvxDhWcb8iU(Lcom/EZdev/mc2/McApp;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/McApp;->lambda$startWatchdog$2()V

    return-void
.end method

.method public static synthetic $r8$lambda$VYaR_DKTLoXXp_Ogo2loFvLd5YA(Lcom/EZdev/mc2/McApp;Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1, p2}, Lcom/EZdev/mc2/McApp;->lambda$onCreate$0(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    return-void
.end method

.method public static synthetic $r8$lambda$VhphgzR7bvKLO_LhYN6K0AV9UOc(Lcom/EZdev/mc2/McApp;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Lcom/EZdev/mc2/McApp;->lambda$startWatchdog$1()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 15
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    .line 18
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/EZdev/mc2/McApp;->uiHandler:Landroid/os/Handler;

    .line 19
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/EZdev/mc2/McApp;->lastTick:J

    return-void
.end method

.method private synthetic lambda$onCreate$0(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 4
    .param p1, "thread"    # Ljava/lang/Thread;
    .param p2, "e"    # Ljava/lang/Throwable;

    .line 27
    new-instance v0, Ljava/io/StringWriter;

    invoke-direct {v0}, Ljava/io/StringWriter;-><init>()V

    .line 28
    .local v0, "sw":Ljava/io/StringWriter;
    new-instance v1, Ljava/io/PrintWriter;

    invoke-direct {v1, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    invoke-virtual {p2, v1}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    .line 29
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Crash detected: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "McApp"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "An unexpected error occurred. Please restart the app."

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Lcom/EZdev/mc2/McApp;->triggerCrashHandler(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 33
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-static {v1}, Landroid/os/Process;->killProcess(I)V

    .line 34
    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/System;->exit(I)V

    .line 35
    return-void
.end method

.method private synthetic lambda$startWatchdog$1()V
    .locals 2

    .line 57
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/EZdev/mc2/McApp;->lastTick:J

    return-void
.end method

.method private synthetic lambda$startWatchdog$2()V
    .locals 8

    .line 55
    nop

    :goto_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v0

    if-nez v0, :cond_2

    .line 56
    iget-wide v0, p0, Lcom/EZdev/mc2/McApp;->lastTick:J

    .line 57
    .local v0, "currentTick":J
    iget-object v2, p0, Lcom/EZdev/mc2/McApp;->uiHandler:Landroid/os/Handler;

    new-instance v3, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda2;

    invoke-direct {v3, p0}, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda2;-><init>(Lcom/EZdev/mc2/McApp;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 60
    const-wide/16 v2, 0x1388

    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 63
    goto :goto_1

    .line 61
    :catch_0
    move-exception v2

    .line 62
    .local v2, "e":Ljava/lang/InterruptedException;
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Thread;->interrupt()V

    .line 65
    .end local v2    # "e":Ljava/lang/InterruptedException;
    :goto_1
    iget-wide v2, p0, Lcom/EZdev/mc2/McApp;->lastTick:J

    cmp-long v2, v2, v0

    if-nez v2, :cond_1

    iget-wide v2, p0, Lcom/EZdev/mc2/McApp;->lastTick:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-eqz v2, :cond_1

    .line 67
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v2

    .line 68
    .local v2, "stackTrace":[Ljava/lang/StackTraceElement;
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "ANR detected\n"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 69
    .local v3, "sb":Ljava/lang/StringBuilder;
    array-length v4, v2

    const/4 v5, 0x0

    :goto_2
    if-ge v5, v4, :cond_0

    aget-object v6, v2, v5

    .line 70
    .local v6, "el":Ljava/lang/StackTraceElement;
    invoke-virtual {v6}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "\n"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    .end local v6    # "el":Ljava/lang/StackTraceElement;
    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    .line 72
    :cond_0
    const-string v4, "McApp"

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 74
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-string v5, "The application has stopped responding."

    const/4 v6, 0x1

    invoke-static {v4, v5, v6}, Lcom/EZdev/mc2/McApp;->triggerCrashHandler(Landroid/content/Context;Ljava/lang/String;Z)V

    .line 77
    goto :goto_3

    .line 79
    .end local v0    # "currentTick":J
    .end local v2    # "stackTrace":[Ljava/lang/StackTraceElement;
    .end local v3    # "sb":Ljava/lang/StringBuilder;
    :cond_1
    goto :goto_0

    .line 80
    :cond_2
    :goto_3
    return-void
.end method

.method private startWatchdog()V
    .locals 2

    .line 54
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda1;-><init>(Lcom/EZdev/mc2/McApp;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    iput-object v0, p0, Lcom/EZdev/mc2/McApp;->watchdogThread:Ljava/lang/Thread;

    .line 81
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 82
    return-void
.end method

.method public static triggerCrashHandler(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 3
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "errorMsg"    # Ljava/lang/String;
    .param p2, "canContinue"    # Z

    .line 41
    :try_start_0
    const-string v0, "crash_log.txt"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->openFileOutput(Ljava/lang/String;I)Ljava/io/FileOutputStream;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    .local v0, "fos":Ljava/io/FileOutputStream;
    :try_start_1
    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 43
    :try_start_2
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 45
    .end local v0    # "fos":Ljava/io/FileOutputStream;
    goto :goto_2

    .line 43
    :catch_0
    move-exception v0

    goto :goto_1

    .line 41
    .restart local v0    # "fos":Ljava/io/FileOutputStream;
    :catchall_0
    move-exception v1

    if-eqz v0, :cond_0

    :try_start_3
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_0

    :catchall_1
    move-exception v2

    :try_start_4
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    nop

    .end local p0    # "context":Landroid/content/Context;
    .end local p1    # "errorMsg":Ljava/lang/String;
    .end local p2    # "canContinue":Z
    throw v1
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    .line 43
    .end local v0    # "fos":Ljava/io/FileOutputStream;
    .restart local p0    # "context":Landroid/content/Context;
    .restart local p1    # "errorMsg":Ljava/lang/String;
    .restart local p2    # "canContinue":Z
    :goto_1
    nop

    .line 44
    .local v0, "e":Ljava/io/IOException;
    const-string v1, "McApp"

    const-string v2, "Failed to save crash log"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 47
    .end local v0    # "e":Ljava/io/IOException;
    :goto_2
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/EZdev/mc2/CrashHandlerActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 48
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "canContinue"

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 49
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 50
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 51
    return-void
.end method


# virtual methods
.method public onCreate()V
    .locals 1

    .line 24
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 26
    new-instance v0, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/EZdev/mc2/McApp$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/McApp;)V

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    .line 37
    invoke-direct {p0}, Lcom/EZdev/mc2/McApp;->startWatchdog()V

    .line 38
    return-void
.end method
