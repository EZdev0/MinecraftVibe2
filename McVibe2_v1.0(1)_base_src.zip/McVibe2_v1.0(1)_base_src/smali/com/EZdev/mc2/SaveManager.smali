.class public Lcom/EZdev/mc2/SaveManager;
.super Ljava/lang/Object;
.source "SaveManager.java"


# static fields
.field private static final TAG:Ljava/lang/String; = "SaveManager"


# instance fields
.field private context:Landroid/content/Context;

.field private worldName:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1
    .param p1, "context"    # Landroid/content/Context;

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    const-string v0, "world1"

    iput-object v0, p0, Lcom/EZdev/mc2/SaveManager;->worldName:Ljava/lang/String;

    .line 16
    iput-object p1, p0, Lcom/EZdev/mc2/SaveManager;->context:Landroid/content/Context;

    .line 17
    return-void
.end method


# virtual methods
.method public getBaseDir()Ljava/io/File;
    .locals 1

    .line 83
    iget-object v0, p0, Lcom/EZdev/mc2/SaveManager;->context:Landroid/content/Context;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public loadChunk(Lcom/EZdev/mc2/Chunk;)Z
    .locals 11
    .param p1, "chunk"    # Lcom/EZdev/mc2/Chunk;

    .line 49
    const-string v0, "SaveManager"

    const/4 v1, 0x0

    if-nez p1, :cond_0

    .line 50
    :try_start_0
    const-string v2, "Cannot load chunk: chunk is null"

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 51
    return v1

    .line 76
    :catch_0
    move-exception v2

    goto/16 :goto_2

    .line 53
    :cond_0
    invoke-virtual {p0}, Lcom/EZdev/mc2/SaveManager;->getBaseDir()Ljava/io/File;

    move-result-object v2

    .line 54
    .local v2, "baseDir":Ljava/io/File;
    if-nez v2, :cond_1

    .line 55
    const-string v3, "Cannot load chunk: base directory is null"

    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 56
    return v1

    .line 58
    :cond_1
    new-instance v3, Ljava/io/File;

    iget-object v4, p0, Lcom/EZdev/mc2/SaveManager;->worldName:Ljava/lang/String;

    invoke-direct {v3, v2, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 59
    .local v3, "dir":Ljava/io/File;
    new-instance v4, Ljava/io/File;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "chunk_"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, p1, Lcom/EZdev/mc2/Chunk;->chunkX:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "_"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, p1, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ".dat"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v3, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 61
    .local v4, "file":Ljava/io/File;
    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v5

    if-nez v5, :cond_2

    return v1

    .line 63
    :cond_2
    new-instance v5, Ljava/io/FileInputStream;

    invoke-direct {v5, v4}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 64
    .local v5, "fis":Ljava/io/FileInputStream;
    const/4 v6, 0x0

    .local v6, "x":I
    :goto_0
    const/16 v7, 0x10

    if-ge v6, v7, :cond_5

    .line 65
    const/4 v8, 0x0

    .local v8, "y":I
    :goto_1
    const/16 v9, 0x80

    if-ge v8, v9, :cond_4

    .line 66
    iget-object v9, p1, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v9, v9, v6

    aget-object v9, v9, v8

    invoke-virtual {v5, v9}, Ljava/io/FileInputStream;->read([B)I

    move-result v9

    .line 67
    .local v9, "bytesRead":I
    if-ge v9, v7, :cond_3

    .line 68
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Incomplete chunk file: read only "

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v10, " bytes for x="

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v10, ", y="

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v0, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 69
    invoke-virtual {v5}, Ljava/io/FileInputStream;->close()V

    .line 70
    return v1

    .line 67
    :cond_3
    nop

    .line 65
    .end local v9    # "bytesRead":I
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_4
    nop

    .line 64
    .end local v8    # "y":I
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_5
    nop

    .line 74
    .end local v6    # "x":I
    invoke-virtual {v5}, Ljava/io/FileInputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 75
    const/4 v0, 0x1

    return v0

    .line 76
    .end local v2    # "baseDir":Ljava/io/File;
    .end local v3    # "dir":Ljava/io/File;
    .end local v4    # "file":Ljava/io/File;
    .end local v5    # "fis":Ljava/io/FileInputStream;
    :goto_2
    nop

    .line 77
    .local v2, "e":Ljava/lang/Exception;
    const-string v3, "Error loading chunk"

    invoke-static {v0, v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 78
    return v1
.end method

.method public saveChunk(Lcom/EZdev/mc2/Chunk;)V
    .locals 8
    .param p1, "chunk"    # Lcom/EZdev/mc2/Chunk;

    .line 21
    const-string v0, "SaveManager"

    if-nez p1, :cond_0

    .line 22
    :try_start_0
    const-string v1, "Cannot save chunk: chunk is null"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 23
    return-void

    .line 42
    :catch_0
    move-exception v1

    goto :goto_2

    .line 25
    :cond_0
    invoke-virtual {p0}, Lcom/EZdev/mc2/SaveManager;->getBaseDir()Ljava/io/File;

    move-result-object v1

    .line 26
    .local v1, "baseDir":Ljava/io/File;
    if-nez v1, :cond_1

    .line 27
    const-string v2, "Cannot save chunk: base directory is null"

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 28
    return-void

    .line 30
    :cond_1
    new-instance v2, Ljava/io/File;

    iget-object v3, p0, Lcom/EZdev/mc2/SaveManager;->worldName:Ljava/lang/String;

    invoke-direct {v2, v1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 31
    .local v2, "dir":Ljava/io/File;
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 33
    :cond_2
    new-instance v3, Ljava/io/File;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "chunk_"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, p1, Lcom/EZdev/mc2/Chunk;->chunkX:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "_"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, p1, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, ".dat"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v2, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 34
    .local v3, "file":Ljava/io/File;
    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 36
    .local v4, "fos":Ljava/io/FileOutputStream;
    const/4 v5, 0x0

    .local v5, "x":I
    :goto_0
    const/16 v6, 0x10

    if-ge v5, v6, :cond_4

    .line 37
    const/4 v6, 0x0

    .local v6, "y":I
    :goto_1
    const/16 v7, 0x80

    if-ge v6, v7, :cond_3

    .line 38
    iget-object v7, p1, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v7, v7, v5

    aget-object v7, v7, v6

    invoke-virtual {v4, v7}, Ljava/io/FileOutputStream;->write([B)V

    .line 37
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_3
    nop

    .line 36
    .end local v6    # "y":I
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    nop

    .line 41
    .end local v5    # "x":I
    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 44
    .end local v1    # "baseDir":Ljava/io/File;
    .end local v2    # "dir":Ljava/io/File;
    .end local v3    # "file":Ljava/io/File;
    .end local v4    # "fos":Ljava/io/FileOutputStream;
    goto :goto_3

    .line 42
    :goto_2
    nop

    .line 43
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "Error saving chunk"

    invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 45
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_3
    return-void
.end method
