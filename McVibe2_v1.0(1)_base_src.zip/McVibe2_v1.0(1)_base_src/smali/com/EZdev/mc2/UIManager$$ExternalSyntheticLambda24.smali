.class public final synthetic Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda24;
.super Ljava/lang/Object;
.source "R8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/EZdev/mc2/UIManager;


# direct methods
.method public synthetic constructor <init>(Lcom/EZdev/mc2/UIManager;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda24;->f$0:Lcom/EZdev/mc2/UIManager;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/EZdev/mc2/UIManager$$ExternalSyntheticLambda24;->f$0:Lcom/EZdev/mc2/UIManager;

    invoke-virtual {v0}, Lcom/EZdev/mc2/UIManager;->updateHotbarUI()V

    return-void
.end method
