.class public Lcom/EZdev/mc2/Chunk;
.super Ljava/lang/Object;
.source "Chunk.java"


# static fields
.field private static final MAX_POSSIBLE_VERTS:I = 0x60000

.field private static final meshLock:Ljava/lang/Object;

.field private static final sharedCData:[F

.field private static final sharedVData:[F


# instance fields
.field public blocks:[[[B

.field private bufferCapacity:I

.field public chunkX:I

.field public chunkZ:I

.field public colorBuffer:Ljava/nio/FloatBuffer;

.field private final random:Ljava/util/Random;

.field public vertexBuffer:Ljava/nio/FloatBuffer;

.field public vertexCount:I

.field private world:Lcom/EZdev/mc2/WorldLogic;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 17
    const/high16 v0, 0x120000

    new-array v0, v0, [F

    sput-object v0, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    .line 18
    const/high16 v0, 0x180000

    new-array v0, v0, [F

    sput-object v0, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    .line 19
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/EZdev/mc2/Chunk;->meshLock:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/EZdev/mc2/WorldLogic;II)V
    .locals 5
    .param p1, "world"    # Lcom/EZdev/mc2/WorldLogic;
    .param p2, "cx"    # I
    .param p3, "cz"    # I

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    const/16 v0, 0x10

    const/16 v1, 0x80

    filled-new-array {v0, v1, v0}, [I

    move-result-object v0

    sget-object v1, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[[B

    iput-object v0, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    .line 14
    const/4 v0, 0x0

    iput v0, p0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 21
    iput v0, p0, Lcom/EZdev/mc2/Chunk;->bufferCapacity:I

    .line 24
    iput-object p1, p0, Lcom/EZdev/mc2/Chunk;->world:Lcom/EZdev/mc2/WorldLogic;

    iput p2, p0, Lcom/EZdev/mc2/Chunk;->chunkX:I

    iput p3, p0, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    .line 25
    iget-wide v0, p1, Lcom/EZdev/mc2/WorldLogic;->worldSeed:J

    int-to-long v2, p2

    const/16 v4, 0x20

    shl-long/2addr v2, v4

    xor-long/2addr v0, v2

    int-to-long v2, p3

    xor-long/2addr v0, v2

    .line 26
    .local v0, "chunkSeed":J
    new-instance v2, Ljava/util/Random;

    invoke-direct {v2, v0, v1}, Ljava/util/Random;-><init>(J)V

    iput-object v2, p0, Lcom/EZdev/mc2/Chunk;->random:Ljava/util/Random;

    .line 28
    const/4 v2, 0x0

    .line 29
    .local v2, "loaded":Z
    iget-object v3, p1, Lcom/EZdev/mc2/WorldLogic;->saveManager:Lcom/EZdev/mc2/SaveManager;

    if-eqz v3, :cond_0

    .line 30
    invoke-virtual {v3, p0}, Lcom/EZdev/mc2/SaveManager;->loadChunk(Lcom/EZdev/mc2/Chunk;)Z

    move-result v2

    .line 33
    :cond_0
    if-nez v2, :cond_1

    .line 34
    invoke-direct {p0}, Lcom/EZdev/mc2/Chunk;->generateTerrain()V

    .line 35
    invoke-direct {p0}, Lcom/EZdev/mc2/Chunk;->addDecorations()V

    .line 36
    iget-object v3, p1, Lcom/EZdev/mc2/WorldLogic;->saveManager:Lcom/EZdev/mc2/SaveManager;

    if-eqz v3, :cond_1

    invoke-virtual {v3, p0}, Lcom/EZdev/mc2/SaveManager;->saveChunk(Lcom/EZdev/mc2/Chunk;)V

    .line 38
    :cond_1
    invoke-virtual {p0}, Lcom/EZdev/mc2/Chunk;->buildMesh()V

    .line 39
    return-void
.end method

.method private addDecorations()V
    .locals 12

    .line 110
    const/4 v0, 0x2

    .local v0, "x":I
    :goto_0
    const/16 v1, 0xe

    if-ge v0, v1, :cond_8

    .line 111
    const/4 v2, 0x2

    .local v2, "z":I
    :goto_1
    if-ge v2, v1, :cond_7

    .line 112
    const/16 v3, 0x64

    .local v3, "y":I
    :goto_2
    const/16 v4, 0x32

    if-le v3, v4, :cond_6

    .line 113
    iget-object v4, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v4, v4, v0

    aget-object v5, v4, v3

    aget-byte v5, v5, v2

    const/4 v6, 0x1

    if-ne v5, v6, :cond_5

    add-int/lit8 v5, v3, 0x1

    aget-object v4, v4, v5

    aget-byte v4, v4, v2

    if-nez v4, :cond_5

    .line 114
    iget-object v4, p0, Lcom/EZdev/mc2/Chunk;->random:Ljava/util/Random;

    invoke-virtual {v4}, Ljava/util/Random;->nextDouble()D

    move-result-wide v4

    const-wide v6, 0x3f947ae147ae147bL    # 0.02

    cmpg-double v4, v4, v6

    if-gez v4, :cond_6

    .line 115
    const/4 v4, 0x1

    .local v4, "h":I
    :goto_3
    const/4 v5, 0x4

    if-gt v4, v5, :cond_0

    iget-object v5, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v5, v5, v0

    add-int v6, v3, v4

    aget-object v5, v5, v6

    const/4 v6, 0x3

    aput-byte v6, v5, v2

    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    .line 116
    .end local v4    # "h":I
    :cond_0
    add-int/lit8 v4, v0, -0x2

    .local v4, "lx":I
    :goto_4
    add-int/lit8 v6, v0, 0x2

    nop

    if-gt v4, v6, :cond_4

    add-int/lit8 v6, v3, 0x3

    .local v6, "ly":I
    :goto_5
    add-int/lit8 v7, v3, 0x5

    nop

    if-gt v6, v7, :cond_3

    add-int/lit8 v7, v2, -0x2

    .local v7, "lz":I
    :goto_6
    add-int/lit8 v8, v2, 0x2

    if-gt v7, v8, :cond_2

    .line 117
    iget-object v8, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v8, v8, v4

    aget-object v8, v8, v6

    aget-byte v8, v8, v7

    if-nez v8, :cond_1

    iget-object v8, p0, Lcom/EZdev/mc2/Chunk;->random:Ljava/util/Random;

    invoke-virtual {v8}, Ljava/util/Random;->nextDouble()D

    move-result-wide v8

    const-wide v10, 0x3fe999999999999aL    # 0.8

    cmpg-double v8, v8, v10

    if-gez v8, :cond_1

    iget-object v8, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v8, v8, v4

    aget-object v8, v8, v6

    aput-byte v5, v8, v7

    .line 116
    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_6

    :cond_2
    nop

    .end local v7    # "lz":I
    add-int/lit8 v6, v6, 0x1

    goto :goto_5

    .end local v6    # "ly":I
    :cond_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    .end local v4    # "lx":I
    :cond_4
    goto :goto_7

    .line 112
    :cond_5
    add-int/lit8 v3, v3, -0x1

    goto :goto_2

    .line 111
    .end local v3    # "y":I
    :cond_6
    :goto_7
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_1

    :cond_7
    nop

    .line 110
    .end local v2    # "z":I
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_8
    nop

    .line 124
    .end local v0    # "x":I
    const/4 v0, 0x0

    .restart local v0    # "x":I
    :goto_8
    const/16 v1, 0x10

    nop

    if-ge v0, v1, :cond_c

    const/4 v2, 0x0

    .restart local v2    # "z":I
    :goto_9
    nop

    if-ge v2, v1, :cond_b

    const/4 v3, 0x5

    .restart local v3    # "y":I
    :goto_a
    const/16 v4, 0x28

    if-ge v3, v4, :cond_a

    .line 125
    iget-object v4, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v4, v4, v0

    aget-object v5, v4, v3

    aget-byte v5, v5, v2

    if-nez v5, :cond_9

    add-int/lit8 v5, v3, 0x1

    aget-object v4, v4, v5

    aget-byte v4, v4, v2

    const/4 v5, 0x2

    if-ne v4, v5, :cond_9

    iget-object v4, p0, Lcom/EZdev/mc2/Chunk;->random:Ljava/util/Random;

    invoke-virtual {v4}, Ljava/util/Random;->nextDouble()D

    move-result-wide v6

    const-wide v8, 0x3fa999999999999aL    # 0.05

    cmpg-double v4, v6, v8

    if-gez v4, :cond_9

    iget-object v4, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v4, v4, v0

    aget-object v4, v4, v3

    aput-byte v5, v4, v2

    .line 124
    :cond_9
    add-int/lit8 v3, v3, 0x1

    goto :goto_a

    :cond_a
    nop

    .end local v3    # "y":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    .end local v2    # "z":I
    :cond_b
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    .line 126
    .end local v0    # "x":I
    :cond_c
    return-void
.end method

.method private addFace([F[FFFFIFFFF)V
    .locals 5
    .param p1, "v"    # [F
    .param p2, "c"    # [F
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "z"    # F
    .param p6, "s"    # I
    .param p7, "r"    # F
    .param p8, "g"    # F
    .param p9, "b"    # F
    .param p10, "a"    # F

    .line 202
    iget v0, p0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    array-length v1, p1

    div-int/lit8 v1, v1, 0x3

    add-int/lit8 v1, v1, -0x6

    if-lt v0, v1, :cond_0

    return-void

    .line 203
    :cond_0
    mul-int/lit8 v1, v0, 0x3

    .line 204
    .local v1, "vc":I
    const/high16 v2, 0x3f800000    # 1.0f

    packed-switch p6, :pswitch_data_0

    goto/16 :goto_0

    .line 246
    :pswitch_0
    aput p3, p1, v1

    add-int/lit8 v3, v1, 0x1

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x2

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 247
    add-int/lit8 v3, v1, 0x3

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x4

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x5

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 248
    add-int/lit8 v3, v1, 0x6

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x7

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x8

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 249
    add-int/lit8 v3, v1, 0x9

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0xa

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xb

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 250
    add-int/lit8 v3, v1, 0xc

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xd

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0xe

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 251
    add-int/lit8 v3, v1, 0xf

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x10

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x11

    add-float/2addr v2, p5

    aput v2, p1, v3

    goto/16 :goto_0

    .line 238
    :pswitch_1
    add-float v3, p3, v2

    aput v3, p1, v1

    add-int/lit8 v3, v1, 0x1

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x2

    aput p5, p1, v3

    .line 239
    add-int/lit8 v3, v1, 0x3

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x4

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x5

    aput p5, p1, v3

    .line 240
    add-int/lit8 v3, v1, 0x6

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x7

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x8

    aput p5, p1, v3

    .line 241
    add-int/lit8 v3, v1, 0x9

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xa

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xb

    aput p5, p1, v3

    .line 242
    add-int/lit8 v3, v1, 0xc

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0xd

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0xe

    aput p5, p1, v3

    .line 243
    add-int/lit8 v3, v1, 0xf

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x10

    add-float/2addr v2, p4

    aput v2, p1, v3

    add-int/lit8 v2, v1, 0x11

    aput p5, p1, v2

    .line 244
    goto/16 :goto_0

    .line 230
    :pswitch_2
    add-float v3, p3, v2

    aput v3, p1, v1

    add-int/lit8 v3, v1, 0x1

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x2

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 231
    add-int/lit8 v3, v1, 0x3

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x4

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x5

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 232
    add-int/lit8 v3, v1, 0x6

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x7

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x8

    aput p5, p1, v3

    .line 233
    add-int/lit8 v3, v1, 0x9

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xa

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xb

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 234
    add-int/lit8 v3, v1, 0xc

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xd

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0xe

    aput p5, p1, v3

    .line 235
    add-int/lit8 v3, v1, 0xf

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x10

    add-float/2addr v2, p4

    aput v2, p1, v3

    add-int/lit8 v2, v1, 0x11

    aput p5, p1, v2

    .line 236
    goto/16 :goto_0

    .line 222
    :pswitch_3
    aput p3, p1, v1

    add-int/lit8 v3, v1, 0x1

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x2

    aput p5, p1, v3

    .line 223
    add-int/lit8 v3, v1, 0x3

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x4

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x5

    aput p5, p1, v3

    .line 224
    add-int/lit8 v3, v1, 0x6

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x7

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x8

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 225
    add-int/lit8 v3, v1, 0x9

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0xa

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xb

    aput p5, p1, v3

    .line 226
    add-int/lit8 v3, v1, 0xc

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0xd

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0xe

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 227
    add-int/lit8 v3, v1, 0xf

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x10

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x11

    add-float/2addr v2, p5

    aput v2, p1, v3

    .line 228
    goto/16 :goto_0

    .line 214
    :pswitch_4
    aput p3, p1, v1

    add-int/lit8 v3, v1, 0x1

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x2

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 215
    add-int/lit8 v3, v1, 0x3

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x4

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x5

    aput p5, p1, v3

    .line 216
    add-int/lit8 v3, v1, 0x6

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x7

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x8

    aput p5, p1, v3

    .line 217
    add-int/lit8 v3, v1, 0x9

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0xa

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0xb

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 218
    add-int/lit8 v3, v1, 0xc

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xd

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0xe

    aput p5, p1, v3

    .line 219
    add-int/lit8 v3, v1, 0xf

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x10

    aput p4, p1, v3

    add-int/lit8 v3, v1, 0x11

    add-float/2addr v2, p5

    aput v2, p1, v3

    .line 220
    goto :goto_0

    .line 206
    :pswitch_5
    aput p3, p1, v1

    add-int/lit8 v3, v1, 0x1

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x2

    aput p5, p1, v3

    .line 207
    add-int/lit8 v3, v1, 0x3

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0x4

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x5

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 208
    add-int/lit8 v3, v1, 0x6

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x7

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x8

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 209
    add-int/lit8 v3, v1, 0x9

    aput p3, p1, v3

    add-int/lit8 v3, v1, 0xa

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xb

    aput p5, p1, v3

    .line 210
    add-int/lit8 v3, v1, 0xc

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xd

    add-float v4, p4, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0xe

    add-float v4, p5, v2

    aput v4, p1, v3

    .line 211
    add-int/lit8 v3, v1, 0xf

    add-float v4, p3, v2

    aput v4, p1, v3

    add-int/lit8 v3, v1, 0x10

    add-float/2addr v2, p4

    aput v2, p1, v3

    add-int/lit8 v2, v1, 0x11

    aput p5, p1, v2

    .line 212
    nop

    .line 254
    :goto_0
    mul-int/lit8 v2, v0, 0x4

    .line 255
    .local v2, "cc":I
    aput p7, p2, v2

    add-int/lit8 v3, v2, 0x1

    aput p8, p2, v3

    add-int/lit8 v3, v2, 0x2

    aput p9, p2, v3

    add-int/lit8 v3, v2, 0x3

    aput p10, p2, v3

    .line 256
    add-int/lit8 v3, v2, 0x4

    aput p7, p2, v3

    add-int/lit8 v3, v2, 0x5

    aput p8, p2, v3

    add-int/lit8 v3, v2, 0x6

    aput p9, p2, v3

    add-int/lit8 v3, v2, 0x7

    aput p10, p2, v3

    .line 257
    add-int/lit8 v3, v2, 0x8

    aput p7, p2, v3

    add-int/lit8 v3, v2, 0x9

    aput p8, p2, v3

    add-int/lit8 v3, v2, 0xa

    aput p9, p2, v3

    add-int/lit8 v3, v2, 0xb

    aput p10, p2, v3

    .line 258
    add-int/lit8 v3, v2, 0xc

    aput p7, p2, v3

    add-int/lit8 v3, v2, 0xd

    aput p8, p2, v3

    add-int/lit8 v3, v2, 0xe

    aput p9, p2, v3

    add-int/lit8 v3, v2, 0xf

    aput p10, p2, v3

    .line 259
    add-int/lit8 v3, v2, 0x10

    aput p7, p2, v3

    add-int/lit8 v3, v2, 0x11

    aput p8, p2, v3

    add-int/lit8 v3, v2, 0x12

    aput p9, p2, v3

    add-int/lit8 v3, v2, 0x13

    aput p10, p2, v3

    .line 260
    add-int/lit8 v3, v2, 0x14

    aput p7, p2, v3

    add-int/lit8 v3, v2, 0x15

    aput p8, p2, v3

    add-int/lit8 v3, v2, 0x16

    aput p9, p2, v3

    add-int/lit8 v3, v2, 0x17

    aput p10, p2, v3

    .line 261
    add-int/lit8 v0, v0, 0x6

    iput v0, p0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 262
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private addFireCross([F[FFFFFFF)V
    .locals 88
    .param p1, "v"    # [F
    .param p2, "c"    # [F
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "z"    # F
    .param p6, "r"    # F
    .param p7, "g"    # F
    .param p8, "b"    # F

    move-object/from16 v66, p0

    move-object/from16 v67, p1

    move-object/from16 v68, p2

    move/from16 v69, p3

    move/from16 v81, p3

    move/from16 v74, p4

    move/from16 v70, p4

    move/from16 v75, p5

    move/from16 v79, p5

    move/from16 v85, p6

    move/from16 v86, p7

    move/from16 v87, p8

    move-object/from16 v44, p0

    move-object/from16 v45, p1

    move-object/from16 v46, p2

    move/from16 v51, p3

    move/from16 v55, p3

    move/from16 v52, p4

    move/from16 v48, p4

    move/from16 v61, p5

    move/from16 v49, p5

    move/from16 v63, p6

    move/from16 v64, p7

    move/from16 v65, p8

    move-object/from16 v22, p0

    move-object/from16 v23, p1

    move-object/from16 v24, p2

    move/from16 v29, p3

    move/from16 v33, p3

    move/from16 v30, p4

    move/from16 v26, p4

    move/from16 v31, p5

    move/from16 v35, p5

    move/from16 v41, p6

    move/from16 v42, p7

    move/from16 v43, p8

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move/from16 v15, p3

    move/from16 v8, p4

    move/from16 v4, p4

    move/from16 v17, p5

    move/from16 v5, p5

    move/from16 v19, p6

    move/from16 v20, p7

    move/from16 v21, p8

    .line 266
    const/high16 v6, 0x3f800000    # 1.0f

    const/high16 v83, 0x3f800000    # 1.0f

    add-float v7, p3, v83

    add-float v9, p5, v83

    const/high16 v10, 0x3f800000    # 1.0f

    add-float v11, p3, v83

    add-float v12, p4, v83

    add-float v13, p5, v83

    const/4 v14, 0x0

    add-float v16, p4, v83

    const/16 v18, 0x0

    invoke-direct/range {v0 .. v21}, Lcom/EZdev/mc2/Chunk;->addQuad([F[FFFFFFFFFFFFFFFFFFFF)V

    .line 267
    add-float v25, p3, v83

    add-float v27, p5, v83

    const/high16 v28, 0x3f800000    # 1.0f

    const/high16 v32, 0x3f800000    # 1.0f

    add-float v34, p4, v83

    const/16 v36, 0x0

    add-float v37, p3, v83

    add-float v38, p4, v83

    add-float v39, p5, v83

    const/16 v40, 0x0

    invoke-direct/range {v22 .. v43}, Lcom/EZdev/mc2/Chunk;->addQuad([F[FFFFFFFFFFFFFFFFFFFF)V

    .line 269
    add-float v47, p3, v83

    const/high16 v50, 0x3f800000    # 1.0f

    add-float v53, p5, v83

    const/high16 v54, 0x3f800000    # 1.0f

    add-float v56, p4, v83

    add-float v57, p5, v83

    const/16 v58, 0x0

    add-float v59, p3, v83

    add-float v60, p4, v83

    const/16 v62, 0x0

    invoke-direct/range {v44 .. v65}, Lcom/EZdev/mc2/Chunk;->addQuad([F[FFFFFFFFFFFFFFFFFFFF)V

    .line 270
    add-float v71, p5, v83

    const/high16 v72, 0x3f800000    # 1.0f

    add-float v73, p3, v83

    const/high16 v76, 0x3f800000    # 1.0f

    add-float v77, p3, v83

    add-float v78, p4, v83

    const/16 v80, 0x0

    add-float v82, p4, v83

    add-float v83, p5, v83

    const/16 v84, 0x0

    invoke-direct/range {v66 .. v87}, Lcom/EZdev/mc2/Chunk;->addQuad([F[FFFFFFFFFFFFFFFFFFFF)V

    .line 271
    return-void
.end method

.method private addQuad([F[FFFFFFFFFFFFFFFFFFFF)V
    .locals 6
    .param p1, "v"    # [F
    .param p2, "c"    # [F
    .param p3, "x1"    # F
    .param p4, "y1"    # F
    .param p5, "z1"    # F
    .param p6, "a1"    # F
    .param p7, "x2"    # F
    .param p8, "y2"    # F
    .param p9, "z2"    # F
    .param p10, "a2"    # F
    .param p11, "x3"    # F
    .param p12, "y3"    # F
    .param p13, "z3"    # F
    .param p14, "a3"    # F
    .param p15, "x4"    # F
    .param p16, "y4"    # F
    .param p17, "z4"    # F
    .param p18, "a4"    # F
    .param p19, "r"    # F
    .param p20, "g"    # F
    .param p21, "b"    # F

    .line 277
    move-object v0, p0

    move-object v1, p1

    iget v2, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    array-length v3, v1

    div-int/lit8 v3, v3, 0x3

    add-int/lit8 v3, v3, -0x6

    if-lt v2, v3, :cond_0

    return-void

    .line 278
    :cond_0
    mul-int/lit8 v3, v2, 0x3

    .line 279
    .local v3, "vc":I
    aput p3, v1, v3

    add-int/lit8 v4, v3, 0x1

    aput p4, v1, v4

    add-int/lit8 v4, v3, 0x2

    aput p5, v1, v4

    .line 280
    add-int/lit8 v4, v3, 0x3

    aput p7, v1, v4

    add-int/lit8 v4, v3, 0x4

    aput p8, v1, v4

    add-int/lit8 v4, v3, 0x5

    aput p9, v1, v4

    .line 281
    add-int/lit8 v4, v3, 0x6

    aput p11, v1, v4

    add-int/lit8 v4, v3, 0x7

    aput p12, v1, v4

    add-int/lit8 v4, v3, 0x8

    aput p13, v1, v4

    .line 282
    add-int/lit8 v4, v3, 0x9

    aput p3, v1, v4

    add-int/lit8 v4, v3, 0xa

    aput p4, v1, v4

    add-int/lit8 v4, v3, 0xb

    aput p5, v1, v4

    .line 283
    add-int/lit8 v4, v3, 0xc

    aput p11, v1, v4

    add-int/lit8 v4, v3, 0xd

    aput p12, v1, v4

    add-int/lit8 v4, v3, 0xe

    aput p13, v1, v4

    .line 284
    add-int/lit8 v4, v3, 0xf

    aput p15, v1, v4

    add-int/lit8 v4, v3, 0x10

    aput p16, v1, v4

    add-int/lit8 v4, v3, 0x11

    aput p17, v1, v4

    .line 286
    mul-int/lit8 v4, v2, 0x4

    .line 287
    .local v4, "cc":I
    aput p19, p2, v4

    add-int/lit8 v5, v4, 0x1

    aput p20, p2, v5

    add-int/lit8 v5, v4, 0x2

    aput p21, p2, v5

    add-int/lit8 v5, v4, 0x3

    aput p6, p2, v5

    .line 288
    add-int/lit8 v5, v4, 0x4

    aput p19, p2, v5

    add-int/lit8 v5, v4, 0x5

    aput p20, p2, v5

    add-int/lit8 v5, v4, 0x6

    aput p21, p2, v5

    add-int/lit8 v5, v4, 0x7

    aput p10, p2, v5

    .line 289
    add-int/lit8 v5, v4, 0x8

    aput p19, p2, v5

    add-int/lit8 v5, v4, 0x9

    aput p20, p2, v5

    add-int/lit8 v5, v4, 0xa

    aput p21, p2, v5

    add-int/lit8 v5, v4, 0xb

    aput p14, p2, v5

    .line 290
    add-int/lit8 v5, v4, 0xc

    aput p19, p2, v5

    add-int/lit8 v5, v4, 0xd

    aput p20, p2, v5

    add-int/lit8 v5, v4, 0xe

    aput p21, p2, v5

    add-int/lit8 v5, v4, 0xf

    aput p6, p2, v5

    .line 291
    add-int/lit8 v5, v4, 0x10

    aput p19, p2, v5

    add-int/lit8 v5, v4, 0x11

    aput p20, p2, v5

    add-int/lit8 v5, v4, 0x12

    aput p21, p2, v5

    add-int/lit8 v5, v4, 0x13

    aput p14, p2, v5

    .line 292
    add-int/lit8 v5, v4, 0x14

    aput p19, p2, v5

    add-int/lit8 v5, v4, 0x15

    aput p20, p2, v5

    add-int/lit8 v5, v4, 0x16

    aput p21, p2, v5

    add-int/lit8 v5, v4, 0x17

    aput p18, p2, v5

    .line 293
    add-int/lit8 v2, v2, 0x6

    iput v2, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 294
    return-void
.end method

.method private drawLetterT([F[FFFFI)V
    .locals 13
    .param p1, "v"    # [F
    .param p2, "c"    # [F
    .param p3, "x"    # F
    .param p4, "y"    # F
    .param p5, "z"    # F
    .param p6, "s"    # I

    .line 298
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p6

    iget v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    array-length v4, v1

    const/4 v5, 0x3

    div-int/2addr v4, v5

    add-int/lit8 v4, v4, -0xc

    if-lt v3, v4, :cond_0

    return-void

    .line 299
    :cond_0
    const v4, 0x3c23d70a    # 0.01f

    .line 300
    .local v4, "e":F
    mul-int/lit8 v6, v3, 0x3

    .line 301
    .local v6, "vc":I
    const v7, 0x3e4ccccd    # 0.2f

    const v8, 0x3f266666    # 0.65f

    const v9, 0x3f4ccccd    # 0.8f

    const/4 v10, 0x4

    const/high16 v11, 0x3f800000    # 1.0f

    const/4 v12, 0x0

    if-ne v2, v10, :cond_1

    .line 302
    add-float v5, p3, v9

    aput v5, v1, v6

    add-int/lit8 v5, v6, 0x1

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x2

    sub-float v10, p5, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x3

    add-float v10, p3, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x4

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x5

    sub-float v10, p5, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x6

    add-float v10, p3, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x7

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x8

    sub-float v10, p5, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x9

    add-float v10, p3, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xa

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xb

    sub-float v10, p5, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xc

    add-float v10, p3, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xd

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xe

    sub-float v10, p5, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xf

    add-float v10, p3, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x10

    add-float v9, p4, v9

    aput v9, v1, v5

    add-int/lit8 v5, v6, 0x11

    sub-float v9, p5, v4

    aput v9, v1, v5

    .line 303
    mul-int/lit8 v5, v3, 0x4

    .line 304
    .local v5, "cc":I
    aput v12, p2, v5

    add-int/lit8 v9, v5, 0x1

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x2

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x3

    aput v11, p2, v9

    .line 305
    add-int/lit8 v9, v5, 0x4

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x5

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x6

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x7

    aput v11, p2, v9

    .line 306
    add-int/lit8 v9, v5, 0x8

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x9

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xa

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xb

    aput v11, p2, v9

    .line 307
    add-int/lit8 v9, v5, 0xc

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xd

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xe

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xf

    aput v11, p2, v9

    .line 308
    add-int/lit8 v9, v5, 0x10

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x11

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x12

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x13

    aput v11, p2, v9

    .line 309
    add-int/lit8 v9, v5, 0x14

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x15

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x16

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x17

    aput v11, p2, v9

    .line 310
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    mul-int/lit8 v6, v3, 0x3

    .line 311
    const v9, 0x3f19999a    # 0.6f

    add-float v9, p3, v9

    aput v9, v1, v6

    add-int/lit8 v9, v6, 0x1

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x2

    sub-float v10, p5, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x3

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x4

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x5

    sub-float v10, p5, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x6

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x7

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x8

    sub-float v10, p5, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x9

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xa

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xb

    sub-float v10, p5, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xc

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xd

    add-float v7, p4, v7

    aput v7, v1, v9

    add-int/lit8 v7, v6, 0xe

    sub-float v9, p5, v4

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0xf

    const v9, 0x3ecccccd    # 0.4f

    add-float v9, p3, v9

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0x10

    add-float v8, p4, v8

    aput v8, v1, v7

    add-int/lit8 v7, v6, 0x11

    sub-float v8, p5, v4

    aput v8, v1, v7

    .line 312
    mul-int/lit8 v5, v3, 0x4

    .line 313
    aput v12, p2, v5

    add-int/lit8 v7, v5, 0x1

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x2

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x3

    aput v11, p2, v7

    .line 314
    add-int/lit8 v7, v5, 0x4

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x5

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x6

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x7

    aput v11, p2, v7

    .line 315
    add-int/lit8 v7, v5, 0x8

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x9

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xa

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xb

    aput v11, p2, v7

    .line 316
    add-int/lit8 v7, v5, 0xc

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xd

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xe

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xf

    aput v11, p2, v7

    .line 317
    add-int/lit8 v7, v5, 0x10

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x11

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x12

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x13

    aput v11, p2, v7

    .line 318
    add-int/lit8 v7, v5, 0x14

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x15

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x16

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x17

    aput v11, p2, v7

    .line 319
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 320
    .end local v5    # "cc":I
    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x5

    if-ne v2, v10, :cond_2

    .line 321
    add-float v5, p3, v7

    aput v5, v1, v6

    add-int/lit8 v5, v6, 0x1

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x2

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x3

    add-float v10, p3, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x4

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x5

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x6

    add-float v10, p3, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x7

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x8

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x9

    add-float v10, p3, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xa

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xb

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xc

    add-float v10, p3, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xd

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xe

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xf

    add-float v10, p3, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x10

    add-float v9, p4, v9

    aput v9, v1, v5

    add-int/lit8 v5, v6, 0x11

    add-float v9, p5, v11

    add-float/2addr v9, v4

    aput v9, v1, v5

    .line 322
    mul-int/lit8 v5, v3, 0x4

    .line 323
    .restart local v5    # "cc":I
    aput v12, p2, v5

    add-int/lit8 v9, v5, 0x1

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x2

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x3

    aput v11, p2, v9

    .line 324
    add-int/lit8 v9, v5, 0x4

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x5

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x6

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x7

    aput v11, p2, v9

    .line 325
    add-int/lit8 v9, v5, 0x8

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x9

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xa

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xb

    aput v11, p2, v9

    .line 326
    add-int/lit8 v9, v5, 0xc

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xd

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xe

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xf

    aput v11, p2, v9

    .line 327
    add-int/lit8 v9, v5, 0x10

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x11

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x12

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x13

    aput v11, p2, v9

    .line 328
    add-int/lit8 v9, v5, 0x14

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x15

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x16

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x17

    aput v11, p2, v9

    .line 329
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    mul-int/lit8 v6, v3, 0x3

    .line 330
    const v9, 0x3ecccccd    # 0.4f

    add-float v9, p3, v9

    aput v9, v1, v6

    add-int/lit8 v9, v6, 0x1

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x2

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x3

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x4

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x5

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x6

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x7

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x8

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x9

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xa

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xb

    add-float v10, p5, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xc

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p3, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xd

    add-float v7, p4, v7

    aput v7, v1, v9

    add-int/lit8 v7, v6, 0xe

    add-float v9, p5, v11

    add-float/2addr v9, v4

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0xf

    const v9, 0x3f19999a    # 0.6f

    add-float v9, p3, v9

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0x10

    add-float v8, p4, v8

    aput v8, v1, v7

    add-int/lit8 v7, v6, 0x11

    add-float v8, p5, v11

    add-float/2addr v8, v4

    aput v8, v1, v7

    .line 331
    mul-int/lit8 v5, v3, 0x4

    .line 332
    aput v12, p2, v5

    add-int/lit8 v7, v5, 0x1

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x2

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x3

    aput v11, p2, v7

    .line 333
    add-int/lit8 v7, v5, 0x4

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x5

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x6

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x7

    aput v11, p2, v7

    .line 334
    add-int/lit8 v7, v5, 0x8

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x9

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xa

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xb

    aput v11, p2, v7

    .line 335
    add-int/lit8 v7, v5, 0xc

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xd

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xe

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xf

    aput v11, p2, v7

    .line 336
    add-int/lit8 v7, v5, 0x10

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x11

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x12

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x13

    aput v11, p2, v7

    .line 337
    add-int/lit8 v7, v5, 0x14

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x15

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x16

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x17

    aput v11, p2, v7

    .line 338
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 339
    .end local v5    # "cc":I
    goto/16 :goto_0

    :cond_2
    const/4 v10, 0x2

    if-ne v2, v10, :cond_4

    .line 340
    sub-float v5, p3, v4

    aput v5, v1, v6

    add-int/lit8 v5, v6, 0x1

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x2

    add-float v10, p5, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x3

    sub-float v10, p3, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x4

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x5

    add-float v10, p5, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x6

    sub-float v10, p3, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x7

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x8

    add-float v10, p5, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x9

    sub-float v10, p3, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xa

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xb

    add-float v10, p5, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xc

    sub-float v10, p3, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xd

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xe

    add-float v10, p5, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xf

    sub-float v10, p3, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x10

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x11

    add-float v9, p5, v9

    aput v9, v1, v5

    .line 341
    mul-int/lit8 v5, v3, 0x4

    .line 342
    .restart local v5    # "cc":I
    aput v12, p2, v5

    add-int/lit8 v9, v5, 0x1

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x2

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x3

    aput v11, p2, v9

    .line 343
    add-int/lit8 v9, v5, 0x4

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x5

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x6

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x7

    aput v11, p2, v9

    .line 344
    add-int/lit8 v9, v5, 0x8

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x9

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xa

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xb

    aput v11, p2, v9

    .line 345
    add-int/lit8 v9, v5, 0xc

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xd

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xe

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xf

    aput v11, p2, v9

    .line 346
    add-int/lit8 v9, v5, 0x10

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x11

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x12

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x13

    aput v11, p2, v9

    .line 347
    add-int/lit8 v9, v5, 0x14

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x15

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x16

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x17

    aput v11, p2, v9

    .line 348
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    mul-int/lit8 v6, v3, 0x3

    .line 349
    sub-float v9, p3, v4

    aput v9, v1, v6

    add-int/lit8 v9, v6, 0x1

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x2

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x3

    sub-float v10, p3, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x4

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x5

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x6

    sub-float v10, p3, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x7

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x8

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x9

    sub-float v10, p3, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xa

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xb

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xc

    sub-float v10, p3, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xd

    add-float v7, p4, v7

    aput v7, v1, v9

    add-int/lit8 v7, v6, 0xe

    const v9, 0x3f19999a    # 0.6f

    add-float v9, p5, v9

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0xf

    sub-float v9, p3, v4

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0x10

    add-float v8, p4, v8

    aput v8, v1, v7

    add-int/lit8 v7, v6, 0x11

    const v8, 0x3f19999a    # 0.6f

    add-float v8, p5, v8

    aput v8, v1, v7

    .line 350
    mul-int/lit8 v5, v3, 0x4

    .line 351
    aput v12, p2, v5

    add-int/lit8 v7, v5, 0x1

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x2

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x3

    aput v11, p2, v7

    .line 352
    add-int/lit8 v7, v5, 0x4

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x5

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x6

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x7

    aput v11, p2, v7

    .line 353
    add-int/lit8 v7, v5, 0x8

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x9

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xa

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xb

    aput v11, p2, v7

    .line 354
    add-int/lit8 v7, v5, 0xc

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xd

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xe

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xf

    aput v11, p2, v7

    .line 355
    add-int/lit8 v7, v5, 0x10

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x11

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x12

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x13

    aput v11, p2, v7

    .line 356
    add-int/lit8 v7, v5, 0x14

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x15

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x16

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x17

    aput v11, p2, v7

    .line 357
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 358
    .end local v5    # "cc":I
    :cond_3
    goto/16 :goto_0

    :cond_4
    if-ne v2, v5, :cond_3

    .line 359
    add-float v5, p3, v11

    add-float/2addr v5, v4

    aput v5, v1, v6

    add-int/lit8 v5, v6, 0x1

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x2

    add-float v10, p5, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x3

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x4

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x5

    add-float v10, p5, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x6

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x7

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x8

    add-float v10, p5, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x9

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xa

    add-float v10, p4, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xb

    add-float v10, p5, v9

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xc

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xd

    add-float v10, p4, v8

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xe

    add-float v10, p5, v7

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0xf

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v5

    add-int/lit8 v5, v6, 0x10

    add-float v9, p4, v9

    aput v9, v1, v5

    add-int/lit8 v5, v6, 0x11

    add-float v9, p5, v7

    aput v9, v1, v5

    .line 360
    mul-int/lit8 v5, v3, 0x4

    .line 361
    .restart local v5    # "cc":I
    aput v12, p2, v5

    add-int/lit8 v9, v5, 0x1

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x2

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x3

    aput v11, p2, v9

    .line 362
    add-int/lit8 v9, v5, 0x4

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x5

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x6

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x7

    aput v11, p2, v9

    .line 363
    add-int/lit8 v9, v5, 0x8

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x9

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xa

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xb

    aput v11, p2, v9

    .line 364
    add-int/lit8 v9, v5, 0xc

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xd

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xe

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0xf

    aput v11, p2, v9

    .line 365
    add-int/lit8 v9, v5, 0x10

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x11

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x12

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x13

    aput v11, p2, v9

    .line 366
    add-int/lit8 v9, v5, 0x14

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x15

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x16

    aput v12, p2, v9

    add-int/lit8 v9, v5, 0x17

    aput v11, p2, v9

    .line 367
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    mul-int/lit8 v6, v3, 0x3

    .line 368
    add-float v9, p3, v11

    add-float/2addr v9, v4

    aput v9, v1, v6

    add-int/lit8 v9, v6, 0x1

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x2

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x3

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x4

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x5

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x6

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x7

    add-float v10, p4, v7

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x8

    const v10, 0x3ecccccd    # 0.4f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0x9

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xa

    add-float v10, p4, v8

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xb

    const v10, 0x3f19999a    # 0.6f

    add-float v10, p5, v10

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xc

    add-float v10, p3, v11

    add-float/2addr v10, v4

    aput v10, v1, v9

    add-int/lit8 v9, v6, 0xd

    add-float v7, p4, v7

    aput v7, v1, v9

    add-int/lit8 v7, v6, 0xe

    const v9, 0x3ecccccd    # 0.4f

    add-float v9, p5, v9

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0xf

    add-float v9, p3, v11

    add-float/2addr v9, v4

    aput v9, v1, v7

    add-int/lit8 v7, v6, 0x10

    add-float v8, p4, v8

    aput v8, v1, v7

    add-int/lit8 v7, v6, 0x11

    const v8, 0x3ecccccd    # 0.4f

    add-float v8, p5, v8

    aput v8, v1, v7

    .line 369
    mul-int/lit8 v5, v3, 0x4

    .line 370
    aput v12, p2, v5

    add-int/lit8 v7, v5, 0x1

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x2

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x3

    aput v11, p2, v7

    .line 371
    add-int/lit8 v7, v5, 0x4

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x5

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x6

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x7

    aput v11, p2, v7

    .line 372
    add-int/lit8 v7, v5, 0x8

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x9

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xa

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xb

    aput v11, p2, v7

    .line 373
    add-int/lit8 v7, v5, 0xc

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xd

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xe

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0xf

    aput v11, p2, v7

    .line 374
    add-int/lit8 v7, v5, 0x10

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x11

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x12

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x13

    aput v11, p2, v7

    .line 375
    add-int/lit8 v7, v5, 0x14

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x15

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x16

    aput v12, p2, v7

    add-int/lit8 v7, v5, 0x17

    aput v11, p2, v7

    .line 376
    add-int/lit8 v3, v3, 0x6

    iput v3, v0, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 378
    .end local v5    # "cc":I
    :goto_0
    return-void
.end method

.method private generateTerrain()V
    .locals 27

    .line 43
    move-object/from16 v0, p0

    const/4 v1, 0x0

    .local v1, "x":I
    :goto_0
    const/16 v2, 0x10

    if-ge v1, v2, :cond_10

    .line 44
    const/4 v3, 0x0

    .local v3, "z":I
    :goto_1
    if-ge v3, v2, :cond_f

    .line 45
    iget v4, v0, Lcom/EZdev/mc2/Chunk;->chunkX:I

    mul-int/2addr v4, v2

    add-int/2addr v4, v1

    .local v4, "gx":I
    iget v5, v0, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    mul-int/2addr v5, v2

    add-int/2addr v5, v3

    .line 47
    .local v5, "gz":I
    int-to-float v6, v4

    const v7, 0x3ba3d70a    # 0.005f

    mul-float/2addr v6, v7

    int-to-float v8, v5

    mul-float/2addr v8, v7

    const/4 v9, 0x4

    invoke-static {v6, v8, v9}, Lcom/EZdev/mc2/Noise;->fbm2(FFI)F

    move-result v6

    .line 49
    .local v6, "noiseVal":F
    const/high16 v8, 0x41f00000    # 30.0f

    mul-float/2addr v8, v6

    float-to-int v8, v8

    add-int/lit8 v8, v8, 0x46

    .line 51
    .local v8, "height":I
    const/4 v9, 0x0

    .local v9, "y":I
    :goto_2
    const/16 v11, 0xa

    const/4 v12, 0x1

    if-gt v9, v8, :cond_c

    .line 52
    const/16 v13, 0x9

    if-nez v9, :cond_0

    iget-object v10, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v10, v10, v1

    aget-object v10, v10, v9

    aput-byte v13, v10, v3

    move/from16 v20, v4

    move/from16 v19, v6

    goto/16 :goto_8

    .line 53
    :cond_0
    const/4 v14, 0x2

    if-gt v9, v14, :cond_1

    iget-object v15, v0, Lcom/EZdev/mc2/Chunk;->random:Ljava/util/Random;

    invoke-virtual {v15}, Ljava/util/Random;->nextDouble()D

    move-result-wide v15

    const-wide/high16 v17, 0x3fe0000000000000L    # 0.5

    cmpg-double v15, v15, v17

    if-gez v15, :cond_1

    iget-object v10, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v10, v10, v1

    aget-object v10, v10, v9

    aput-byte v13, v10, v3

    move/from16 v20, v4

    move/from16 v19, v6

    goto/16 :goto_8

    .line 56
    :cond_1
    if-ne v9, v8, :cond_2

    iget-object v11, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v11, v11, v1

    aget-object v11, v11, v9

    aput-byte v12, v11, v3

    goto :goto_3

    .line 57
    :cond_2
    add-int/lit8 v13, v8, -0x4

    if-le v9, v13, :cond_3

    iget-object v13, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v13, v13, v1

    aget-object v13, v13, v9

    aput-byte v11, v13, v3

    goto :goto_3

    .line 58
    :cond_3
    iget-object v11, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v11, v11, v1

    aget-object v11, v11, v9

    aput-byte v14, v11, v3

    .line 59
    :goto_3
    const/16 v11, 0x14

    if-ge v9, v11, :cond_4

    iget-object v11, v0, Lcom/EZdev/mc2/Chunk;->random:Ljava/util/Random;

    invoke-virtual {v11}, Ljava/util/Random;->nextFloat()F

    move-result v11

    cmpg-float v11, v11, v7

    if-gez v11, :cond_4

    iget-object v11, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v11, v11, v1

    aget-object v11, v11, v9

    const/4 v13, 0x5

    aput-byte v13, v11, v3

    .line 62
    :cond_4
    add-int/lit8 v11, v8, -0x5

    if-ge v9, v11, :cond_a

    if-le v9, v14, :cond_a

    .line 63
    int-to-float v11, v4

    const v13, 0x3c75c28f    # 0.015f

    mul-float/2addr v11, v13

    .line 64
    .local v11, "caveX":F
    int-to-float v15, v9

    mul-float/2addr v15, v13

    .line 65
    .local v15, "caveY":F
    int-to-float v2, v5

    mul-float/2addr v2, v13

    .line 68
    .local v2, "caveZ":F
    invoke-static {v11, v15, v2, v14}, Lcom/EZdev/mc2/Noise;->fbm3(FFFI)F

    move-result v13

    .line 69
    .local v13, "cheeseNoise":F
    const v17, 0x3ee66666    # 0.45f

    cmpl-float v17, v13, v17

    const/16 v18, 0x0

    if-lez v17, :cond_5

    move/from16 v17, v12

    goto :goto_4

    :cond_5
    move/from16 v17, v18

    .line 73
    .local v17, "isCheese":Z
    :goto_4
    const/high16 v19, 0x3fc00000    # 1.5f

    mul-float v10, v11, v19

    mul-float v7, v15, v19

    mul-float v12, v2, v19

    invoke-static {v10, v7, v12, v14}, Lcom/EZdev/mc2/Noise;->fbm3(FFFI)F

    move-result v7

    .line 74
    .local v7, "spaghetti1":F
    mul-float v10, v11, v19

    const/high16 v12, 0x42c80000    # 100.0f

    add-float/2addr v10, v12

    mul-float v22, v15, v19

    add-float v14, v22, v12

    mul-float v19, v19, v2

    add-float v12, v19, v12

    move/from16 v19, v6

    const/4 v6, 0x2

    .end local v6    # "noiseVal":F
    .local v19, "noiseVal":F
    invoke-static {v10, v14, v12, v6}, Lcom/EZdev/mc2/Noise;->fbm3(FFFI)F

    move-result v10

    .line 75
    .local v10, "spaghetti2":F
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v6

    const v12, 0x3d75c28f    # 0.06f

    cmpg-float v6, v6, v12

    if-gez v6, :cond_6

    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    move-result v6

    cmpg-float v6, v6, v12

    if-gez v6, :cond_6

    const/4 v6, 0x1

    goto :goto_5

    :cond_6
    move/from16 v6, v18

    .line 78
    .local v6, "isSpaghetti":Z
    :goto_5
    const/high16 v12, 0x40400000    # 3.0f

    mul-float v14, v11, v12

    move/from16 v22, v7

    .end local v7    # "spaghetti1":F
    .local v22, "spaghetti1":F
    mul-float v7, v15, v12

    move/from16 v23, v10

    .end local v10    # "spaghetti2":F
    .local v23, "spaghetti2":F
    mul-float v10, v2, v12

    const/4 v12, 0x1

    invoke-static {v14, v7, v10, v12}, Lcom/EZdev/mc2/Noise;->fbm3(FFFI)F

    move-result v7

    .line 79
    .local v7, "noodle1":F
    const/high16 v10, 0x40400000    # 3.0f

    mul-float v14, v11, v10

    const/high16 v21, 0x42480000    # 50.0f

    add-float v14, v14, v21

    mul-float v24, v15, v10

    add-float v12, v24, v21

    mul-float/2addr v10, v2

    add-float v10, v10, v21

    move/from16 v24, v2

    const/4 v2, 0x1

    .end local v2    # "caveZ":F
    .local v24, "caveZ":F
    invoke-static {v14, v12, v10, v2}, Lcom/EZdev/mc2/Noise;->fbm3(FFFI)F

    move-result v10

    .line 80
    .local v10, "noodle2":F
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const v12, 0x3d23d70a    # 0.04f

    cmpg-float v2, v2, v12

    if-gez v2, :cond_7

    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    move-result v2

    cmpg-float v2, v2, v12

    if-gez v2, :cond_7

    const/4 v12, 0x1

    goto :goto_6

    :cond_7
    move/from16 v12, v18

    :goto_6
    move v2, v12

    .line 84
    .local v2, "isNoodle":Z
    int-to-float v12, v4

    const v14, 0x3c23d70a    # 0.01f

    mul-float/2addr v12, v14

    int-to-float v14, v9

    const v26, 0x3b03126f    # 0.002f

    mul-float v14, v14, v26

    move/from16 v26, v7

    .end local v7    # "noodle1":F
    .local v26, "noodle1":F
    int-to-float v7, v5

    const v25, 0x3c23d70a    # 0.01f

    mul-float v7, v7, v25

    move/from16 v25, v10

    const/4 v10, 0x2

    .end local v10    # "noodle2":F
    .local v25, "noodle2":F
    invoke-static {v12, v14, v7, v10}, Lcom/EZdev/mc2/Noise;->fbm3(FFFI)F

    move-result v7

    .line 86
    .local v7, "ravineNoise":F
    int-to-float v10, v4

    const v12, 0x3ba3d70a    # 0.005f

    mul-float/2addr v10, v12

    const/high16 v14, 0x447a0000    # 1000.0f

    add-float/2addr v10, v14

    move/from16 v20, v4

    .end local v4    # "gx":I
    .local v20, "gx":I
    int-to-float v4, v5

    mul-float/2addr v4, v12

    add-float/2addr v4, v14

    invoke-static {v10, v4}, Lcom/EZdev/mc2/Noise;->simplex2(FF)F

    move-result v4

    .line 87
    .local v4, "ravineMask":F
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v10

    const v14, 0x3d4ccccd    # 0.05f

    cmpg-float v10, v10, v14

    if-gez v10, :cond_8

    const v10, 0x3e99999a    # 0.3f

    cmpl-float v10, v4, v10

    if-lez v10, :cond_8

    const/16 v21, 0x1

    goto :goto_7

    :cond_8
    move/from16 v21, v18

    :goto_7
    move/from16 v10, v21

    .line 89
    .local v10, "isRavine":Z
    if-nez v17, :cond_9

    if-nez v6, :cond_9

    if-nez v2, :cond_9

    if-eqz v10, :cond_b

    .line 90
    :cond_9
    iget-object v14, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v14, v14, v1

    aget-object v14, v14, v9

    aput-byte v18, v14, v3

    .line 93
    const/16 v12, 0xc

    if-ge v9, v12, :cond_b

    const/4 v12, 0x7

    aput-byte v12, v14, v3

    goto :goto_8

    .line 62
    .end local v2    # "isNoodle":Z
    .end local v7    # "ravineNoise":F
    .end local v10    # "isRavine":Z
    .end local v11    # "caveX":F
    .end local v13    # "cheeseNoise":F
    .end local v15    # "caveY":F
    .end local v17    # "isCheese":Z
    .end local v19    # "noiseVal":F
    .end local v20    # "gx":I
    .end local v22    # "spaghetti1":F
    .end local v23    # "spaghetti2":F
    .end local v24    # "caveZ":F
    .end local v25    # "noodle2":F
    .end local v26    # "noodle1":F
    .local v4, "gx":I
    .local v6, "noiseVal":F
    :cond_a
    move/from16 v20, v4

    move/from16 v19, v6

    .line 51
    .end local v4    # "gx":I
    .end local v6    # "noiseVal":F
    .restart local v19    # "noiseVal":F
    .restart local v20    # "gx":I
    :cond_b
    :goto_8
    add-int/lit8 v9, v9, 0x1

    move/from16 v6, v19

    move/from16 v4, v20

    const/16 v2, 0x10

    const v7, 0x3ba3d70a    # 0.005f

    goto/16 :goto_2

    .end local v19    # "noiseVal":F
    .end local v20    # "gx":I
    .restart local v4    # "gx":I
    .restart local v6    # "noiseVal":F
    :cond_c
    move/from16 v20, v4

    move/from16 v19, v6

    .line 99
    .end local v4    # "gx":I
    .end local v6    # "noiseVal":F
    .end local v9    # "y":I
    .restart local v19    # "noiseVal":F
    .restart local v20    # "gx":I
    const/16 v2, 0x3c

    .local v2, "y":I
    :goto_9
    if-le v2, v8, :cond_d

    .line 100
    iget-object v4, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v4, v4, v1

    aget-object v4, v4, v2

    const/4 v6, 0x7

    aput-byte v6, v4, v3

    .line 99
    add-int/lit8 v2, v2, -0x1

    goto :goto_9

    :cond_d
    nop

    .line 103
    .end local v2    # "y":I
    const/16 v2, 0x3c

    if-ge v8, v2, :cond_e

    iget-object v2, v0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v2, v2, v1

    aget-object v2, v2, v8

    aget-byte v4, v2, v3

    const/4 v6, 0x1

    if-ne v4, v6, :cond_e

    .line 104
    aput-byte v11, v2, v3

    .line 44
    .end local v5    # "gz":I
    .end local v8    # "height":I
    .end local v19    # "noiseVal":F
    .end local v20    # "gx":I
    :cond_e
    add-int/lit8 v3, v3, 0x1

    const/16 v2, 0x10

    goto/16 :goto_1

    :cond_f
    nop

    .line 43
    .end local v3    # "z":I
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_10
    nop

    .line 108
    .end local v1    # "x":I
    return-void
.end method

.method private getBlockWorldAware(III)B
    .locals 4
    .param p1, "lx"    # I
    .param p2, "ly"    # I
    .param p3, "lz"    # I

    .line 129
    if-ltz p2, :cond_0

    const/16 v0, 0x80

    if-lt p2, v0, :cond_1

    :cond_0
    goto :goto_0

    .line 130
    :cond_1
    const/16 v0, 0x10

    if-ltz p1, :cond_2

    if-ge p1, v0, :cond_2

    if-ltz p3, :cond_2

    if-ge p3, v0, :cond_2

    iget-object v0, p0, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v0, v0, p1

    aget-object v0, v0, p2

    aget-byte v0, v0, p3

    return v0

    .line 131
    :cond_2
    iget-object v1, p0, Lcom/EZdev/mc2/Chunk;->world:Lcom/EZdev/mc2/WorldLogic;

    iget v2, p0, Lcom/EZdev/mc2/Chunk;->chunkX:I

    mul-int/2addr v2, v0

    add-int/2addr v2, p1

    iget v3, p0, Lcom/EZdev/mc2/Chunk;->chunkZ:I

    mul-int/2addr v3, v0

    add-int/2addr v3, p3

    invoke-virtual {v1, v2, p2, v3}, Lcom/EZdev/mc2/WorldLogic;->getBlock(III)B

    move-result v0

    return v0

    .line 129
    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method private isTransparent(IIIB)Z
    .locals 3
    .param p1, "x"    # I
    .param p2, "y"    # I
    .param p3, "z"    # I
    .param p4, "sourceBlockType"    # B

    .line 135
    invoke-direct {p0, p1, p2, p3}, Lcom/EZdev/mc2/Chunk;->getBlockWorldAware(III)B

    move-result v0

    .line 136
    .local v0, "b":B
    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    if-ne v0, v2, :cond_1

    :cond_0
    goto :goto_0

    .line 137
    :cond_1
    const/4 v2, 0x7

    if-eq p4, v2, :cond_2

    if-ne v0, v2, :cond_2

    return v1

    .line 138
    :cond_2
    const/4 v1, 0x0

    return v1

    .line 136
    :goto_0
    return v1
.end method


# virtual methods
.method public buildMesh()V
    .locals 34

    .line 142
    move-object/from16 v12, p0

    sget-object v13, Lcom/EZdev/mc2/Chunk;->meshLock:Ljava/lang/Object;

    monitor-enter v13

    .line 143
    const/4 v0, 0x0

    :try_start_0
    iput v0, v12, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    .line 145
    const/4 v1, 0x0

    move v14, v1

    .local v14, "x":I
    :goto_0
    const/16 v15, 0x10

    const/4 v11, 0x3

    const/4 v10, 0x4

    if-ge v14, v15, :cond_18

    .line 146
    const/4 v1, 0x0

    move v9, v1

    .local v9, "y":I
    :goto_1
    const/16 v1, 0x80

    if-ge v9, v1, :cond_17

    .line 147
    const/4 v1, 0x0

    move v8, v1

    .local v8, "z":I
    :goto_2
    if-ge v8, v15, :cond_16

    .line 148
    iget-object v1, v12, Lcom/EZdev/mc2/Chunk;->blocks:[[[B

    aget-object v1, v1, v14

    aget-object v2, v1, v9

    aget-byte v2, v2, v8

    move v7, v2

    .line 149
    .local v7, "type":B
    if-nez v7, :cond_0

    move v15, v9

    move/from16 v19, v10

    move/from16 v20, v11

    move v9, v14

    move v14, v8

    goto/16 :goto_b

    .line 151
    :cond_0
    const/high16 v2, 0x3f800000    # 1.0f

    .local v2, "r":F
    const/high16 v3, 0x3f800000    # 1.0f

    .local v3, "g":F
    const/high16 v4, 0x3f800000    # 1.0f

    .local v4, "b":F
    const/high16 v5, 0x3f800000    # 1.0f

    .line 152
    .local v5, "a":F
    const/4 v6, 0x7

    const/4 v15, 0x5

    const/4 v0, 0x1

    if-ne v7, v0, :cond_1

    const v2, 0x3e99999a    # 0.3f

    const v3, 0x3f333333    # 0.7f

    const v4, 0x3e4ccccd    # 0.2f

    move v0, v5

    goto/16 :goto_3

    .line 153
    :cond_1
    const/16 v0, 0xa

    if-ne v7, v0, :cond_2

    const v2, 0x3ecccccd    # 0.4f

    const/high16 v3, 0x3e800000    # 0.25f

    const v4, 0x3dcccccd    # 0.1f

    move v0, v5

    goto :goto_3

    .line 154
    :cond_2
    const/4 v0, 0x2

    if-ne v7, v0, :cond_3

    const v2, 0x3ecccccd    # 0.4f

    const v3, 0x3ecccccd    # 0.4f

    const v4, 0x3ecccccd    # 0.4f

    move v0, v5

    goto :goto_3

    .line 155
    :cond_3
    if-ne v7, v11, :cond_4

    const v2, 0x3ecccccd    # 0.4f

    const/high16 v3, 0x3e800000    # 0.25f

    const v4, 0x3dcccccd    # 0.1f

    move v0, v5

    goto :goto_3

    .line 156
    :cond_4
    if-ne v7, v10, :cond_5

    const v2, 0x3dcccccd    # 0.1f

    const/high16 v3, 0x3f000000    # 0.5f

    const v4, 0x3dcccccd    # 0.1f

    move v0, v5

    goto :goto_3

    .line 157
    :cond_5
    if-ne v7, v15, :cond_6

    const v2, 0x3f666666    # 0.9f

    const v3, 0x3e4ccccd    # 0.2f

    const v4, 0x3e4ccccd    # 0.2f

    move v0, v5

    goto :goto_3

    .line 158
    :cond_6
    if-ne v7, v6, :cond_7

    const v2, 0x3e4ccccd    # 0.2f

    const v3, 0x3ecccccd    # 0.4f

    const v4, 0x3f666666    # 0.9f

    const v5, 0x3f333333    # 0.7f

    move v0, v5

    goto :goto_3

    .line 159
    :cond_7
    const/16 v0, 0x9

    if-ne v7, v0, :cond_8

    const v2, 0x3dcccccd    # 0.1f

    const v3, 0x3dcccccd    # 0.1f

    const v4, 0x3dcccccd    # 0.1f

    :cond_8
    move v0, v5

    .line 161
    .end local v5    # "a":F
    .local v0, "a":F
    :goto_3
    const/4 v5, 0x1

    if-ne v7, v5, :cond_9

    const/16 v5, 0x7f

    if-ge v9, v5, :cond_9

    add-int/lit8 v5, v9, 0x1

    aget-object v5, v1, v5

    aget-byte v5, v5, v8

    if-eqz v5, :cond_9

    add-int/lit8 v5, v9, 0x1

    aget-object v1, v1, v5

    aget-byte v1, v1, v8

    if-eq v1, v6, :cond_9

    .line 162
    const v2, 0x3ecccccd    # 0.4f

    const/high16 v3, 0x3e800000    # 0.25f

    const v4, 0x3dcccccd    # 0.1f

    move/from16 v16, v2

    move/from16 v17, v3

    move/from16 v18, v4

    goto :goto_4

    .line 198
    .end local v0    # "a":F
    .end local v2    # "r":F
    .end local v3    # "g":F
    .end local v4    # "b":F
    .end local v7    # "type":B
    .end local v8    # "z":I
    .end local v9    # "y":I
    .end local v14    # "x":I
    :catchall_0
    move-exception v0

    goto/16 :goto_c

    .line 165
    .restart local v0    # "a":F
    .restart local v2    # "r":F
    .restart local v3    # "g":F
    .restart local v4    # "b":F
    .restart local v7    # "type":B
    .restart local v8    # "z":I
    .restart local v9    # "y":I
    .restart local v14    # "x":I
    :cond_9
    move/from16 v16, v2

    move/from16 v17, v3

    move/from16 v18, v4

    .end local v2    # "r":F
    .end local v3    # "g":F
    .end local v4    # "b":F
    .local v16, "r":F
    .local v17, "g":F
    .local v18, "b":F
    :goto_4
    const/4 v1, 0x6

    if-ne v7, v1, :cond_a

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v14

    int-to-float v5, v9

    int-to-float v6, v8

    const v15, 0x3f666666    # 0.9f

    const/high16 v19, 0x3f000000    # 0.5f

    const v20, 0x3dcccccd    # 0.1f

    move-object/from16 v1, p0

    move/from16 v21, v7

    .end local v7    # "type":B
    .local v21, "type":B
    move v7, v15

    move v15, v8

    .end local v8    # "z":I
    .local v15, "z":I
    move/from16 v8, v19

    move/from16 v19, v15

    move v15, v9

    .end local v9    # "y":I
    .local v15, "y":I
    .local v19, "z":I
    move/from16 v9, v20

    invoke-direct/range {v1 .. v9}, Lcom/EZdev/mc2/Chunk;->addFireCross([F[FFFFFFF)V

    move/from16 v20, v11

    move v9, v14

    move/from16 v14, v19

    move/from16 v19, v10

    goto/16 :goto_b

    .line 167
    .end local v15    # "y":I
    .end local v19    # "z":I
    .end local v21    # "type":B
    .restart local v7    # "type":B
    .restart local v8    # "z":I
    .restart local v9    # "y":I
    :cond_a
    move/from16 v21, v7

    move/from16 v33, v9

    move v9, v8

    move v8, v15

    move/from16 v15, v33

    .end local v7    # "type":B
    .end local v8    # "z":I
    .local v9, "z":I
    .restart local v15    # "y":I
    .restart local v21    # "type":B
    add-int/lit8 v1, v15, 0x1

    .end local v21    # "type":B
    .restart local v7    # "type":B
    invoke-direct {v12, v14, v1, v9, v7}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_b

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v14

    int-to-float v5, v15

    int-to-float v6, v9

    const/16 v19, 0x0

    move-object/from16 v1, p0

    move/from16 v22, v7

    .end local v7    # "type":B
    .local v22, "type":B
    move/from16 v7, v19

    move/from16 v8, v16

    move/from16 v23, v9

    .end local v9    # "z":I
    .local v23, "z":I
    move/from16 v9, v17

    move/from16 v19, v10

    move/from16 v10, v18

    move/from16 v20, v11

    move v11, v0

    invoke-direct/range {v1 .. v11}, Lcom/EZdev/mc2/Chunk;->addFace([F[FFFFIFFFF)V

    goto :goto_5

    .end local v22    # "type":B
    .end local v23    # "z":I
    .restart local v7    # "type":B
    .restart local v9    # "z":I
    :cond_b
    move/from16 v22, v7

    move/from16 v23, v9

    move/from16 v19, v10

    move/from16 v20, v11

    .line 168
    .end local v7    # "type":B
    .end local v9    # "z":I
    .restart local v22    # "type":B
    .restart local v23    # "z":I
    :goto_5
    add-int/lit8 v9, v15, -0x1

    move/from16 v10, v22

    move/from16 v11, v23

    .end local v22    # "type":B
    .end local v23    # "z":I
    .local v10, "type":B
    .local v11, "z":I
    invoke-direct {v12, v14, v9, v11, v10}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_c

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v14

    int-to-float v5, v15

    int-to-float v6, v11

    const/4 v7, 0x1

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float v8, v16, v1

    mul-float v9, v17, v1

    mul-float v21, v18, v1

    move-object/from16 v1, p0

    move/from16 v24, v10

    .end local v10    # "type":B
    .local v24, "type":B
    move/from16 v10, v21

    move/from16 v25, v11

    .end local v11    # "z":I
    .local v25, "z":I
    move v11, v0

    invoke-direct/range {v1 .. v11}, Lcom/EZdev/mc2/Chunk;->addFace([F[FFFFIFFFF)V

    goto :goto_6

    .end local v24    # "type":B
    .end local v25    # "z":I
    .restart local v10    # "type":B
    .restart local v11    # "z":I
    :cond_c
    move/from16 v24, v10

    move/from16 v25, v11

    .line 169
    .end local v10    # "type":B
    .end local v11    # "z":I
    .restart local v24    # "type":B
    .restart local v25    # "z":I
    :goto_6
    add-int/lit8 v1, v14, -0x1

    move/from16 v10, v24

    move/from16 v11, v25

    .end local v24    # "type":B
    .end local v25    # "z":I
    .restart local v10    # "type":B
    .restart local v11    # "z":I
    invoke-direct {v12, v1, v15, v11, v10}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    const v21, 0x3f4ccccd    # 0.8f

    if-eqz v1, :cond_d

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v14

    int-to-float v5, v15

    int-to-float v6, v11

    const/4 v7, 0x2

    mul-float v8, v16, v21

    mul-float v9, v17, v21

    mul-float v22, v18, v21

    move-object/from16 v1, p0

    move/from16 v26, v10

    .end local v10    # "type":B
    .local v26, "type":B
    move/from16 v10, v22

    move/from16 v27, v11

    .end local v11    # "z":I
    .local v27, "z":I
    move v11, v0

    invoke-direct/range {v1 .. v11}, Lcom/EZdev/mc2/Chunk;->addFace([F[FFFFIFFFF)V

    goto :goto_7

    .end local v26    # "type":B
    .end local v27    # "z":I
    .restart local v10    # "type":B
    .restart local v11    # "z":I
    :cond_d
    move/from16 v26, v10

    move/from16 v27, v11

    .line 170
    .end local v10    # "type":B
    .end local v11    # "z":I
    .restart local v26    # "type":B
    .restart local v27    # "z":I
    :goto_7
    add-int/lit8 v1, v14, 0x1

    move/from16 v10, v26

    move/from16 v11, v27

    .end local v26    # "type":B
    .end local v27    # "z":I
    .restart local v10    # "type":B
    .restart local v11    # "z":I
    invoke-direct {v12, v1, v15, v11, v10}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_e

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v14

    int-to-float v5, v15

    int-to-float v6, v11

    const/4 v7, 0x3

    mul-float v8, v16, v21

    mul-float v9, v17, v21

    mul-float v21, v21, v18

    move-object/from16 v1, p0

    move/from16 v28, v10

    .end local v10    # "type":B
    .local v28, "type":B
    move/from16 v10, v21

    move/from16 v21, v14

    move v14, v11

    .end local v11    # "z":I
    .local v14, "z":I
    .local v21, "x":I
    move v11, v0

    invoke-direct/range {v1 .. v11}, Lcom/EZdev/mc2/Chunk;->addFace([F[FFFFIFFFF)V

    goto :goto_8

    .end local v21    # "x":I
    .end local v28    # "type":B
    .restart local v10    # "type":B
    .restart local v11    # "z":I
    .local v14, "x":I
    :cond_e
    move/from16 v28, v10

    move/from16 v21, v14

    move v14, v11

    .line 171
    .end local v10    # "type":B
    .end local v11    # "z":I
    .local v14, "z":I
    .restart local v21    # "x":I
    .restart local v28    # "type":B
    :goto_8
    add-int/lit8 v8, v14, -0x1

    move/from16 v11, v21

    move/from16 v10, v28

    .end local v21    # "x":I
    .end local v28    # "type":B
    .restart local v10    # "type":B
    .local v11, "x":I
    invoke-direct {v12, v11, v15, v8, v10}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    const v21, 0x3f666666    # 0.9f

    if-eqz v1, :cond_f

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v11

    int-to-float v5, v15

    int-to-float v6, v14

    const/4 v7, 0x4

    mul-float v8, v16, v21

    mul-float v9, v17, v21

    mul-float v22, v18, v21

    move-object/from16 v1, p0

    move/from16 v29, v10

    .end local v10    # "type":B
    .local v29, "type":B
    move/from16 v10, v22

    move/from16 v30, v11

    .end local v11    # "x":I
    .local v30, "x":I
    move v11, v0

    invoke-direct/range {v1 .. v11}, Lcom/EZdev/mc2/Chunk;->addFace([F[FFFFIFFFF)V

    goto :goto_9

    .end local v29    # "type":B
    .end local v30    # "x":I
    .restart local v10    # "type":B
    .restart local v11    # "x":I
    :cond_f
    move/from16 v29, v10

    move/from16 v30, v11

    .line 172
    .end local v10    # "type":B
    .end local v11    # "x":I
    .restart local v29    # "type":B
    .restart local v30    # "x":I
    :goto_9
    add-int/lit8 v8, v14, 0x1

    move/from16 v10, v29

    move/from16 v11, v30

    .end local v29    # "type":B
    .end local v30    # "x":I
    .restart local v10    # "type":B
    .restart local v11    # "x":I
    invoke-direct {v12, v11, v15, v8, v10}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_10

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v11

    int-to-float v5, v15

    int-to-float v6, v14

    const/4 v7, 0x5

    mul-float v8, v16, v21

    mul-float v9, v17, v21

    mul-float v21, v21, v18

    move-object/from16 v1, p0

    move/from16 v31, v10

    .end local v10    # "type":B
    .local v31, "type":B
    move/from16 v10, v21

    move/from16 v32, v11

    .end local v11    # "x":I
    .local v32, "x":I
    move v11, v0

    invoke-direct/range {v1 .. v11}, Lcom/EZdev/mc2/Chunk;->addFace([F[FFFFIFFFF)V

    goto :goto_a

    .end local v31    # "type":B
    .end local v32    # "x":I
    .restart local v10    # "type":B
    .restart local v11    # "x":I
    :cond_10
    move/from16 v31, v10

    move/from16 v32, v11

    .line 174
    .end local v10    # "type":B
    .end local v11    # "x":I
    .restart local v31    # "type":B
    .restart local v32    # "x":I
    :goto_a
    move/from16 v8, v31

    const/4 v1, 0x5

    .end local v31    # "type":B
    .local v8, "type":B
    if-ne v8, v1, :cond_14

    .line 175
    add-int/lit8 v1, v14, -0x1

    move/from16 v9, v32

    .end local v32    # "x":I
    .local v9, "x":I
    invoke-direct {v12, v9, v15, v1, v8}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_11

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v9

    int-to-float v5, v15

    int-to-float v6, v14

    const/4 v7, 0x4

    move-object/from16 v1, p0

    invoke-direct/range {v1 .. v7}, Lcom/EZdev/mc2/Chunk;->drawLetterT([F[FFFFI)V

    .line 176
    :cond_11
    add-int/lit8 v1, v14, 0x1

    invoke-direct {v12, v9, v15, v1, v8}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_12

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v9

    int-to-float v5, v15

    int-to-float v6, v14

    const/4 v7, 0x5

    move-object/from16 v1, p0

    invoke-direct/range {v1 .. v7}, Lcom/EZdev/mc2/Chunk;->drawLetterT([F[FFFFI)V

    .line 177
    :cond_12
    add-int/lit8 v1, v9, -0x1

    invoke-direct {v12, v1, v15, v14, v8}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_13

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v9

    int-to-float v5, v15

    int-to-float v6, v14

    const/4 v7, 0x2

    move-object/from16 v1, p0

    invoke-direct/range {v1 .. v7}, Lcom/EZdev/mc2/Chunk;->drawLetterT([F[FFFFI)V

    .line 178
    :cond_13
    add-int/lit8 v1, v9, 0x1

    invoke-direct {v12, v1, v15, v14, v8}, Lcom/EZdev/mc2/Chunk;->isTransparent(IIIB)Z

    move-result v1

    if-eqz v1, :cond_15

    sget-object v2, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    sget-object v3, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    int-to-float v4, v9

    int-to-float v5, v15

    int-to-float v6, v14

    const/4 v7, 0x3

    move-object/from16 v1, p0

    invoke-direct/range {v1 .. v7}, Lcom/EZdev/mc2/Chunk;->drawLetterT([F[FFFFI)V

    goto :goto_b

    .line 174
    .end local v9    # "x":I
    .restart local v32    # "x":I
    :cond_14
    move/from16 v9, v32

    .line 147
    .end local v0    # "a":F
    .end local v8    # "type":B
    .end local v16    # "r":F
    .end local v17    # "g":F
    .end local v18    # "b":F
    .end local v32    # "x":I
    .restart local v9    # "x":I
    :cond_15
    :goto_b
    add-int/lit8 v8, v14, 0x1

    move v14, v9

    move v9, v15

    move/from16 v10, v19

    move/from16 v11, v20

    const/4 v0, 0x0

    const/16 v15, 0x10

    .end local v14    # "z":I
    .local v8, "z":I
    goto/16 :goto_2

    .end local v15    # "y":I
    .local v9, "y":I
    .local v14, "x":I
    :cond_16
    move v15, v9

    move/from16 v19, v10

    move/from16 v20, v11

    move v9, v14

    move v14, v8

    .line 146
    .end local v8    # "z":I
    .end local v14    # "x":I
    .local v9, "x":I
    .restart local v15    # "y":I
    add-int/lit8 v0, v15, 0x1

    move v14, v9

    const/16 v15, 0x10

    move v9, v0

    const/4 v0, 0x0

    .end local v15    # "y":I
    .local v0, "y":I
    goto/16 :goto_1

    .end local v0    # "y":I
    .local v9, "y":I
    .restart local v14    # "x":I
    :cond_17
    move v15, v9

    move v9, v14

    .line 145
    .end local v14    # "x":I
    .local v9, "x":I
    add-int/lit8 v14, v9, 0x1

    const/4 v0, 0x0

    .end local v9    # "x":I
    .restart local v14    # "x":I
    goto/16 :goto_0

    :cond_18
    move/from16 v19, v10

    move/from16 v20, v11

    move v9, v14

    .line 184
    .end local v14    # "x":I
    iget-object v0, v12, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    if-eqz v0, :cond_19

    iget v0, v12, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    iget v1, v12, Lcom/EZdev/mc2/Chunk;->bufferCapacity:I

    if-le v0, v1, :cond_1a

    .line 185
    :cond_19
    iget v0, v12, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    add-int/lit16 v0, v0, 0x3e8

    iput v0, v12, Lcom/EZdev/mc2/Chunk;->bufferCapacity:I

    .line 186
    mul-int/lit8 v0, v0, 0x3

    mul-int/lit8 v0, v0, 0x4

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;

    move-result-object v0

    iput-object v0, v12, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    .line 187
    iget v0, v12, Lcom/EZdev/mc2/Chunk;->bufferCapacity:I

    mul-int/lit8 v0, v0, 0x4

    mul-int/lit8 v0, v0, 0x4

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;

    move-result-object v0

    iput-object v0, v12, Lcom/EZdev/mc2/Chunk;->colorBuffer:Ljava/nio/FloatBuffer;

    .line 190
    :cond_1a
    monitor-enter p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 191
    :try_start_1
    iget-object v0, v12, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    invoke-virtual {v0}, Ljava/nio/FloatBuffer;->clear()Ljava/nio/Buffer;

    .line 192
    iget-object v0, v12, Lcom/EZdev/mc2/Chunk;->vertexBuffer:Ljava/nio/FloatBuffer;

    sget-object v1, Lcom/EZdev/mc2/Chunk;->sharedVData:[F

    iget v2, v12, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    mul-int/lit8 v2, v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Ljava/nio/FloatBuffer;->put([FII)Ljava/nio/FloatBuffer;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    .line 194
    iget-object v0, v12, Lcom/EZdev/mc2/Chunk;->colorBuffer:Ljava/nio/FloatBuffer;

    invoke-virtual {v0}, Ljava/nio/FloatBuffer;->clear()Ljava/nio/Buffer;

    .line 195
    iget-object v0, v12, Lcom/EZdev/mc2/Chunk;->colorBuffer:Ljava/nio/FloatBuffer;

    sget-object v1, Lcom/EZdev/mc2/Chunk;->sharedCData:[F

    iget v2, v12, Lcom/EZdev/mc2/Chunk;->vertexCount:I

    mul-int/lit8 v2, v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Ljava/nio/FloatBuffer;->put([FII)Ljava/nio/FloatBuffer;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    .line 197
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 198
    :try_start_2
    monitor-exit v13
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 199
    return-void

    .line 197
    :catchall_1
    move-exception v0

    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    throw v0

    .line 198
    :goto_c
    monitor-exit v13
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw v0
.end method
