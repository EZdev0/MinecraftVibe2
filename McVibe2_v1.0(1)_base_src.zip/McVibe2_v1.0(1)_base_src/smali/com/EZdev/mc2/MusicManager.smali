.class public Lcom/EZdev/mc2/MusicManager;
.super Ljava/lang/Object;
.source "MusicManager.java"


# static fields
.field private static final TAG:Ljava/lang/String; = "MusicManager"


# instance fields
.field private context:Landroid/content/Context;

.field private currentTrack:I

.field private isEnabled:Z

.field private isPlaying:Z

.field private mediaPlayer:Landroid/media/MediaPlayer;

.field private random:Ljava/security/SecureRandom;

.field private trackUrls:[Ljava/lang/String;


# direct methods
.method public static synthetic $r8$lambda$9ftdrUHsbCODq6aQ1wPU-7Pyy4E(Lcom/EZdev/mc2/MusicManager;Landroid/media/MediaPlayer;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MusicManager;->lambda$startMusic$1(Landroid/media/MediaPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$xhxcMOcG7a9uEcOtvyvh-hoihQU(Lcom/EZdev/mc2/MusicManager;Landroid/media/MediaPlayer;)V
    .locals 0

    .line 0
    invoke-direct {p0, p1}, Lcom/EZdev/mc2/MusicManager;->lambda$startMusic$0(Landroid/media/MediaPlayer;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .param p1, "context"    # Landroid/content/Context;

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isPlaying:Z

    .line 14
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    .line 18
    const-string v2, "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"

    const-string v3, "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/EZdev/mc2/MusicManager;->trackUrls:[Ljava/lang/String;

    .line 23
    iput v0, p0, Lcom/EZdev/mc2/MusicManager;->currentTrack:I

    .line 26
    iput-object p1, p0, Lcom/EZdev/mc2/MusicManager;->context:Landroid/content/Context;

    .line 27
    const-string v2, "McPrefs"

    invoke-virtual {p1, v2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "MUSIC_ENABLED"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    .line 28
    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/MusicManager;->random:Ljava/security/SecureRandom;

    .line 29
    return-void
.end method

.method private synthetic lambda$startMusic$0(Landroid/media/MediaPlayer;)V
    .locals 0
    .param p1, "mp"    # Landroid/media/MediaPlayer;

    .line 37
    invoke-direct {p0}, Lcom/EZdev/mc2/MusicManager;->playNextTrack()V

    return-void
.end method

.method private synthetic lambda$startMusic$1(Landroid/media/MediaPlayer;)V
    .locals 3
    .param p1, "mp"    # Landroid/media/MediaPlayer;

    .line 41
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v0

    .line 42
    .local v0, "duration":I
    if-lez v0, :cond_0

    .line 44
    iget-object v1, p0, Lcom/EZdev/mc2/MusicManager;->random:Ljava/security/SecureRandom;

    div-int/lit8 v2, v0, 0x2

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    .line 45
    .local v1, "startPoint":I
    invoke-virtual {p1, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    .line 47
    .end local v1    # "startPoint":I
    :cond_0
    invoke-virtual {p1}, Landroid/media/MediaPlayer;->start()V

    .line 48
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/EZdev/mc2/MusicManager;->isPlaying:Z

    .line 49
    return-void
.end method

.method private playNextTrack()V
    .locals 2

    .line 60
    iget-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    if-nez v0, :cond_0

    return-void

    .line 61
    :cond_0
    iget v0, p0, Lcom/EZdev/mc2/MusicManager;->currentTrack:I

    add-int/lit8 v0, v0, 0x1

    iget-object v1, p0, Lcom/EZdev/mc2/MusicManager;->trackUrls:[Ljava/lang/String;

    array-length v1, v1

    rem-int/2addr v0, v1

    iput v0, p0, Lcom/EZdev/mc2/MusicManager;->currentTrack:I

    .line 62
    invoke-virtual {p0}, Lcom/EZdev/mc2/MusicManager;->stopMusic()V

    .line 63
    invoke-virtual {p0}, Lcom/EZdev/mc2/MusicManager;->startMusic()V

    .line 64
    return-void
.end method


# virtual methods
.method public isEnabled()Z
    .locals 1

    .line 83
    iget-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    return v0
.end method

.method public startMusic()V
    .locals 4

    .line 32
    iget-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    if-nez v0, :cond_0

    return-void

    .line 34
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    if-nez v0, :cond_1

    .line 35
    new-instance v0, Landroid/media/MediaPlayer;

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    .line 36
    iget-object v1, p0, Lcom/EZdev/mc2/MusicManager;->context:Landroid/content/Context;

    iget-object v2, p0, Lcom/EZdev/mc2/MusicManager;->trackUrls:[Ljava/lang/String;

    iget v3, p0, Lcom/EZdev/mc2/MusicManager;->currentTrack:I

    aget-object v2, v2, v3

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    .line 37
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    new-instance v1, Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda0;-><init>(Lcom/EZdev/mc2/MusicManager;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 38
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->prepareAsync()V

    .line 39
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    new-instance v1, Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcom/EZdev/mc2/MusicManager$$ExternalSyntheticLambda1;-><init>(Lcom/EZdev/mc2/MusicManager;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    goto :goto_0

    .line 54
    :catch_0
    move-exception v0

    goto :goto_1

    .line 50
    :cond_1
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v0

    if-nez v0, :cond_2

    .line 51
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    .line 52
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isPlaying:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    :cond_2
    :goto_0
    goto :goto_2

    .line 54
    :goto_1
    nop

    .line 55
    .local v0, "e":Ljava/lang/Exception;
    const-string v1, "MusicManager"

    const-string v2, "Error starting music"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 57
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_2
    return-void
.end method

.method public stopMusic()V
    .locals 1

    .line 67
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_1

    .line 68
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    .line 69
    :cond_0
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    .line 70
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/EZdev/mc2/MusicManager;->mediaPlayer:Landroid/media/MediaPlayer;

    .line 71
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isPlaying:Z

    .line 73
    :cond_1
    return-void
.end method

.method public toggleMusic()V
    .locals 3

    .line 76
    iget-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    .line 77
    iget-object v0, p0, Lcom/EZdev/mc2/MusicManager;->context:Landroid/content/Context;

    const-string v1, "McPrefs"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "MUSIC_ENABLED"

    iget-boolean v2, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 78
    iget-boolean v0, p0, Lcom/EZdev/mc2/MusicManager;->isEnabled:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/EZdev/mc2/MusicManager;->startMusic()V

    goto :goto_0

    .line 79
    :cond_0
    invoke-virtual {p0}, Lcom/EZdev/mc2/MusicManager;->stopMusic()V

    .line 80
    :goto_0
    return-void
.end method
