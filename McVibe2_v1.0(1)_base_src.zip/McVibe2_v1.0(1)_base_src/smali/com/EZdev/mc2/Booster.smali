.class public Lcom/EZdev/mc2/Booster;
.super Ljava/lang/Object;
.source "Booster.java"


# static fields
.field public static colorHandle:I

.field public static fogEnabledHandle:I

.field public static fogEndHandle:I

.field public static isFlashingHandle:I

.field public static mvpHandle:I

.field public static pTypeHandle:I

.field public static posHandle:I

.field public static shaderProgram:I

.field public static timeHandle:I

.field public static tntColorBuffer:Ljava/nio/FloatBuffer;

.field public static tntVertexBuffer:Ljava/nio/FloatBuffer;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static buildTnt()V
    .locals 16

    .line 58
    const/16 v0, 0x6c

    new-array v0, v0, [F

    .line 59
    .local v0, "v":[F
    const/16 v1, 0x90

    new-array v1, v1, [F

    .line 60
    .local v1, "c":[F
    const/4 v2, 0x0

    .line 61
    .local v2, "cS":I
    const/4 v3, 0x6

    new-array v4, v3, [[F

    const/16 v5, 0x12

    new-array v6, v5, [F

    fill-array-data v6, :array_0

    const/4 v7, 0x0

    aput-object v6, v4, v7

    new-array v6, v5, [F

    fill-array-data v6, :array_1

    const/4 v8, 0x1

    aput-object v6, v4, v8

    new-array v6, v5, [F

    fill-array-data v6, :array_2

    const/4 v9, 0x2

    aput-object v6, v4, v9

    new-array v6, v5, [F

    fill-array-data v6, :array_3

    const/4 v10, 0x3

    aput-object v6, v4, v10

    new-array v6, v5, [F

    fill-array-data v6, :array_4

    const/4 v11, 0x4

    aput-object v6, v4, v11

    new-array v6, v5, [F

    fill-array-data v6, :array_5

    const/4 v12, 0x5

    aput-object v6, v4, v12

    .line 70
    .local v4, "fs":[[F
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_0
    if-ge v6, v3, :cond_2

    .line 71
    const/4 v12, 0x0

    .local v12, "j":I
    :goto_1
    if-ge v12, v5, :cond_0

    .line 72
    mul-int/lit8 v13, v2, 0x3

    add-int/2addr v13, v12

    aget-object v14, v4, v6

    aget v14, v14, v12

    aput v14, v0, v13

    .line 71
    add-int/lit8 v12, v12, 0x1

    goto :goto_1

    :cond_0
    nop

    .line 74
    .end local v12    # "j":I
    const/4 v12, 0x0

    .restart local v12    # "j":I
    :goto_2
    if-ge v12, v3, :cond_1

    .line 75
    mul-int/lit8 v13, v2, 0x4

    mul-int/lit8 v14, v12, 0x4

    add-int/2addr v13, v14

    const v14, 0x3f666666    # 0.9f

    aput v14, v1, v13

    .line 76
    mul-int/lit8 v13, v2, 0x4

    mul-int/lit8 v14, v12, 0x4

    add-int/2addr v13, v14

    add-int/2addr v13, v8

    const v14, 0x3e4ccccd    # 0.2f

    aput v14, v1, v13

    .line 77
    mul-int/lit8 v13, v2, 0x4

    mul-int/lit8 v15, v12, 0x4

    add-int/2addr v13, v15

    add-int/2addr v13, v9

    aput v14, v1, v13

    .line 78
    mul-int/lit8 v13, v2, 0x4

    mul-int/lit8 v14, v12, 0x4

    add-int/2addr v13, v14

    add-int/2addr v13, v10

    const/high16 v14, 0x3f800000    # 1.0f

    aput v14, v1, v13

    .line 74
    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    :cond_1
    nop

    .line 80
    .end local v12    # "j":I
    add-int/lit8 v2, v2, 0x6

    .line 70
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_2
    nop

    .line 83
    .end local v6    # "i":I
    array-length v3, v0

    mul-int/2addr v3, v11

    invoke-static {v3}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    .line 84
    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v3

    .line 85
    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;

    move-result-object v3

    sput-object v3, Lcom/EZdev/mc2/Booster;->tntVertexBuffer:Ljava/nio/FloatBuffer;

    .line 86
    invoke-virtual {v3, v0}, Ljava/nio/FloatBuffer;->put([F)Ljava/nio/FloatBuffer;

    move-result-object v3

    invoke-virtual {v3, v7}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    .line 88
    array-length v3, v1

    mul-int/2addr v3, v11

    invoke-static {v3}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    .line 89
    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v3

    .line 90
    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;

    move-result-object v3

    sput-object v3, Lcom/EZdev/mc2/Booster;->tntColorBuffer:Ljava/nio/FloatBuffer;

    .line 91
    invoke-virtual {v3, v1}, Ljava/nio/FloatBuffer;->put([F)Ljava/nio/FloatBuffer;

    move-result-object v3

    invoke-virtual {v3, v7}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    .line 92
    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
    .end array-data

    :array_2
    .array-data 4
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
    .end array-data

    :array_3
    .array-data 4
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
    .end array-data

    :array_4
    .array-data 4
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
    .end array-data

    :array_5
    .array-data 4
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public static initGeometry()V
    .locals 6

    .line 14
    const-string v0, "precision mediump float; precision mediump int; uniform mat4 uMVPMatrix; uniform float uTime; uniform int pType; attribute vec4 vPosition; attribute vec4 vColor; varying vec4 fColor; varying float vDist; void main() { vec4 pos = vPosition; if (vColor.r > 0.8 && vColor.g > 0.4 && vColor.b < 0.2 && pType != 99 && pType != 100) { float w = 1.0 - vColor.a; pos.x += sin(uTime * 15.0 + pos.y * 10.0) * 0.15 * w; pos.z += cos(uTime * 15.0 + pos.x * 10.0) * 0.15 * w; } gl_Position = uMVPMatrix * pos; fColor = vec4(vColor.rgb, 1.0); vDist = gl_Position.w; }"

    .line 19
    .local v0, "v":Ljava/lang/String;
    const-string v1, "precision mediump float; precision mediump int; varying vec4 fColor; varying float vDist; uniform int uFogEnabled; uniform float uFogEnd; uniform float uTime; uniform int uIsFlashing; uniform int pType; void main() { vec4 fc = fColor; if (uIsFlashing == 1) { float p = (sin(uTime * 15.0) + 1.0) * 0.5; fc = mix(fColor, vec4(1.0), p); } else if (uIsFlashing == 2 && pType == 99) { fc = vec4(0.8, 0.8, 0.8, 0.7); } else if (pType == 100) { fc = vec4(0.9, 0.6, 0.7, 1.0); } else if (pType == 1) { fc = vec4(0.3, 0.7, 0.2, 1.0); } else if (pType == 10) { fc = vec4(0.4, 0.25, 0.1, 1.0); } else if (pType == 2) { fc = vec4(0.4, 0.4, 0.4, 1.0); } else if (pType == 3) { fc = vec4(0.4, 0.25, 0.1, 1.0); } else if (pType == 4) { fc = vec4(0.1, 0.5, 0.1, 1.0); } else if (pType == 6) { fc = vec4(0.9, 0.5, 0.1, 1.0); } if (uFogEnabled == 1) { float ff = clamp((vDist - (uFogEnd * 0.4)) / (uFogEnd * 0.6), 0.0, 1.0); gl_FragColor = mix(fc, vec4(0.5, 0.8, 1.0, 1.0), ff); } else { gl_FragColor = fc; } }"

    .line 33
    .local v1, "f":Ljava/lang/String;
    const v2, 0x8b31

    invoke-static {v2}, Landroid/opengl/GLES20;->glCreateShader(I)I

    move-result v2

    .line 34
    .local v2, "vs":I
    invoke-static {v2, v0}, Landroid/opengl/GLES20;->glShaderSource(ILjava/lang/String;)V

    .line 35
    invoke-static {v2}, Landroid/opengl/GLES20;->glCompileShader(I)V

    .line 37
    const v3, 0x8b30

    invoke-static {v3}, Landroid/opengl/GLES20;->glCreateShader(I)I

    move-result v3

    .line 38
    .local v3, "fs":I
    invoke-static {v3, v1}, Landroid/opengl/GLES20;->glShaderSource(ILjava/lang/String;)V

    .line 39
    invoke-static {v3}, Landroid/opengl/GLES20;->glCompileShader(I)V

    .line 41
    invoke-static {}, Landroid/opengl/GLES20;->glCreateProgram()I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    .line 42
    invoke-static {v4, v2}, Landroid/opengl/GLES20;->glAttachShader(II)V

    .line 43
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    invoke-static {v4, v3}, Landroid/opengl/GLES20;->glAttachShader(II)V

    .line 44
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    invoke-static {v4}, Landroid/opengl/GLES20;->glLinkProgram(I)V

    .line 46
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "vPosition"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetAttribLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->posHandle:I

    .line 47
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "vColor"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetAttribLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->colorHandle:I

    .line 48
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "uMVPMatrix"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->mvpHandle:I

    .line 49
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "uFogEnabled"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->fogEnabledHandle:I

    .line 50
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "uFogEnd"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->fogEndHandle:I

    .line 51
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "uTime"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->timeHandle:I

    .line 52
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "uIsFlashing"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->isFlashingHandle:I

    .line 53
    sget v4, Lcom/EZdev/mc2/Booster;->shaderProgram:I

    const-string v5, "pType"

    invoke-static {v4, v5}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v4

    sput v4, Lcom/EZdev/mc2/Booster;->pTypeHandle:I

    .line 54
    invoke-static {}, Lcom/EZdev/mc2/Booster;->buildTnt()V

    .line 55
    return-void
.end method
