.class public Lcom/EZdev/mc2/UIManager$TouchOverlay;
.super Landroid/view/View;
.source "UIManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/UIManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "TouchOverlay"
.end annotation


# instance fields
.field private blockBreakPaint:Landroid/graphics/Paint;

.field private fpsPaint:Landroid/graphics/Paint;

.field private healthPaint:Landroid/graphics/Paint;

.field private joyBaseX:F

.field private joyBaseY:F

.field private joyId:I

.field private joyKnobX:F

.field private joyKnobY:F

.field private lastLookX:F

.field private lastLookY:F

.field private lookId:I

.field private p:Landroid/graphics/Paint;

.field private final sb:Ljava/lang/StringBuilder;

.field private textPaint:Landroid/graphics/Paint;

.field final synthetic this$0:Lcom/EZdev/mc2/UIManager;


# direct methods
.method public constructor <init>(Lcom/EZdev/mc2/UIManager;Landroid/content/Context;)V
    .locals 8
    .param p1, "this$0"    # Lcom/EZdev/mc2/UIManager;
    .param p2, "c"    # Landroid/content/Context;

    .line 486
    iput-object p1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    .line 487
    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 480
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->textPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->fpsPaint:Landroid/graphics/Paint;

    .line 481
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->healthPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->blockBreakPaint:Landroid/graphics/Paint;

    .line 482
    const/4 v0, -0x1

    iput v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    iput v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lookId:I

    .line 484
    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v2, 0x80

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    iput-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    .line 488
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->textPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->textPaint:Landroid/graphics/Paint;

    const/high16 v2, 0x42100000    # 36.0f

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->textPaint:Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->textPaint:Landroid/graphics/Paint;

    const/high16 v4, 0x40a00000    # 5.0f

    const/high16 v5, 0x40000000    # 2.0f

    const/high16 v6, -0x1000000

    invoke-virtual {v1, v4, v5, v5, v6}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 489
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->fpsPaint:Landroid/graphics/Paint;

    const/16 v7, -0x100

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->fpsPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->fpsPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->fpsPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v5, v6}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 490
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->healthPaint:Landroid/graphics/Paint;

    const/high16 v2, -0x10000

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->healthPaint:Landroid/graphics/Paint;

    const/high16 v2, 0x42340000    # 45.0f

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->healthPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->healthPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v5, v6}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    .line 491
    iget-object v1, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->blockBreakPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->blockBreakPaint:Landroid/graphics/Paint;

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v0, p0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->blockBreakPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 492
    return-void
.end method


# virtual methods
.method public onDraw(Landroid/graphics/Canvas;)V
    .locals 17
    .param p1, "canvas"    # Landroid/graphics/Canvas;

    .line 495
    move-object/from16 v0, p0

    move-object/from16 v10, p1

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    if-eqz v1, :cond_0

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    if-nez v1, :cond_1

    :cond_0
    goto/16 :goto_2

    .line 497
    :cond_1
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    iget-boolean v1, v1, Lcom/EZdev/mc2/UIManager;->showDebug:Z

    const/4 v11, 0x0

    if-eqz v1, :cond_3

    .line 498
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 499
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const-string v2, "X: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v2}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v2

    iget-object v2, v2, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v2, v2, Lcom/EZdev/mc2/Gameplay;->camX:F

    float-to-int v2, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " Y: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v2}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v2

    iget-object v2, v2, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v2, v2, Lcom/EZdev/mc2/Gameplay;->camY:F

    float-to-int v2, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " Z: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v2}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v2

    iget-object v2, v2, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v2, v2, Lcom/EZdev/mc2/Gameplay;->camZ:F

    float-to-int v2, v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 500
    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    const/high16 v5, 0x41f00000    # 30.0f

    const/high16 v6, 0x42700000    # 60.0f

    iget-object v7, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->textPaint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/CharSequence;IIFFLandroid/graphics/Paint;)V

    .line 502
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 503
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const-string v2, "FPS: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v2}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v2

    iget v2, v2, Lcom/EZdev/mc2/MyGdxGame;->currentFPS:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 504
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    iget-boolean v1, v1, Lcom/EZdev/mc2/UIManager;->fastRender:Z

    if-eqz v1, :cond_2

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const-string v2, " [VULKAN ENABLED]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 505
    :cond_2
    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    const/high16 v5, 0x41f00000    # 30.0f

    const/high16 v6, 0x42dc0000    # 110.0f

    iget-object v7, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->fpsPaint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/CharSequence;IIFFLandroid/graphics/Paint;)V

    .line 508
    :cond_3
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v1, v1, Lcom/EZdev/mc2/Gameplay;->isCreative:Z

    const/16 v12, 0x64

    const/high16 v13, 0x40000000    # 2.0f

    if-nez v1, :cond_8

    .line 510
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 511
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v1, v1, Lcom/EZdev/mc2/Gameplay;->health:F

    float-to-int v1, v1

    div-int/lit8 v14, v1, 0x2

    .line 512
    .local v14, "hearts":I
    const/4 v1, 0x0

    .local v1, "h":I
    :goto_0
    const/16 v2, 0xa

    if-ge v1, v2, :cond_5

    .line 513
    if-ge v1, v14, :cond_4

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const-string v3, "\u2764\ufe0f"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    .line 514
    :cond_4
    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const-string v3, "\ud83d\udda4"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 512
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_5
    nop

    .line 518
    .end local v1    # "h":I
    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->sb:Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    const/high16 v5, 0x435c0000    # 220.0f

    sub-float v5, v1, v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    add-int/lit16 v1, v1, -0xc8

    int-to-float v6, v1

    iget-object v7, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->healthPaint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/CharSequence;IIFFLandroid/graphics/Paint;)V

    .line 521
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v1, v1, Lcom/EZdev/mc2/Gameplay;->fireDamageTimer:F

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    if-lez v1, :cond_6

    .line 522
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1}, Landroid/graphics/Paint;-><init>()V

    move-object v7, v1

    .line 523
    .local v7, "fireOverlay":Landroid/graphics/Paint;
    const/16 v1, 0xff

    invoke-static {v12, v1, v12, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 524
    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v4, v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v5, v1

    move-object/from16 v1, p1

    move-object v6, v7

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 528
    .end local v7    # "fireOverlay":Landroid/graphics/Paint;
    :cond_6
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget-boolean v1, v1, Lcom/EZdev/mc2/Gameplay;->isBreaking:Z

    if-eqz v1, :cond_8

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v1, v1, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    const v2, 0x3d4ccccd    # 0.05f

    cmpl-float v1, v1, v2

    if-lez v1, :cond_8

    .line 529
    const/high16 v15, 0x3f800000    # 1.0f

    .line 530
    .local v15, "maxTime":F
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v1}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v1

    iget-object v1, v1, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v1, v1, Lcom/EZdev/mc2/Gameplay;->breakTimer:F

    div-float/2addr v1, v15

    const/high16 v2, 0x43b40000    # 360.0f

    mul-float/2addr v1, v2

    .line 531
    .local v1, "progress":F
    cmpl-float v2, v1, v2

    if-lez v2, :cond_7

    const/high16 v1, 0x43b40000    # 360.0f

    :cond_7
    move/from16 v16, v1

    .line 532
    .end local v1    # "progress":F
    .local v16, "progress":F
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    const/high16 v2, 0x42200000    # 40.0f

    sub-float v3, v1, v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    sub-float v4, v1, v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    add-float v5, v1, v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    add-float v6, v1, v2

    const/high16 v7, -0x3d4c0000    # -90.0f

    const/4 v8, 0x0

    iget-object v9, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->blockBreakPaint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move v2, v3

    move v3, v4

    move v4, v5

    move v5, v6

    move v6, v7

    move/from16 v7, v16

    invoke-virtual/range {v1 .. v9}, Landroid/graphics/Canvas;->drawArc(FFFFFFZLandroid/graphics/Paint;)V

    .line 536
    .end local v14    # "hearts":I
    .end local v15    # "maxTime":F
    .end local v16    # "progress":F
    :cond_8
    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    const/4 v7, -0x1

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    const/high16 v2, 0x40a00000    # 5.0f

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 537
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    const/high16 v8, 0x41a00000    # 20.0f

    sub-float v2, v1, v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float v3, v1, v13

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    add-float v4, v1, v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float v5, v1, v13

    iget-object v6, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 538
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float v2, v1, v13

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    sub-float v3, v1, v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float v4, v1, v13

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v13

    add-float v5, v1, v8

    iget-object v6, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 540
    iget v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    if-eq v1, v7, :cond_9

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    invoke-static {v12, v11, v11, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    iget v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseX:F

    iget v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseY:F

    const/high16 v3, 0x43160000    # 150.0f

    iget-object v4, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    invoke-virtual {v10, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget-object v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setColor(I)V

    iget v1, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobX:F

    iget v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobY:F

    const/high16 v3, 0x428c0000    # 70.0f

    iget-object v4, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->p:Landroid/graphics/Paint;

    invoke-virtual {v10, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 541
    :cond_9
    return-void

    .line 495
    :goto_2
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 18
    .param p1, "e"    # Landroid/view/MotionEvent;

    .line 544
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v2}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v2

    if-eqz v2, :cond_e

    iget-object v2, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v2}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v2

    iget-object v2, v2, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    if-nez v2, :cond_0

    const/4 v3, 0x1

    goto/16 :goto_5

    .line 545
    :cond_0
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    .local v2, "action":I
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v4

    .local v4, "pIndex":I
    invoke-virtual {v1, v4}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v5

    .line 546
    .local v5, "pId":I
    invoke-virtual {v1, v4}, Landroid/view/MotionEvent;->getX(I)F

    move-result v6

    .local v6, "x":F
    invoke-virtual {v1, v4}, Landroid/view/MotionEvent;->getY(I)F

    move-result v7

    .line 548
    .local v7, "y":F
    const/4 v8, -0x1

    if-eqz v2, :cond_b

    const/4 v9, 0x5

    if-ne v2, v9, :cond_1

    move/from16 v17, v4

    goto/16 :goto_3

    .line 551
    :cond_1
    const/4 v9, 0x2

    if-ne v2, v9, :cond_8

    .line 552
    const/4 v8, 0x0

    .local v8, "i":I
    :goto_0
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v9

    if-ge v8, v9, :cond_7

    .line 553
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getX(I)F

    move-result v9

    .local v9, "currX":F
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getY(I)F

    move-result v10

    .line 554
    .local v10, "currY":F
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v11

    iget v12, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    if-ne v11, v12, :cond_4

    .line 555
    iget v11, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseX:F

    sub-float v11, v9, v11

    .local v11, "dx":F
    iget v12, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseY:F

    sub-float v12, v10, v12

    .local v12, "dy":F
    mul-float v13, v11, v11

    mul-float v14, v12, v12

    add-float/2addr v13, v14

    float-to-double v13, v13

    invoke-static {v13, v14}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v13

    double-to-float v13, v13

    .line 556
    .local v13, "dist":F
    const/high16 v14, 0x43160000    # 150.0f

    cmpl-float v15, v13, v14

    if-lez v15, :cond_2

    iget v15, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseX:F

    div-float v16, v14, v13

    mul-float v16, v16, v11

    add-float v15, v15, v16

    iput v15, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobX:F

    iget v15, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseY:F

    div-float v16, v14, v13

    mul-float v16, v16, v12

    add-float v15, v15, v16

    iput v15, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobY:F

    goto :goto_1

    :cond_2
    iput v9, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobX:F

    iput v10, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobY:F

    .line 557
    :goto_1
    iget-object v15, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v15}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v15

    iget-object v15, v15, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobX:F

    move/from16 v17, v4

    .end local v4    # "pIndex":I
    .local v17, "pIndex":I
    iget v4, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseX:F

    sub-float/2addr v3, v4

    div-float/2addr v3, v14

    iput v3, v15, Lcom/EZdev/mc2/Gameplay;->joyMoveX:F

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v4, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobY:F

    iget v15, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseY:F

    sub-float/2addr v4, v15

    div-float/2addr v4, v14

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->joyMoveY:F

    .line 558
    .end local v11    # "dx":F
    .end local v12    # "dy":F
    .end local v13    # "dist":F
    :cond_3
    goto :goto_2

    .end local v17    # "pIndex":I
    .restart local v4    # "pIndex":I
    :cond_4
    move/from16 v17, v4

    .end local v4    # "pIndex":I
    .restart local v17    # "pIndex":I
    invoke-virtual {v1, v8}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v3

    iget v4, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lookId:I

    if-ne v3, v4, :cond_3

    .line 559
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v4, v3, Lcom/EZdev/mc2/Gameplay;->yaw:F

    iget v11, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lastLookX:F

    sub-float v11, v9, v11

    const v12, 0x3e4ccccd    # 0.2f

    mul-float/2addr v11, v12

    add-float/2addr v4, v11

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->yaw:F

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v4, v3, Lcom/EZdev/mc2/Gameplay;->pitch:F

    iget v11, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lastLookY:F

    sub-float v11, v10, v11

    mul-float/2addr v11, v12

    sub-float/2addr v4, v11

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->pitch:F

    .line 560
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v3, v3, Lcom/EZdev/mc2/Gameplay;->pitch:F

    const/high16 v4, 0x42b20000    # 89.0f

    cmpl-float v3, v3, v4

    if-lez v3, :cond_5

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->pitch:F

    :cond_5
    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iget v3, v3, Lcom/EZdev/mc2/Gameplay;->pitch:F

    const/high16 v4, -0x3d4e0000    # -89.0f

    cmpg-float v3, v3, v4

    if-gez v3, :cond_6

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->pitch:F

    .line 561
    :cond_6
    iput v9, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lastLookX:F

    iput v10, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lastLookY:F

    .line 552
    .end local v9    # "currX":F
    .end local v10    # "currY":F
    :goto_2
    add-int/lit8 v8, v8, 0x1

    move/from16 v4, v17

    goto/16 :goto_0

    .end local v17    # "pIndex":I
    .restart local v4    # "pIndex":I
    :cond_7
    move/from16 v17, v4

    .end local v4    # "pIndex":I
    .end local v8    # "i":I
    .restart local v17    # "pIndex":I
    goto :goto_4

    .line 564
    .end local v17    # "pIndex":I
    .restart local v4    # "pIndex":I
    :cond_8
    move/from16 v17, v4

    .end local v4    # "pIndex":I
    .restart local v17    # "pIndex":I
    const/4 v3, 0x1

    if-eq v2, v3, :cond_9

    const/4 v3, 0x6

    if-eq v2, v3, :cond_9

    const/4 v3, 0x3

    if-ne v2, v3, :cond_d

    .line 565
    :cond_9
    iget v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    if-ne v5, v3, :cond_a

    iput v8, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    const/4 v4, 0x0

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->joyMoveX:F

    iget-object v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->this$0:Lcom/EZdev/mc2/UIManager;

    invoke-static {v3}, Lcom/EZdev/mc2/UIManager;->-$$Nest$fgetengine(Lcom/EZdev/mc2/UIManager;)Lcom/EZdev/mc2/MyGdxGame;

    move-result-object v3

    iget-object v3, v3, Lcom/EZdev/mc2/MyGdxGame;->gameplay:Lcom/EZdev/mc2/Gameplay;

    iput v4, v3, Lcom/EZdev/mc2/Gameplay;->joyMoveY:F

    .line 566
    :cond_a
    iget v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lookId:I

    if-ne v5, v3, :cond_d

    iput v8, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lookId:I

    goto :goto_4

    .line 548
    .end local v17    # "pIndex":I
    .restart local v4    # "pIndex":I
    :cond_b
    move/from16 v17, v4

    .line 549
    .end local v4    # "pIndex":I
    .restart local v17    # "pIndex":I
    :goto_3
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    const/high16 v4, 0x40400000    # 3.0f

    div-float/2addr v3, v4

    cmpg-float v3, v6, v3

    if-gez v3, :cond_c

    iget v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    if-ne v3, v8, :cond_c

    iput v5, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyId:I

    iput v6, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseX:F

    iput v7, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyBaseY:F

    iput v6, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobX:F

    iput v7, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->joyKnobY:F

    goto :goto_4

    .line 550
    :cond_c
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v4

    cmpl-float v3, v6, v3

    if-ltz v3, :cond_d

    iget v3, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lookId:I

    if-ne v3, v8, :cond_d

    iput v5, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lookId:I

    iput v6, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lastLookX:F

    iput v7, v0, Lcom/EZdev/mc2/UIManager$TouchOverlay;->lastLookY:F

    .line 568
    :cond_d
    :goto_4
    const/4 v3, 0x1

    return v3

    .line 544
    .end local v2    # "action":I
    .end local v5    # "pId":I
    .end local v6    # "x":F
    .end local v7    # "y":F
    .end local v17    # "pIndex":I
    :cond_e
    const/4 v3, 0x1

    :goto_5
    return v3
.end method
