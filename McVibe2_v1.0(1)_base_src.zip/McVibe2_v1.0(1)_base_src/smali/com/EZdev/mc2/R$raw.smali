.class public final Lcom/EZdev/mc2/R$raw;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/EZdev/mc2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "raw"
.end annotation


# static fields
.field public static grass:I = 0x7f040000

.field public static stone:I = 0x7f040001

.field public static tnt:I = 0x7f040002

.field public static water:I = 0x7f040003

.field public static wood:I = 0x7f040004


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
